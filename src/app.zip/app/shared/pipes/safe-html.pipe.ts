import { NgModule } from '@angular/core';
import { SanitizeTextPipe } from './sanitize-text';
import { WeekNumberPipe } from './week-number';
import { AlphaNumberPipe } from './alpha-number';

@NgModule({
    declarations: [SanitizeTextPipe, WeekNumberPipe, AlphaNumberPipe],
    exports: [SanitizeTextPipe, WeekNumberPipe, AlphaNumberPipe]
})
export class SafeHtmlPipe { }