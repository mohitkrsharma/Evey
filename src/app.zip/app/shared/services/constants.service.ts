/* Importing all the Modules,component,services we need */
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class ConstantsService {


  constructor() { }


  public alertData() {
    const alertData = [
      {
        name: 'White / Dark Blue Boarder',
        priority: 2,
        property: {
          border_color: '#0063AB',
          background_color: '#FFFFFF',
          font_color: '#0063AB',
          font_size: 17
        },
        icon: 'assets/images/white.png'
      },
      {
        name: 'Light Blue / Dark Blue Boarder',
        priority: 3,
        property: {
          border_color: '#0063AB',
          background_color: '#E1F4FD',
          font_color: '#0063AB',
          font_size: 17
        },
        icon: 'assets/images/LightBlue.png'
      },
      {
        name: 'Blue / Dark Blue Boarder',
        priority: 4,
        property: {
          border_color: '#0063AB',
          background_color: '#0096D8',
          font_color: '#FFFFFF',
          font_size: 17
        },
        icon: 'assets/images/Blue.png'
      },
      {
        name: 'Dark Blue',
        priority: 5,
        property: {
          border_color: '#0063AB',
          background_color: '#0063AB',
          font_color: '#FFFFFF',
          font_size: 17
        },
        icon: 'assets/images/darkblue.png'
      },
      {
        name: 'Red',
        priority: 1,
        property: {
          border_color: '#E82627',
          background_color: '#E82627',
          font_color: '#FFFFFF',
          font_size: 17
        },
        icon: 'assets/images/red.png'
      },
      {
        name: 'White / Red Boarder',
        priority: 6,
        property: {
          border_color: '#E82627',
          background_color: '#ffffff',
          font_color: '#E82627',
          font_size: 17
        },
        icon: 'assets/images/whiteRed.png'
      },
      {
        name: 'Light Grey / Black Boarder',
        priority: 7,
        property: {
          border_color: '#1A1818',
          background_color: '#EEEEEF',
          font_color: '#1A1818',
          font_size: 17
        },
        icon: 'assets/images/lightGrey.png'
      },
    ];
    return alertData;
  }


}
