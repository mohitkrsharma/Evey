import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Socket } from 'ngx-socket-io';
import { Aes256Service } from './../../../shared/services/aes-256/aes-256.service'


@Injectable({
  providedIn: 'root'
})
export class SocketService {

  constructor(
    private _socket: Socket,
    private _aes256Service: Aes256Service
  ) {}

  getloggedOutUserFn() {
    const observable = new Observable(observer => {
      this._socket.on('logoutUser', (data: any) => {
        data = this._aes256Service.decFnWithsalt(data);
        observer.next(data);
      });
      return () => {
        console.log('SOCKET DISCONNECTED');
        // this.socket.disconnect();
      };
    });
    return observable;
  }

  onDeleteLiveDashboard() {
    const observable = new Observable(observer => {
      this._socket.on('logoutLiveDashboard', (data: any) => {
        data = this._aes256Service.decFnWithsalt(data);
        observer.next(data);
      });
      return () => {
        console.log('SOCKET DISCONNECTED');
        // this.socket.disconnect();
      };
    });
    return observable;
  }

  onTrackCareUpdateFn() {
    console.log('socket connected in trackcare');
    const observable = new Observable(observer => {
      this._socket.on('trackcare', (data: any) => {
        data = this._aes256Service.decFnWithsalt(data);
        observer.next(data);
      });
      return () => {
        console.log('SOCKET DISCONNECTED');
        // this.socket.disconnect();
      };
    });
    return observable;
  }

  onLoginUpdateFn() {
    const observable = new Observable(observer => {
      this._socket.on('onloginupdate', (data: any) => {
        data = this._aes256Service.decFnWithsalt(data);
        observer.next(data);
      });
      return () => {
        console.log('SOCKET DISCONNECTED');
        // this.socket.disconnect();
      };
    });
    return observable;
  }

  getConnectedUserDetailFn() {
    const observable = new Observable(observer => {
      this._socket.on('newConnectedUserDetail', (data) => {
        // console.log('new connected User Detail ----> ', data)
        data = this._aes256Service.decFnWithsalt(data);
        observer.next(data);
      });
      return () => {
        console.log('SOCKET DISCONNECTED');
        // this.socket.disconnect();
      };
    });
    return observable;
  }

  getDisconnectedUserFn() {
    const observable = new Observable(observer => {
      this._socket.on('disconnectedUser', (data) => {
        data = this._aes256Service.decFnWithsalt(data);
        observer.next(data);
      });
      return () => {
        console.log('SOCKET DISCONNECTED');
        // this.socket.disconnect();
      };
    });
    return observable;
  }

  connectedEvent(event: string, payload: any) {
    this._socket.emit(event, payload, function(_res) {
      if (!_res) {
        this.connectedEvent(event, payload);
      }
    });
  }

  reqConnectedUsersFn(event: string) {
    this._socket.emit(event);
  }

  getMessages() {
    const observable = new Observable(observer => {
      this._socket.on('loggedInEvent', (data) => {
        data = this._aes256Service.decFnWithsalt(data);
        observer.next(data);
      });
      return () => {
        console.log('SOCKET DISCONNECTED');
        // this.socket.disconnect();
      };
    });
    return observable;
  }

  getId() {
    const observable = new Observable(observer => {
      this._socket.on('socket_id', (data) => {
        data = this._aes256Service.decFnWithsalt(data);
        observer.next(data);
      });
      return () => {
        console.log('SOCKET DISCONNECTED');
      };
    });
    return observable;
  }

  getAnnouncementFn() {
    const observable = new Observable(observer => {
      this._socket.on('update_announce', (data) => {
        data = this._aes256Service.decFnWithsalt(data);
        observer.next(data);
      });
      return () => {
        console.log('SOCKET DISCONNECTED');
        // this.socket.disconnect();
      };
    });
    return observable;
  }

  updateResidentFn() {
    const observable = new Observable(observer => {
      this._socket.on('update_resident', (data) => {
        data = this._aes256Service.decFnWithsalt(data);
        observer.next(data);
      });
      return () => {
        console.log('SOCKET DISCONNECTED');
        // this.socket.disconnect();
      };
    });
    return observable;
  }

  addResidentFn(){
    const observable = new Observable(observer => {
      this._socket.on('add_resident', (data) => {
        data = this._aes256Service.decFnWithsalt(data);
        observer.next(data);
      });
      return () => {
        console.log('SOCKET DISCONNECTED');
        // this.socket.disconnect();
      };
    });
    return observable;
  }

  updateZoneFn() {
    const observable = new Observable(observer => {
      this._socket.on('update_zone', (data) => {
        data = this._aes256Service.decFnWithsalt(data);
        observer.next(data);
      });
      return () => {
        console.log('SOCKET DISCONNECTED');
        // this.socket.disconnect();
      };
    });
    return observable;
  }

  ///////////////////////////////////////////////////

  async getOngoingShiftFn(payload) {
    return new Promise(async (resolve, reject) => {
      this._socket.emit('ongoingShift', payload, function(_confirmation) {
        _confirmation = this._aes256Service.decFnWithsalt(_confirmation);
        if (_confirmation['_status']) {
          resolve(_confirmation);
        } else {
          reject(_confirmation);
        }
      });
    });
  }
  async getOngoingCaresFn(payload) {
    return new Promise(async (resolve, reject) => {
      this._socket.emit('ongoingCares', payload, function(_confirmation) {
        _confirmation = this._aes256Service.decFnWithsalt(_confirmation);
        if (_confirmation['_status']) {
          resolve(_confirmation);
        } else {
          reject(_confirmation);
        }
      });
    });
  }
  async getOngoingUnassignedFn(payload) {
    return new Promise(async (resolve, reject) => {
      this._socket.emit('ongoingUnassigned', payload, function(_confirmation) {
        _confirmation = this._aes256Service.decFnWithsalt(_confirmation);
        if (_confirmation['_status']) {
          resolve(_confirmation);
        } else {
          reject(_confirmation);
        }
      });
    });
  }

  async getDateTimeFn(payload) {
    return new Promise(async (resolve, reject) => {
      this._socket.emit('getDateTime', payload, function(_confirmation) {
        _confirmation = this._aes256Service.decFnWithsalt(_confirmation);
        if (_confirmation['_status']) {
          resolve(_confirmation);
        } else {
          reject(_confirmation);
        }
      });
    });
  }
  // getOngoingTotaltimeFn(payload, cb) {
  //   this.socket.emit('ongoingTotaltime', payload, function(_confirmation){
  //     cb(_confirmation);
  //   });
  // }
  async getOngoingOpenCaresFn(payload) {
    return new Promise(async (resolve, reject) => {
      this._socket.emit('ongoingOpenCares', payload, function(_confirmation) {
        _confirmation = this._aes256Service.decFnWithsalt(_confirmation);
        if (_confirmation['_status']) {
          resolve(_confirmation);
        } else {
          reject(_confirmation);
        }
      });
    });
  }

  async openCareLeftFn(payload) {
    return new Promise(async (resolve, reject) => {
      this._socket.emit('openCareLeftCount', payload, function(_confirmation) {
        _confirmation = this._aes256Service.decFnWithsalt(_confirmation);
        if (_confirmation['_status']) {
          resolve(_confirmation);
        } else {
          reject(_confirmation);
        }
      });
    });
  }

  async getOngoingPerformersFn(payload) {
    return new Promise(async (resolve, reject) => {
      this._socket.emit('ongoingPerformers', payload, function(_confirmation) {
        _confirmation = this._aes256Service.decFnWithsalt(_confirmation);
        if (_confirmation['_status']) {
          resolve(_confirmation);
        } else {
          reject(_confirmation);
        }
      });
    });
  }

  async fetchLevelFn(payload) {
    return new Promise(async (resolve, reject) => {
      this._socket.emit('fetchLevelRecords', payload , function(_confirmation) {
        _confirmation = this._aes256Service.decFnWithsalt(_confirmation);
        if (_confirmation['_status']) {
          resolve(_confirmation);
        } else {
          reject(_confirmation);
        }
      });
    });
  }

  async fetchFallsFn(payload) {
    return new Promise(async (resolve, reject) => {
      this._socket.emit('fetchFallsRecords', payload , function(_confirmation) {
        _confirmation = this._aes256Service.decFnWithsalt(_confirmation);
        if (_confirmation['_status']) {
          resolve(_confirmation);
        } else {
          reject(_confirmation);
        }
      });
    });
  }

  async fetchAlertsFn(payload) {
    return new Promise(async (resolve, reject) => {
      this._socket.emit('fetchAlertsRecords', payload , function(_confirmation) {
        _confirmation = this._aes256Service.decFnWithsalt(_confirmation);
        if (_confirmation['_status']) {
          resolve(_confirmation);
        } else {
          reject(_confirmation);
        }
      });
    });
  }

  async getLabelMessage(payload) {
    return new Promise(async (resolve, reject) => {
      this._socket.emit('labelMessage', payload, function(_confirmation) {
        _confirmation = this._aes256Service.decFnWithsalt(_confirmation);
        if (_confirmation['_status']) {
          resolve(_confirmation);
        } else {
          reject(_confirmation);
        }
      });
    });
  }

// careGraph
  async careGraphFn(payload) {
    return new Promise(async (resolve, reject) => {
      this._socket.emit('onCareGraphFn', payload, function (_confirmation) {
        _confirmation = this._aes256Service.decFnWithsalt(_confirmation);
        if (_confirmation['_status']) {
          resolve(_confirmation);
        } else {
          reject(_confirmation);
        }
      });
    });
  }

  async load_def_Lev_Chart(payload) {
    return new Promise(async (resolve, reject) => {
      this._socket.emit('onDefLevChart', payload, function (_confirmation) {
        _confirmation = this._aes256Service.decFnWithsalt(_confirmation);
        if (_confirmation['_status']) {
          resolve(_confirmation);
        } else {
          reject(_confirmation);
        }
      });
    });
  }


// LOGGEDIN USERS
async fetchConnectedUsersListFn(payload) {
  return new Promise(async (resolve, reject) => {
    this._socket.emit('connectedUsersList', payload, function(_confirmation) {
      _confirmation = this._aes256Service.decFnWithsalt(_confirmation);
      if (_confirmation['_status']) {
        // console.log("connected Data",_confirmation._result);
        resolve(_confirmation);
      } else {
        reject(_confirmation);
      }
    });
  });
}

onResidentOutOfFacilityFn() {
//  console.log('socket connected in resi_out_of_facility');
  const observable = new Observable(observer => {
    this._socket.on('resi_out_of_facility', (data: any) => {
      data = this._aes256Service.decFnWithsalt(data);
      observer.next(data);
    });
    return () => {
      console.log('SOCKET DISCONNECTED');
      // this.socket.disconnect();
    };
  });
  return observable;
}

onResidentIsVirusCheckFn() {
 // console.log('socket connected in is_virus_check');
  const observable = new Observable(observer => {
    this._socket.on('resi_is_virus_check', (data: any) => {
      data = this._aes256Service.decFnWithsalt(data);
      observer.next(data);
    });
    return () => {
      console.log('SOCKET DISCONNECTED');
      // this.socket.disconnect();
    };
  });
  return observable;
}
onResidentIsIsolationFn() {
 // console.log('socket connected in is_isolation');
  const observable = new Observable(observer => {
    this._socket.on('resident_isolated', (data: any) => {
      data = this._aes256Service.decFnWithsalt(data);
      observer.next(data);
    });
    return () => {
      console.log('SOCKET DISCONNECTED');
      // this.socket.disconnect();
    };
  });
  return observable;
}
onResidentListIsVirusCheckFn() {
 // console.log('socket connected in is_virus_check resident list');
  const observable = new Observable(observer => {
    this._socket.on('resi_list_is_virus_check', (data: any) => {
      data = this._aes256Service.decFnWithsalt(data);
      observer.next(data);
    });
    return () => {
      console.log('SOCKET DISCONNECTED');
      // this.socket.disconnect();
    };
  });
  return observable;
}


}
