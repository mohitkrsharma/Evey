/* Importing all the Modules,component,services we need */
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class CommonService {

  topPosToStartShowing = 100;
  isShow: boolean;

  public content: BehaviorSubject<string> = new BehaviorSubject<string>(' ');
  contentdata = this.content.asObservable();

  public floorcontent: BehaviorSubject<string> = new BehaviorSubject<string>(' ');
  floorcontentdata = this.floorcontent.asObservable();

  public loadercontent: BehaviorSubject<string> = new BehaviorSubject<string>('');
  loadercontentdata = this.loadercontent.asObservable();

  constructor() { }

  // convert date if date is in timestamp format
  public formatDate(data) {
    const date = new Date(data);
    // tslint:disable-next-line: max-line-length
    const monthNames = [ 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' ];

    let hours = date.getHours();
    let minutes = date.getMinutes();
    minutes = Number(minutes);
    const ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? 0 + minutes : minutes;
    const strTime = hours + ':' + minutes + ' ' + ampm;



    const day = date.getDate();
    const monthIndex = date.getMonth();
    const year = date.getFullYear();

    return monthNames[monthIndex] + ' ' + day + ' ' + year + ', ' + strTime;
  }
  public allwoOnlyAlpha({ keyCode }) {
    if ((keyCode >= 65 && keyCode <= 90) ||
      (keyCode >= 97 && keyCode <= 122) ||
      (keyCode === 32)) {
      return true;
    } else {
      return false;
    }
  }

  public allwoOnlyAlpharesi({ keyCode }) {
    if ((keyCode >= 65 && keyCode <= 90) ||
      (keyCode >= 97 && keyCode <= 122) ||
      (keyCode === 32) || (keyCode === 45) || (keyCode === 40) || (keyCode === 41) || (keyCode === 34)) {
      return true;
    } else {
      return false;
    }
  }

  public allwoAlphaAndNumAndSpace({ keyCode }) {
    if ((keyCode >= 65 && keyCode <= 90) ||
      (keyCode >= 97 && keyCode <= 122) ||
      (keyCode >= 48 && keyCode <= 57) || (keyCode === 32) || (keyCode === 45)  ) {
      return true;
    } else {
      return false;
    }
  }

  public allwoAlphaAndNum({ keyCode }) {
    if ((keyCode >= 65 && keyCode <= 90) ||
      (keyCode >= 97 && keyCode <= 122) ||
      (keyCode >= 48 && keyCode <= 57)) {
      return true;
    } else {
      return false;
    }
  }

  public allwoAlphaNumLogin({ keyCode }) {
    if ((keyCode >= 65 && keyCode <= 90) ||
      (keyCode >= 97 && keyCode <= 122) ||
      (keyCode >= 48 && keyCode <= 57) || (keyCode === 46) || (keyCode === 95)) {
      return true;
    } else {
      return false;
    }
  }

  public allwoAlphaNumDash({ keyCode }) {
    if ((keyCode >= 65 && keyCode <= 90) ||
      (keyCode >= 97 && keyCode <= 122) ||
      (keyCode >= 48 && keyCode <= 57) || (keyCode === 45)) {
      return true;
    } else {
      return false;
    }
  }

  public allwoNum({ keyCode }) {
    if ( (keyCode >= 48 && keyCode <= 57) && keyCode !== 101 && keyCode !== 69 || keyCode === 13 ) {
      return true;
    } else {
      return false;
    }
  }

  public allwoNumDecimal({ keyCode }) {
    if ( (keyCode >= 48 && keyCode <= 57) && keyCode !== 101 && keyCode !== 69 || keyCode === 13 || keyCode === 46 ) {
      return true;
    } else {
      return false;
    }
  }

  public notAllwoSpace({ keyCode }) {
    if ((keyCode === 32)) {
      return false;
    } else {
      return true;
    }
  }

  public setOrgFac(data, floorlist) {
    data['floorlist'] = floorlist;
    this.content.next(data);
  }

  public setFloor(floorlist) {
    this.floorcontent.next(floorlist);
  }

  public setLoader(prop) {
    this.loadercontent.next(prop);
  }

  /* Beacon uuid validating */
  public checkUUID(uuid) {
    if (uuid.value.indexOf('_') >= 0 || uuid.value.length < 35) {
      uuid.control.setErrors({
        validateEqual: false
      });
    } else {
      uuid.control.setErrors(null);
    }
  }

  public shiftTime() {
    const arr = [{ no: 1, name: '1st Shift (6:00am - 2:00pm)' },
    { no: 2, name: '2nd Shift (2:00pm - 10:00pm)' },
    { no: 3, name: '3rd Shift (10:00pm - 6:00am)' }];
    return arr;
  }

  checkScroll() {
    // window의 scroll top
    // Both window.pageYOffset and document.documentElement.scrollTop
    // returns the same result in all the cases.
    // window.pageYOffset is not supported below IE 9.
    const scrollPosition = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
    if (scrollPosition >= this.topPosToStartShowing) {
      this.isShow = true;
    } else {
      this.isShow = false;
    }
  }


  async get_rotation () {
      return new Promise((resolve, reject) => {
        const currHour = moment().hour();
        const currTs = moment().valueOf();
        const tomorrow = moment().add(1, 'day');

        const newDate1 = moment();
        const newDate2 = moment();
        let shift = 1;
        if (currHour >= 6 && currHour < 14 ) {
          shift = 1;
          newDate1.set({ hour: 6, minute: 0, second: 0, millisecond: 0 });
          newDate2.set({ hour: 13, minute: 59, second: 59, millisecond: 0 });
        } else if (currHour >= 14 && currHour < 22 ) {
          shift = 2;
          newDate1.set({ hour: 14, minute: 0, second: 0, millisecond: 0 });
          newDate2.set({ hour: 21, minute: 59, second: 59, millisecond: 0 });
        } else {
          shift = 3;
          if (currHour < 6) {
            newDate1.subtract(1, 'day').set({hour: 22, minute: 0, second: 0, millisecond: 0 });
            newDate2.set({ hour: 5, minute: 59, second: 59, millisecond: 0 });
          } else {
            newDate1.set({ hour: 22, minute: 0, second: 0, millisecond: 0 });
            newDate2.add(1, 'day').set({ hour: 5, minute: 59, second: 59, millisecond: 0 });
          }
        }

        const sTime = newDate1.hours();
        const eTime = newDate2.hours();
        const sTimeUTC = newDate1.utc().hours();
        const eTimeUTC = newDate2.utc().hours();
        const sMinute = newDate1.utc().minutes();
        const eMinute = newDate2.utc().minutes();
        let shiftStart, shiftEnd, prevShiftStart;
        shiftStart = newDate1.utc().valueOf();
        shiftEnd = newDate2.utc().valueOf();
        prevShiftStart = newDate1.subtract(8, 'hours').utc().valueOf();

        let  shiftsMinute, shifteMinute;
        let date1 = moment(), date2 = moment().subtract(1, 'days');
        date1 = date1.utc();
        date2 = date2.utc();
        shiftsMinute = date2['_d'].getTime();
        shifteMinute = date1['_d'].getTime();


        const rotation = {
          'rotation': shift,
          'sTime': sTime,
          'eTime': eTime,
          'sTimeUTC' : sTimeUTC,
          'eTimeUTC': eTimeUTC,
          'sMinute': sMinute,
          'eMinute': eMinute,
          'start_date': shiftStart,
          'end_date': shiftEnd,
          'shift24sMinute': shiftsMinute,
          'shift24eMinute': shifteMinute,
          'prevShiftStart': prevShiftStart
        };
        resolve(rotation);

      });
  }

  curr_hrs_mnt () {
    return moment().minutes();
  }

  async get_rotation_as_timeslot (payload) {
    return new Promise((resolve, reject) => {
      const mins = moment().utc().minutes();
      const milliseconds = mins > 30 ? 0 : 3600000;

      const ms =  (moment().valueOf() - milliseconds);
      const gte = (ms + 1800000);
      const lt  = (ms + 3600000);
      const rotation = {
        '$gte': gte,
        '$lt':  lt
      };
        resolve(rotation);
    });
  }

  public errorMessages() {
    const errorMessageList = [{
      user_errors: {
        first_name_allow: 'First name must be contain only letter and spaces',
        first_name_required: 'First name not found',
        last_name_allow: 'Last name must be contain only letter and spaces',
        last_name_required: 'Last name not found',
        personal_email: 'Invalid personal email address',
        work_email: 'Invalid work email address',
        work_email_required: 'Work email not found',
        primary_no: 'Invalid primary Phone please enter only number\'s',
        primary_no_requires: 'Primary phone not found',
        primary_no_len: 'Primary phone no must be 10 digit\'s',
        secondary_no: 'Invalid secondary Phone please enter only number\'s',
        secondary_no_len: 'Secondary phone no must be 10 digit\'s',
        employee_id: 'Employee ID not found',
        postion: 'Invaild postion, Please choose User Position'
      }}
    ];
    return errorMessageList;
  }


}
