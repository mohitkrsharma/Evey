import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiService } from './../../../shared/services/api/api.service';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.scss']
})
export class AlertComponent implements OnInit {
  constructor(private _apiService: ApiService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public _dialogRef: MatDialogRef<AlertComponent>
  ) { }

  ngOnInit() {
  }
  onNoClick(): void {
    this._dialogRef.close(['result']['status'] = false);
  }

  async deleteData() {
    const action = { type: 'DELETE', target: this.data.API };
    const payload = { id: this.data.id };
    const result = await this._apiService.apiFn(action, payload);
    this._dialogRef.close(result);
  }

  async suspendData() {
     const action = { type: 'POST', target: 'users/suspend_user' };
     const payload = { 'active': this.data.id.active, 'userId': this.data.id.userId};
     const result = await this._apiService.apiFn(action, payload);
     this._dialogRef.close(result);
  }

}


