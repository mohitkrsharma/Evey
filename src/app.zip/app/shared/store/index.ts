import { StoreModule } from '@ngrx/store';
import { authReducer } from './auth/reducer';
import { shiftRep_Reducer } from './shiftReport/reducer';
export default [StoreModule.forRoot({ authState: authReducer, shiftRepState: shiftRep_Reducer })]