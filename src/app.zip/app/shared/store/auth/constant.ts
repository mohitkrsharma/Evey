export const GET    = 'GET';
export const INSERT = 'INSERT';
export const UPDATE = 'UPDATE';
export const RESET  = 'RESET';