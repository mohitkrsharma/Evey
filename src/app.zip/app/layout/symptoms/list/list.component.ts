import { Component, OnInit, ViewChild, HostListener, ElementRef, TemplateRef } from '@angular/core';
import { MatTableDataSource, MatSort, PageEvent } from '@angular/material';
import { Router } from '@angular/router';
import { ApiService } from './../../../shared/services/api/api.service';
import { AlertComponent } from '../../../shared/modals/alert/alert.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material/dialog';
import { ExcelService } from './../../../shared/services/excel.service';
import { CommonService } from './../../../shared/services/common.service';
import { ToastrService } from 'ngx-toastr';
import { fromEvent } from 'rxjs';
import { MatOption } from '@angular/material';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import {
  debounceTime,
  map,
  distinctUntilChanged,
  filter,
  tap
} from 'rxjs/operators';
import { bypassSanitizationTrustResourceUrl } from '@angular/core/src/sanitization/bypass';

import {MatTable} from '@angular/material/table';
import {CdkDragDrop, moveItemInArray, transferArrayItem, CdkDragHandle} from '@angular/cdk/drag-drop';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {

  constructor(
    private router: Router,
    private apiService: ApiService,
    public dialog: MatDialog,
    private excelService: ExcelService,
    private toastr: ToastrService,
    private fb: FormBuilder,
    public _commonService: CommonService
  ) { this.createPropertyForm();}
  @ViewChild('table') table: MatTable<any>;
  @ViewChild('addSymptomEle') addSymptomEle: TemplateRef<any>;
  @ViewChild('searchInput') searchInput: ElementRef;
  @ViewChild('deleteButton') private deleteButton: ElementRef;
  public btnAction: Function;

  // MATPAGINATOR
  // pageEvent: PageEvent;
  datasource: null;
  pageIndex: number;
  pageSize: number;
  length: number;
  checked;
  deleteArr = [];
  deleteItem = [];
  data;
  dataSource;
  isShow: boolean;
  topPosToStartShowing = 100;
  displayedColumns = [];
  organiz; floorlist; faclist;
  @ViewChild(MatSort) sort: MatSort;
  sortActive = 'order';
  sortDirection: 'asc' | 'desc' | '';
  count;
  actualDataCount;
  search: any;
  /**
   * Pre-defined columns list for user table
   */
  columnNames = [

    {
      id: 'name',
      value: 'Name',
      sort: false
    },
    {
      id: 'is_isolation',
      value: 'Isolation',
      sort: false
    },
    {
      id: 'isolation_days',
      value: 'Isolation days',
      sort: false
    }
    ];
  exportdata;
  pagiPayload = {
    length: 0,
    pageIndex: 0,
    pageSize: 10,
    previousPageIndex: 0,
    search: '',
  };
  public show = false;
  @HostListener('window:scroll')


  
  dialogRefs = null;
  isEdit = false;
  isOptionField: boolean;
  symptom: any = {   
    name: '',
    is_isolation:false,
    isolation_days:''
    
  };
  symptomForm: FormGroup;
  public temparray: any = [];
  editId: any = null;
  btnClass: string;
 checkScroll() {

 // window의 scroll top
 // Both window.pageYOffset and document.documentElement.scrollTop returns the same result in all the cases. window.pageYOffset is not supported below IE 9.

 const scrollPosition = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;

 if (scrollPosition >= this.topPosToStartShowing) {
 this.isShow = true;
 } else {
 this.isShow = false;
 }
 }

 // TODO: Cross browsing
 gotoTop() {
 window.scroll({
 top: 0,
 left: 0,
 behavior: 'smooth'
 });
 }
  ngOnInit() {
    if (sessionStorage.getItem('pageListing')) {
      const pageListing = JSON.parse(sessionStorage.getItem('pageListing'));
      if (pageListing.symptomList) {
        this.pagiPayload = pageListing.symptomList;
      } else {
        sessionStorage.setItem('pageListing', JSON.stringify({symptomList: this.pagiPayload}));
      }
    } else {
      sessionStorage.setItem('pageListing', JSON.stringify({symptomList: this.pagiPayload}));
    }
    this.search = this.searchInput.nativeElement.value;
    fromEvent(this.searchInput.nativeElement, 'keyup')
      .pipe(
        debounceTime(2000),
        distinctUntilChanged(),
        tap(() => {
          this.getServerData(this.pagiPayload);
        })
      )
      .subscribe();
    this.displayedColumns = this.displayedColumns.concat(['checkbox']);
    this.displayedColumns = this.displayedColumns.concat(['position']);
    this.displayedColumns = this.displayedColumns.concat(this.columnNames.map(x => x.id));
    this.displayedColumns = this.displayedColumns.concat(['change_status']);

    this.displayedColumns = this.displayedColumns.concat(['actions']);
    // Pagination
    this.getServerData(this.pagiPayload);
  }

  selectAll() {
    if (this.checked === true) {
      this.data.forEach(element => {
        element.checked = false;
        this.deleteArr = [];
      });
    } else {
      this.data.forEach(element => {
        this.deleteArr.push(element._id);
        element.checked = true;
      });
    }
  }

  selectElement(id, check) {
    if (check === true) {
      for (let i = 0; i < this.deleteArr.length; i++) {
        if (this.deleteArr[i] === id) {
          this.deleteArr.splice(i, 1);
        }
      }
    } else if (check === undefined || check === false) {
      this.deleteArr.push(id);
    }
    if ((this.deleteArr && this.deleteArr.length) < this.actualDataCount) {
      this.checked = false;
    } else if ((this.deleteArr && this.deleteArr.length) === this.actualDataCount) {
      this.checked = true;
    }
  }

  delete() {
    if (this.deleteArr.length === 0) {
      this.toastr.error('Please select symptom to be deleted');
      this.checked = false;
    } else {
      const dialogRef = this.dialog.open(AlertComponent, {
        width: '350px',
        data: { 'title': 'symptoms', 'id': this.deleteArr, 'API': 'symptoms/delete' }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (!result) {
          this.data.forEach(element => {
            element.checked = false;
            this.checked = false;
          });
          this.deleteArr = [];
        } else {
          if(result['status']){
            this.toastr.success(result['message']);
          }
          this.checked = false;
          this.getServerData(this.pagiPayload);
        }
        this.deleteButton['_elementRef'].nativeElement.classList.remove('cdk-program-focused');
        this.deleteButton['_elementRef'].nativeElement.classList.remove('cdk-focused');
        document.getElementById('searchInput').focus();
        document.getElementById('searchInput').blur();
      });
    }

  }

  createTable(arr) {
    const tableArr: Element[] = arr;
    this.dataSource = new MatTableDataSource(tableArr);
    // this.dataSource.sort = this.sort;
  }






  deleteSymptom(id) {
    this.deleteItem.push(id);
    const dialogRef = this.dialog.open(AlertComponent, {
      width: '350px',
      data: { 'title': 'symptoms', 'id': this.deleteItem, 'API': 'symptoms/delete' }
    });
    dialogRef.afterClosed().subscribe(result => {
      if(result!=false){
        if(result['status']){
          this.toastr.success(result['message']);
        }
        this.getServerData(this.pagiPayload);
      this.checked = false;
      }

    });
  }




  public async getSymptomsDataFunction() {  
    const action = {
      type: 'GET',
      target: 'symptoms'
    };
    const payload = this.pagiPayload;
    let result = await this.apiService.apiFn(action, payload);
   // result = result['data'];
    this.count = result['data']['_count'];
    if (result['status']) {
      result = result['data']['_symptoms'].map(item => {
        return {
          ...item,
          name: item.name,
          is_isolation: (item.is_isolation)?"Yes":"No",
          isolation_days: (item.is_isolation)?item.isolation_days:"--",
          order: item.order
        };
      });
      this.data = result;
      if (this.data && this.data.length > 0) {
        this.actualDataCount = this.data.length;
      }
      this.createTable(result);
      this._commonService.setLoader(false);
    }
  }

  sortData(sort?: PageEvent) {
    // console.log('sortsortsortsortsort',sort);
    if (sort['direction'] === '') {
      this.sort.active = sort['active'];
      this.sort.direction = 'asc';
      this.sort.sortChange.emit({active: sort['active'], direction: 'asc'});
      this.sort._stateChanges.next();
      return;
    }
    this._commonService.setLoader(true);
    this.pagiPayload['sort'] = sort;
    sessionStorage.setItem('pageListing', JSON.stringify({symptomList: this.pagiPayload}));
    this.getSymptomsDataFunction();
  }

  public async getServerData(event?: PageEvent) {
    this._commonService.setLoader(true);
    this.pagiPayload.previousPageIndex = event.previousPageIndex;
    this.pagiPayload.pageIndex = event.pageIndex;
    this.pagiPayload.pageSize = event.pageSize;
    this.pagiPayload.length = event.length;
    this.pagiPayload.search = this.search;
    sessionStorage.setItem('pageListing', JSON.stringify({symptomList: this.pagiPayload}));
    this.getSymptomsDataFunction();

  }

  get optionsPoints() {
    return this.symptomForm.get('options') as FormArray;
  }
  createPropertyForm() {
    this.symptomForm = this.fb.group({
      _id: [null, []],      
      name: ['', [Validators.required]],
      is_isolation: [false, []],
      isolation_days: ['', []]

    });
  }

 
   
  addSymptom() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.maxWidth = '700px';
    dialogConfig.panelClass = 'repeatDialog';
    dialogConfig.disableClose = true;
    dialogConfig.closeOnNavigation = true;
    this.dialogRefs = this.dialog.open(this.addSymptomEle, dialogConfig);
  }

  closeSymptomDialog(): void {
    this.dialogRefs.close();
    this.isEdit = false;
    this.isOptionField = false;
    this.symptomForm.reset();

    
  }



 

  async saveSymptomDialog(report, isValid) {
    console.log(">>>>",this.symptomForm.valid)
    if ( this.symptomForm.valid) {
      this._commonService.setLoader(true);
      const data = {
        '_id': this.symptomForm.controls._id.value,        
        'name': this.symptomForm.controls.name.value,
        'is_isolation': this.symptomForm.controls.is_isolation.value,
        'isolation_days': (this.symptomForm.controls.is_isolation.value && this.symptomForm.controls.isolation_days.value!='')?this.symptomForm.controls.isolation_days.value:0,
        
      };

      const action = {
        type: 'POST',
        target: 'symptoms/add'
      };
      const payload = data ;

     
      const result = await this.apiService.apiFn(action, payload);
      if (result['status']) {
        this.toastr.success(result['message']);
       
        this.closeSymptomDialog();
        this.getServerData(this.pagiPayload);
        this._commonService.setLoader(true);
        // this.dialogRefs.close();
      } else {
        this._commonService.setLoader(false);
        this.toastr.error(result['message']);
      }
    } else {
      this.toastr.error('Please fill all fields');
      this._commonService.setLoader(false);
    }
  }

  async editSymptom(symptomId){
    this.isEdit=true;
    this._commonService.setLoader(true);
      const action = {
        type: 'POST', target: 'symptoms/view'
      };
      const payload = { symptomId: symptomId };
      let result = await this.apiService.apiFn(action, payload)
      this.symptom = result['data']['_symptom'];
      this._commonService.setLoader(false);
     
      this.symptomForm.patchValue(this.symptom);
      this.addSymptom();

  }

  dropTable(event: CdkDragDrop<[]>) {
   // console.log("---", this.dataSource.filteredData)
    const prevIndex = this.dataSource.filteredData.findIndex((d) => d === event.item.data);
     const arr = {
      _id: event.item.data._id,
      previous_order: prevIndex + 1 + (this.pagiPayload.pageIndex * this.pagiPayload.pageSize),
      current_order: event.currentIndex + 1 + (this.pagiPayload.pageIndex * this.pagiPayload.pageSize)
    };
   if (prevIndex !== event.currentIndex) {

     // console.log("array",arr)
      this.exchangeOrder(arr);
    }

     moveItemInArray(this.dataSource.filteredData, prevIndex, event.currentIndex);
    this.table.renderRows();
  }

  async exchangeOrder(arr) {
    // this.loader = true;
       const data = {
        _id: arr._id,
        previous_order: arr.previous_order,
        current_order: arr.current_order
       };

       const action = {
         type: 'POST',
         target: 'symptoms/exchangeOrder'
       };
       const payload = data ;
 
       //console.log("data>>>>",payload)
       const result = await this.apiService.apiFn(action, payload);
      //  if (result['status']) {


      //  } else {

      //  }

   }
   async changeStatus(event, symptom_id) {
    const action = { type: 'POST', target: 'symptoms/changeStatus' };
    const payload = { 'status': event.checked, 'symptomId': symptom_id };
    const result = await this.apiService.apiFn(action, payload);
   // console.log("result of enable disable user",result);
  }

 
}


