import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './../shared/guard/auth.guard';
import { LayoutComponent } from './layout.component';

const routes: Routes = [
    {
        path: '',
        component: LayoutComponent,
        children: [
            {
                path: '',
                loadChildren: './login/login.module#LoginModule'
            },
            {
                path: 'login',
                loadChildren: './login/login.module#LoginModule'
            },
            {
                path: 'dashboard',
                loadChildren: './dashboard/dashboard.module#DashboardModule',
                canActivate: [AuthGuard]
            }
            , {
                path: 'beacons',
                loadChildren: './beacons/beacons.module#BeaconsModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'org',
                loadChildren: './org/org.module#OrgModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'users',
                loadChildren: './users/users.module#UsersModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'facility',
                loadChildren: './facility/facility.module#FacilityModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'floorsector',
                loadChildren: './floorsector/floorsector.module#FloorsectorModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'zones',
                loadChildren: './zones/zones.module#ZonesModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'residents',
                loadChildren: './residents/residents.module#ResidentsModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'technicalsupport',
                loadChildren: './technicalsupport/technicalsupport.module#TechnicalsupportModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'announcement',
                loadChildren: './announcement/announcement.module#AnnouncementModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'reports',
                loadChildren: './reports/reports.module#ReportsModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'scheduling',
                loadChildren: './scheduling/scheduling.module#SchedulingModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'open-visits',
                loadChildren: './open-visits/open-visits.module#OpenVisitsModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'cares',
                loadChildren: './cares/cares.module#CaresModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'createAQuestionnaire',
                loadChildren: './questionnaire/questionnaire.module#QuestionnaireModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'visitors',
                loadChildren: './visitors/visitors.module#VisitorsModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'nfc',
                loadChildren: './nfc/nfc.module#NfcModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'dashboardlink',
                loadChildren: './dashboardlink/dashboardlink.module#DashboardlinkModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'settings',
                loadChildren: './settings/settings.module#SettingsModule',
                canActivate: [AuthGuard]
            },
            {
                path: 'symptoms',
                loadChildren: './symptoms/symptoms.module#SymptomsModule',
                canActivate: [AuthGuard]
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
    providers: [AuthGuard]
})
export class LayoutRoutingModule { }
