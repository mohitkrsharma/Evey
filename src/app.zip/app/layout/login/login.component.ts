import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from 'src/app/shared/services/common.service';
import { ApiService } from '../../shared/services/api/api.service';
import { Store } from '@ngrx/store';

interface AppState {
  _authUser: number;
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  authState: Object;
  isSubmitted: Boolean;
  login = {
    username: '',
    password: '',
    web: true
  };

  otp = '';
  date = new Date();

  loginPage: Number = 1;
  otpPage: Number = 0;

  invalidOTP: Boolean = false;
  isshowPassword: Boolean;

  constructor(
    private _router: Router,
    private _toastr: ToastrService,
    private _apiService: ApiService,
    private _authStore: Store<AppState>,
    public _commonService: CommonService
  ) {
    this._authStore.select('authState').subscribe(sub => {
      this.authState = sub;
    });
    if (this.authState['client_key'] === undefined) {
      this._router.navigate(['/']);
    } else if (this.authState['client_key'] !== undefined) {
    } else {
      this._router.navigate(['/']);
    }
    if (this.authState['isLoggedin']) {
      this._commonService.setLoader(true);
      this._router.navigate(['/dashboard']);
    }
    this._commonService.setLoader(false);
  }

  ngOnInit() {
  }

  async onSubmit(f, login) {
    let vaild = f.form.status;
    login.username = login.username.trim();
    login.password = login.password.trim();
    if (login.username === '' || login.password === '') {
      vaild = 'INVALID';
    }
    if (vaild === 'VALID') {
      this._commonService.setLoader(true);
      const action = {
        type: 'LOGIN',
        target: 'login'
      };
      const payload = this.login;
      const result = await this._apiService.apiFn(action, payload);
      this._commonService.setLoader(false);
      if (result['status']) {
        const enable_livedashboard = result['data']['user']['enable_livedashboard'];
        sessionStorage.setItem('enable_livedashboard', enable_livedashboard);
        sessionStorage.setItem('user_Id', result['data']['user']['_id']);
        this.loginPage = 0;
        this.otpPage = 1;
        this._toastr.success('Please enter the OTP sent to your registered work email');
      } else {
        if (this._toastr.currentlyActive === 0) {
          this._toastr.error(result['message']);
        }
      }
    }
  }

  async onSubmitOTP(f, otp) {
    let vaild = f.form.status;
    if (otp === '') {
      vaild = 'INVALID';
    }
    if (otp.length < 4) {
      vaild = 'INVALID';
    }
    if (vaild === 'VALID') {
      this._commonService.setLoader(true);
      const action = { type: 'OTP', target: 'users/otp' };
      const payload = { otp: parseInt(this.otp) };
      const result = await this._apiService.apiFn(action, payload);
      if (result['status']) {
        this._router.navigate(['./dashboard']);
      } else {
        if (this._toastr.currentlyActive === 0) {
          this._toastr.error(result['message']);
        }
        this._commonService.setLoader(false);
      }
    }
  }

  checkNum(key) {
    const result = this._commonService.allwoNum(key);
    return result;
  }

  forgot() {
    this._commonService.setLoader(true);
    this._router.navigate(['./forgot']);
  }

  async resentOTP() {
    this._commonService.setLoader(true);
    const action = {
      type: 'POST',
      target: 'users/resendotp'
    };
    const payload = 'resendotp';
    const result = await this._apiService.apiFn(action, payload);
    if (result['status']) {
      this._toastr.success('OTP successfully resent on your work email');
    } else {
      this._toastr.error('Unable to send email. Please try again later.');
    }
    this._commonService.setLoader(false);
  }

  showPassword() {
    const x = document.getElementById('showpass');
    if (x['type'] === 'password') {
      x['type'] = 'text';
      this.isshowPassword = true;
    } else {
      x['type'] = 'password';
      this.isshowPassword = false;
    }
  }

  allwoAlphaNumLogin(key) {
    const result = this._commonService.allwoAlphaNumLogin(key);
    return result;
  }

}
