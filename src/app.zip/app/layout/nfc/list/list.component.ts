import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { MatTableDataSource, MatSort, PageEvent } from '@angular/material';
import { Router } from '@angular/router';
import { ApiService } from './../../../shared/services/api/api.service';
import { ExcelService } from './../../../shared/services/excel.service';
import { MatDialog } from '@angular/material/dialog';
import { AlertComponent } from '../../../shared/modals/alert/alert.component';
import { ToastrService } from 'ngx-toastr';
import * as moment from 'moment';
import { fromEvent } from 'rxjs';
import {
  debounceTime,
  map,
  distinctUntilChanged,
  filter,
  tap
} from 'rxjs/operators';
import { Subscription } from 'rxjs/Rx';
import { CommonService } from './../../../shared/services/common.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {

  public btnAction: Function;
  public filtershow = false;
  // MATPAGINATOR
  pageIndex: number;
  pageSize: number;
  length: number;
  checked;
  deleteArr = [];
  deleteItem = [];
  data;
  arr = [];
  dataSource;
  count;
  displayedColumns = [];
  organization; facility;
  // ddp list variable
  organiz;
  fac_list;
  loader = false;
  sortActive = 'name';
  sortDirection: 'asc' | 'desc' | '';
  search: any;
  @ViewChild('deleteButton') private deleteButton: ElementRef;
  pagiPayload: PagiElement = {
    length: 0,
    pageIndex: 0,
    pageSize: 10,
    previousPageIndex: 0,
    search: ''
  };

  bulkorg; bulkfac;
  actualDataCount;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('searchInput') searchInput: ElementRef;
  userIds = [];
  columnNames = [
    {
      id: 'ntagid',
      value: 'NFC Id',
      sort: true
    },
    {
      id: 'organization',
      value: 'Organization',
      sort: true
    },
    {
      id: 'facility',
      value: 'Facility',
      sort: true
    },
    {
      id: 'zone',
      value: 'Zone',
      sort: true
    },
    {
      id: 'Floor',
      value: 'Floor',
      sort: true
    },
    {
      id: 'sector',
      value: 'Sector',
      sort: true
    }
  ];
  private subscription: Subscription;

  constructor(
    private router: Router,
    private apiService: ApiService,
    private excelService: ExcelService,
    public dialog: MatDialog,
    private toastr: ToastrService,
    public commonService: CommonService
  ) { }

  exportdata; filedata; floor; sector;
  org_name; faclist; floorlist; fac_name; seclist; floor_name;
  public show = false;

  async ngOnInit() {
    this.loader = true;
    if (sessionStorage.getItem('pageListing')) {
      const pageListing = JSON.parse(sessionStorage.getItem('pageListing'));
      if (pageListing.nfcList) {
        this.pagiPayload.previousPageIndex = pageListing.nfcList.previousPageIndex;
        this.pagiPayload.pageIndex = pageListing.nfcList.pageIndex;
        this.pagiPayload.pageSize = pageListing.nfcList.pageSize;
        this.pagiPayload.length = pageListing.nfcList.length;
      } else {
        sessionStorage.setItem('pageListing', JSON.stringify({ nfcList: this.pagiPayload }));
      }
    } else {
      sessionStorage.setItem('pageListing', JSON.stringify({ nfcList: this.pagiPayload }));
    }

    this.search = this.searchInput.nativeElement.value;
    fromEvent(this.searchInput.nativeElement, 'keyup')
      .pipe(
        // tslint:disable-next-line:max-line-length
        debounceTime(2000), // The user can type quite quickly in the input box, and that could trigger a lot of server requests. With this operator, we are limiting the amount of server requests emitted to a maximum of one every 150ms
        distinctUntilChanged(), // This operator will eliminate duplicate values
        tap(() => {
          this.getServerData(this.pagiPayload);
        })
      )
      .subscribe();
    this.displayedColumns = this.displayedColumns.concat(['checkbox']);
    this.displayedColumns = this.displayedColumns.concat(this.columnNames.map(x => x.id));
    this.displayedColumns = this.displayedColumns.concat(['actions']);
    this.subscription = this.commonService.contentdata.subscribe(async (contentVal: any) => {
      if (contentVal.org && contentVal.fac) {
        this.loader = true;
        this.floor = null;
        this.sector = null;
        this.seclist = null;

        this.floorlist = contentVal.floorlist;
        this.organization = this.pagiPayload['organization'] = contentVal.org;
        this.facility = this.pagiPayload['facility'] = contentVal.fac;
        // Pagination
        this.getServerData(this.pagiPayload);
      }
    });

    this.subscription = this.commonService.floorcontentdata.subscribe(async (data: any) => {
      if (data) {
        this.floorlist = data;
      }
    });
  }


  // Create mat table
  createTable(arr) {
    const tableArr: Element[] = arr;
    this.dataSource = new MatTableDataSource(tableArr);
  }


  // Open add NFC form
  addNfcFormFn() {
    this.router.navigate(['/nfc/form']);
  }

  // Open edit NFC form
  editNfcFn(id) {
    this.router.navigate(['/nfc/form', id]);
  }

  // View data for a particluar nfc
  viewNfcFn(id) {
    this.router.navigate(['/nfc/view', id]);
  }


  // Function to delete single nfc
  deleteNfcFn(id) {
    this.deleteArr = [];
    const dialogRef = this.dialog.open(AlertComponent, {
      width: '350px',
      data: { 'title': 'nfc', 'id': id, 'API': 'nfc/delete' }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result && result['status']) {
        this.toastr.success(result['message']);
        this.checked = false;
        this.getServerData(this.pagiPayload);
      }
    });
  }


  // function  to delete multiple NFCs
  delete() {
    if (this.deleteArr.length === 0) {
      if (this.toastr.currentlyActive === 0) {
        this.toastr.error('Please select nfc to be deleted');
        this.checked = false;
      }
    } else {
      const dialogRef = this.dialog.open(AlertComponent, {
        width: '350px',
        data: { 'title': 'nfc', 'id': this.deleteArr, 'API': 'nfc/delete' }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result && result['data']['success']) {
          this.toastr.success(result['message']);
          this.getServerData(this.pagiPayload);
          this.checked = false;
        } else {
          this.data.forEach(element => {
            element.checked = false;
            this.checked = false;
          });
          this.deleteArr = [];
        }

        document.getElementById('searchInput').focus();
        document.getElementById('searchInput').blur();
      });
    }
  }

  // Select all Checkboxes in a list
  selectAll() {
    if (this.checked === true) {
      this.data.forEach(element => {
        element.checked = false;
        this.deleteArr = [];
      });
    } else {
      this.data.forEach(element => {
        this.deleteArr.push(element._id);
        element.checked = true;
      });
    }
  }

  // Select single checkbox one by one
  selectElement(id, check) {
    if (check === true) {
      for (let i = 0; i < this.deleteArr.length; i++) {
        if (this.deleteArr[i] === id) {
          this.deleteArr.splice(i, 1);
        }
      }
    } else if (check === undefined || check === false) {
      this.deleteArr.push(id);
    }
    if ((this.deleteArr && this.deleteArr.length) < this.actualDataCount) {
      this.checked = false;
    } else if ((this.deleteArr && this.deleteArr.length) === this.actualDataCount) {
      this.checked = true;
    }
  }

  // Search element in a list
  onChange(item, event) {
    this.search = item;
    setTimeout(() => {
      this.getServerData(this.pagiPayload);
    }, 2000);
  }


  // Fetch list of NFCs added
  public async getNFCDataFunction() {
    const action = {
      type: 'GET',
      target: 'nfc'
    };
    const payload = this.pagiPayload;
    let result = await this.apiService.apiFn(action, payload);

    this.count = result['data']['_count'];
    if (result['status']) {
      const dataNFC = result['data']['_nfc'];
      if (dataNFC && dataNFC.length > 0) {
        this.actualDataCount = dataNFC.length;
      }
      result = result['data']['_nfc'].map(item => {
        let sec;
        if (item.floor && item.floor.sector) {
          sec = item.floor.sector.filter(it => it._id === item.sector);
          if (sec.length) {
            sec = sec[0].name ? sec[0].name : '--';
          }
        }
        return {
          ...item,
          ntagid: item.ntagid ? item.ntagid : '--',
          organization: item.org ? item['org']['org_name'] : '--',
          facility: item.fac ? item['fac']['fac_name'] : '--',
          zone: item.room ? item['room']['room'] : '--',
          Floor: item.floor ? item.floor.floor : '--',
          sector: item.floor && item.floor.sector.length ? sec : '--'

        };
      });
      this.data = result;
      this.createTable(result);
      this.loader = false;
    }
  }

  // Sorting in NFC listing
  sortData(sort?: PageEvent) {
    if (sort['direction'] === '') {
      this.sort.active = sort['active'];
      this.sort.direction = 'asc';
      this.sort.sortChange.emit({ active: sort['active'], direction: 'asc' });
      this.sort._stateChanges.next();
      return;
    }
    this.loader = true;
    this.pagiPayload['sort'] = sort;
    sessionStorage.setItem('pageListing', JSON.stringify({ nfcList: this.pagiPayload }));
    this.getNFCDataFunction();
  }

  // Set payload for pagination,searching,sorting
  public async getServerData(event?: PageEvent) {
    this.pagiPayload.previousPageIndex = event.previousPageIndex;
    this.pagiPayload.pageIndex = event.pageIndex;
    this.pagiPayload.pageSize = event.pageSize;
    this.pagiPayload.length = event.length;
    this.pagiPayload.search = this.search;
    this.pagiPayload['organization'] = this.organization;
    this.pagiPayload['facility'] = this.facility;
    sessionStorage.setItem('pageListing', JSON.stringify({ nfcList: this.pagiPayload }));
    this.getNFCDataFunction();
  }

  // Function to export NFC listin in excel sheet
  async exportNFC() {
    this.loader = true;
    const action = {
      type: 'GET',
      target: 'nfc/export'
    };
    const payload = this.pagiPayload;
    let result = await this.apiService.apiFn(action, payload);

    if (result['status']) {
      const data = result['data'];
      this.exportdata = data;
      const nfc = this.prepareUsersForCSV();
      this.excelService.exportAsExcelFile(nfc, 'NFC_Report');
    }
  }

  // Excel sheet preparation
  prepareUsersForCSV() {
    const users = [];
    this.exportdata.forEach(item => {
      let sec;
      if (item.floor && item.floor.sector) {
        sec = item.floor.sector.filter(it => it._id === item.sector);
        if (sec.length) {
          sec = sec[0].name;
        }
      }
      users.push({
        'NFC ID': item.ntagid ? item.ntagid : '-',
        'Organization': item['org'] ? item['org']['org_name'] : '-',
        'facility': item['fac'] ? item['fac']['fac_name'] : '-',
        'Floor': item['floor'] ? item['floor']['floor'] : '-',
        'Sector': item['floor'] ? sec : '-',
        'Zone': item['room'] ? item['room']['room'] : '-',
        'Resident': item['resident'] ? item['resident']['first_name'] + ' ' + item['resident']['last_name'] : '-',
        'Created Date': item.date ? moment(item.date).format('MMMM Do YYYY') : '-'

      });
    });
    this.loader = false;
    return users;
  }

  // Show/hide filter fields
  filter() {
    this.show = !this.show;
    this.floor = '';
    this.sector = '';
    delete this.pagiPayload['org_name'];
    delete this.pagiPayload['fac_name'];
    delete this.pagiPayload['floor'];
    delete this.pagiPayload['sector'];
  }

  // Reset filter data fro list
  resetFilter() {
    this.show = false;
    this.floor = '';
    this.sector = '';
    delete this.pagiPayload['org_name'];
    delete this.pagiPayload['fac_name'];
    delete this.pagiPayload['floor'];
    delete this.pagiPayload['sector'];
    this.getServerData(this.pagiPayload);
  }

  // Fetch sector for a particular floor
  async changeFloor(floor, type) {
    this.sector = '';
    delete this.pagiPayload['sector'];
    this.pagiPayload = {
      length: 0,
      pageIndex: 0,
      pageSize: 10,
      previousPageIndex: 0,
      search: this.search
    };
    const _secList = [];
    this.seclist = this.floorlist.map(function (it) {
      if (it.value === floor.value) {
        it['sector'].map(function (item) {
          _secList.push(item);
        });
      }
    });
    this.seclist = _secList.map(function (obj) {
      const rObj = {};
      rObj['label'] = obj.name;
      rObj['value'] = obj._id;
      return rObj;
    });
    this.floor_name = floor.value;
    this.pagiPayload['floor'] = this.floor_name;
    this.pagiPayload['fac_name'] = this.fac_name;
    this.pagiPayload['org_name'] = this.org_name;
    delete this.pagiPayload['sector'];
    if (type === 'filter') {
      this.getServerData(this.pagiPayload);
    }

  }

  // function to change sector in filter
  async changeSector(sector, type) {
    this.pagiPayload['sector'] = sector.value;
    this.getServerData(this.pagiPayload);

  }

}

export interface Element {
  position: number;
  name: string;
  weight: number;
  symbol: string;
}

export interface PagiElement {
  length: number;
  pageIndex: number;
  pageSize: number;
  previousPageIndex: number;
  search: '';
}
