import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from './../../../shared/services/api/api.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})

export class ViewComponent implements OnInit {
  nfcObj;
  loader = false;
  id;
  nfc;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private apiService: ApiService,
  ) {
  }

  async ngOnInit() {
    this.loader = true;
    this.id = this.route.params['_value']['id'];
    const action = { type: 'POST', target: 'nfc/view' };
    const payload = { nfcId: this.id };
    const result = await this.apiService.apiFn(action, payload);

    this.nfc = result['data'];
    let sec;
    if (result['data'].floor && result['data'].floor.sector) {
      sec = result['data'].floor.sector.filter(it => it._id === result['data'].sector);
      if (sec.length) {
        sec = sec[0].name ? sec[0].name : '--';
      }
    }
    this.nfc['sector'] = result['data'].floor && result['data'].floor.sector.length ? sec : '--';
    this.loader = false;
  }

  editNFC() {
    this.router.navigate(['/nfc/form', this.route.params['_value']['id']]);
  }

  cancel() {
    this.router.navigate(['/nfc']);
  }

}
