import { Component, OnInit, ViewChild, TemplateRef, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from './../../../shared/services/api/api.service';
import { ToastrService } from 'ngx-toastr';
import { MatSort, MatTableDataSource } from '@angular/material';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { AlertComponent } from '../../../shared/modals/alert/alert.component';
import { CommonService } from './../../../shared/services/common.service';
import { MatOption } from '@angular/material';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTable } from '@angular/material/table';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent implements OnInit {
  alternateCare;
  dialogRefs = null;

  dataSource;
  dataSource1;
  @ViewChild('table') table: MatTable<any>;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('addQuestion') addQuestion: TemplateRef<any>;
  @ViewChild('typeSector') private typeSector: MatOption;
  @ViewChild('deleteButton') private deleteButton: ElementRef;
  count;
  pagiPayload = {
    length: 0,
    pageIndex: 0,
    pageSize: 99999999,
    previousPageIndex: 0,
    parentCareId: ''
  };
  data;
  data1;
  actualDataCount;
  actualDataCount1;
  displayedColumns = [];
  displayedColumns1 = [];
  deleteItem = [];
  deleteItem1 = [];
  deleteArr = [];
  deleteArr1 = [];
  /**
    * Pre-defined columns list for user table
    */
  columnNames = [
    {
      id: 'name',
      value: 'Name',
      sort: true
    }
    , {
      id: 'default_selection',
      value: 'Selection',
      sort: false
    }
    , {
      id: 'default_value',
      value: 'Default Value',
      sort: true
    },
    {
      id: 'order',
      value: 'Order',
      sort: true
    },
    {
      id: 'type',
      value: 'Type',
      sort: true
    }];

  columnNames1 = [
    {
      id: 'question',
      value: 'Question',
      sort: false
    }, {
      id: 'type',
      value: 'Question Type',
      sort: false
    }
  ];

  isEdit = false;
  careArray = [];
  finalCareArray: any = [];

  show = false;
  care: any;

  public Question_Types: any = [
    {
      'type': 'checkbox',
      'name': 'Multiple choice'
    }, {

      'type': 'date',
      'name': 'Date Picker'
    }, {

      'type': 'radio',
      'name': 'Radio'
    }, {

      'type': 'select',
      'name': 'Dropdown'
    }, {
      'type': 'text',
      'name': 'Input'
    }, {
      'type': 'textarea',
      'name': 'Text area'
    }];
  isOptionField: boolean;
  question: any = {
    type: '',
    question: '',
    field_label: this.fb.array([
      this.setInputType(),
    ]),
  };
  questionForm: FormGroup;
  public temparray: any = [];
  editId: any = null;
  btnClass: string;
  showQuestion = false;
  checked = false;
  checked1 = false;


  constructor(private route: ActivatedRoute,
    private router: Router,
    private toastr: ToastrService,
    private apiService: ApiService,
    public dialog: MatDialog,
    private fb: FormBuilder,
    public _commonService: CommonService
    ) {
      this.createPropertyForm();
    }



  async ngOnInit() {

    this.displayedColumns = this.displayedColumns.concat(['checkbox']);
    this.displayedColumns = this.displayedColumns.concat(['icon']);
    this.displayedColumns = this.displayedColumns.concat(this.columnNames.map(x => x.id));
    this.displayedColumns = this.displayedColumns.concat(['actions']);
    this.displayedColumns1 = this.displayedColumns1.concat(['checkbox']);
    this.displayedColumns1 = this.displayedColumns1.concat(['position']);
    this.displayedColumns1 = this.displayedColumns1.concat(this.columnNames1.map(x => x.id));
    this.displayedColumns1 = this.displayedColumns1.concat(['change_status']);
    this.displayedColumns1 = this.displayedColumns1.concat(['actions']);

    this.route.params.subscribe(async param => {
      // console.log("this")
      this._commonService.setLoader(true);
      const id = param['id'];
      this.pagiPayload.parentCareId = id;
      const action = { type: 'POST', target: 'cares/view' };
      const payload = { careId: id };
      const result = await this.apiService.apiFn(action, payload);
      this.care = result['data'];

      // tslint:disable-next-line: max-line-length
      if (this.care.type === 'special' || this.care.type === 'special_input' || this.care.type === 'list' || this.care.type === 'room_cleaning' || this.care.type === 'restroom' || this.care.type === 'virus' || this.care.type === 'vital' ) {
        await this.load_careoutcome();
        await this.getCaresDataFunction();

        this.show = true;
        if (this.care.type === 'virus') {
          await this.getCaresQuestionsFunction();
          this.showQuestion = true;

        }

      } else {
        const alternative_outcomes = this.care['alternative_outcomes'].map(itm => itm.displayName ? itm.displayName : '-');
        this.care.alternative_outcomes = this.care['alternative_outcomes'] ? (alternative_outcomes).toString().replace(/,/g, ', ') : '-';
        this.show = false;
        this.showQuestion = false;
      }
      this._commonService.setLoader(false);

    });

    // this.questionForm = this.fb.group({ // Question form
    //   _id:[null, []],
    //   care_id: ['', [Validators.required]],
    //   type: ['', [Validators.required]],
    //   question: ['', [Validators.required]]

  }

  createTable(arr) {
    const tableArr: Element[] = arr;
    this.dataSource = new MatTableDataSource(tableArr);
  }

  createTable1(arr) {
    const tableArr: Element[] = arr;
    this.dataSource1 = new MatTableDataSource(tableArr);
  }

  async load_careoutcome() {
    const action = {
      type: 'GET', target: 'cares/getcareoutcome'
    };
    const payload = {};
    const result = await this.apiService.apiFn(action, payload);

    this.alternateCare = result['data'].reduce((obj, item, index) => {
      obj.push({ key: item._id, value: item.displayName });
      return obj;
    }, []);
    this.careArray = this.alternateCare;
  }

  select_alt_outcome(event) {
    const record = this.careArray.find((i) => i.key === event);
    if (this.finalCareArray && this.finalCareArray.length > 0) {
      if (this.finalCareArray.find((i) => i.key === event) === record) {
        for (let i = 0; i < this.finalCareArray.length; i++) {
          if (this.finalCareArray[i].key === record.key) {
            this.finalCareArray.splice(i, 1);
          }
        }
      } else {
        this.finalCareArray.push(record);
      }
    } else {
      this.finalCareArray.push(record);
    }
  }

  cancelForm() {
    this.router.navigate(['/cares']);
  }

  editCare(id) {
    this.router.navigate(['/cares/form', id]);
  }
  addSubCare(id) {
    this.router.navigate(['/cares/form/subcare', id]);
  }

  viewCare(id) {
    this.router.navigate(['/cares/view', id]);
  }

  deleteCare(id) {
    const _arr = [id];
    const dialogRef = this.dialog.open(AlertComponent, {
      width: '350px',
      data: { 'title': 'cares', 'id': _arr, 'API': 'cares/delete' }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result !== false) {
        if (result['status']) {
          this.toastr.success(result['message']);
        }
        this.getCaresDataFunction();
      }

    });
  }

  public async getCaresDataFunction() {
    this._commonService.setLoader(true);
    const action = {
      type: 'GET',
      target: 'cares'
    };
    const payload = this.pagiPayload;
    let result = await this.apiService.apiFn(action, payload);
    this.count = result['data']['_count'];
    if (result['status']) {
      result = result['data']['_cares'].map(item => {
        return {
          ...item,
          icon: item.icon && item.icon !== undefined ? item.icon : '',
          name: item.name,
          default_selection: item.default_selection ? item.default_selection.displayName : '-',
          default_value: item.default_value ? item.default_value : '-',
          order: item.order,
          type: item.type
        };
      });
      this.data = result;
      if (this.data && this.data.length > 0) {
        this.actualDataCount = this.data.length;
      }
      this.createTable(result);
      this._commonService.setLoader(false);
    }
    this._commonService.setLoader(false);
  }
  get optionsPoints() {
    return this.questionForm.get('options') as FormArray;
  }


  selectAll() {
    if (this.checked === true) {
      this.data.forEach(element => {
        element.checked = false;
        this.deleteArr = [];
      });
    } else {
      this.data.forEach(element => {
        this.deleteArr.push(element._id);
        element.checked = true;
      });
    }
  }
  selectElement(id, check) {
    if (check === true) {
      for (let i = 0; i < this.deleteArr.length; i++) {
        if (this.deleteArr[i] === id) {
          this.deleteArr.splice(i, 1);
        }
      }
    } else if (check === undefined || check === false) {
      this.deleteArr.push(id);
    }
    if ((this.deleteArr && this.deleteArr.length) < this.actualDataCount) {
      this.checked = false;
    } else if ((this.deleteArr && this.deleteArr.length) === this.actualDataCount) {
      this.checked = true;
    }
  }
  delete() {
    if (this.deleteArr.length === 0) {
      this.toastr.error('Please select sub Care to be deleted');
      this.checked = false;
    } else {
      const dialogRef = this.dialog.open(AlertComponent, {
        width: '350px',
        data: { 'title': 'cares', 'id': this.deleteArr, 'API': 'cares/delete' }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (!result) {
          this.data.forEach(element => {
            element.checked = false;
            this.checked = false;
          });
          this.deleteArr = [];
        } else {
          if (result['status']) {
            this.toastr.success(result['message']);
          }
          this.checked = false;
          this.getCaresDataFunction();
        }
        this.deleteButton['_elementRef'].nativeElement.classList.remove('cdk-program-focused');
        this.deleteButton['_elementRef'].nativeElement.classList.remove('cdk-focused');

      });
    }

  }
  createPropertyForm() {
    this.questionForm = this.fb.group({
      _id: [null, []],
      care_id: ['', [Validators.required]],
      type: ['', [Validators.required]],
      question: ['', [Validators.required]],
      options: this.fb.array([
        this.setInputType(),
      ])

    });
  }

  /* Add multiple input to the form */
  setInputType() {
    return this.fb.group({
      label: ['', []],
    });
  }

  /* Add option for Radio, Dropdown and Multi Checkboxes */
  addOption() {
    this.temparray = <FormArray>this.questionForm.controls['options'];

    this.temparray.push(this.setInputType());
  }

  /* Remove option for Radio, Dropdown and Multi Checkboxes */
  removeOption(key) {
    this.temparray = <FormArray>this.questionForm.controls['options'];
    this.temparray.removeAt(key);

  }
  addquestion() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.maxWidth = '700px';
    dialogConfig.panelClass = 'repeatDialog';
    dialogConfig.disableClose = true;
    dialogConfig.closeOnNavigation = true;
    this.dialogRefs = this.dialog.open(this.addQuestion, dialogConfig);
  }

  closeQuestionDialog(): void {
    this.dialogRefs.close();
    this.isEdit = false;
    this.isOptionField = false;
    this.questionForm.reset();
    this.temparray = <FormArray>this.questionForm.controls['options'];
    for (let i = this.temparray.length - 1; i >= 2; i--) {
      this.temparray.removeAt(i);
    }

  }



  getFieldType(event = '') {
    if (this.question.type === 'radio' || this.question.type === 'select' || this.question.type === 'checkbox') {
      this.btnClass = this.question.type + 'btn';
      this.isOptionField = true;
      this.temparray = <FormArray>this.questionForm.controls['options'];
      if (this.temparray.length < 2) {
        this.temparray.push(this.setInputType());
      }
    } else {
      this.isOptionField = false;
      this.btnClass = '';
      this.temparray = [this.setInputType()];

    }
  }

  public async getCaresQuestionsFunction() {
    this._commonService.setLoader(true);
    const action = {
      type: 'GET',
      target: 'questions'
    };
    const payload = this.pagiPayload;
    let result = await this.apiService.apiFn(action, payload);
    // console.log("result>>",result['data'])
    // console.log("result")
    this.count = result['data']['_count'];

    if (result['status'] && this.count > 0) {
      result = result['data']['_questions'].map(item => {
        return {
          ...item,
          type: this.questionType(item.type),
          care_id: item.care_id,
          question: item.question,
          order: item.order
        };
      });
      this.data1 = result;
      if (this.data1 && this.data1.length > 0) {
        this.actualDataCount1 = this.data1.length;
      }

      this.createTable1(result);
      this._commonService.setLoader(false);
    } else {
      this.data1 = [];
      this.actualDataCount1 = 0;
      this.createTable1([]);
    }
    this._commonService.setLoader(false);
  }
  async saveQuestionDialog(report, isValid) {
    this.questionForm.controls.care_id.patchValue(this.pagiPayload.parentCareId);

    if (this.questionForm.valid) {
      this._commonService.setLoader(true);
      const data = {
        '_id': this.questionForm.controls._id.value,
        'type': this.questionForm.controls.type.value,
        'question': this.questionForm.controls.question.value,
        'care_id': this.questionForm.controls.care_id.value,
        'options': (this.isOptionField) ? this.questionForm.controls.options.value : [],
      };

      const action = {
        type: 'POST',
        target: 'questions/add'
      };
      const payload = data;

      const result = await this.apiService.apiFn(action, payload);
      console.log('result>>', result )
      if (result['status']) {
        this.toastr.success(result['message']);

        this.closeQuestionDialog();
        this.getCaresQuestionsFunction();
        this._commonService.setLoader(true);
      } else {
        this._commonService.setLoader(false);
        this.toastr.error(result['message']);
      }
    } else {
      this.toastr.error('Please fill all fields');
      this._commonService.setLoader(false);
    }
  }

  async editQuestion(questionId) {
    this.isEdit = true;
    this._commonService.setLoader(true);
    const action = {
      type: 'POST', target: 'questions/view'
    };
    const payload = { questionId: questionId };
    const result = await this.apiService.apiFn(action, payload)
    this.question = result['data']['_question'];
    this._commonService.setLoader(false);
    // console.log("herer>>>>",this.question)

    this.temparray = <FormArray>this.questionForm.controls['options'];
    //  console.log("length>>>",this.temparray.length )
    // this.temparray.push(this.setInputType());

    if (this.question.options.length > 1) {
      this.question.options.forEach((element, ind) => {

        if (ind >= this.temparray.length) {
          this.addOption();
        }

      });
    }
    this.questionForm.patchValue(this.question);
    this.getFieldType();
    this.addquestion();

  }

  deleteQuestion(id) {
    const _arr = [id];
    const dialogRef = this.dialog.open(AlertComponent, {
      width: '350px',
      data: { 'title': 'question', 'id': _arr, 'API': 'questions/delete' }
    });
    dialogRef.afterClosed().subscribe(result => {

      if (result != false) {
        if (result['status']) {
          this.toastr.success(result['message']);
        }
        this.getCaresQuestionsFunction();
      }

    });
  }
  selectAllQues() {
    if (this.checked1 === true) {
      this.data1.forEach(element => {
        element.checked = false;
        this.deleteArr1 = [];
      });
    } else {
      this.data1.forEach(element => {
        this.deleteArr1.push(element._id);
        element.checked = true;
      });
    }
  }
  selectElementQues(id, check) {
    if (check === true) {
      for (let i = 0; i < this.deleteArr1.length; i++) {
        if (this.deleteArr1[i] === id) {
          this.deleteArr1.splice(i, 1);
        }
      }
    } else if (check === undefined || check === false) {
      this.deleteArr1.push(id);
    }
    if ((this.deleteArr1 && this.deleteArr1.length) < this.actualDataCount1) {
      this.checked1 = false;
    } else if ((this.deleteArr1 && this.deleteArr1.length) === this.actualDataCount1) {
      this.checked1 = true;
    }
  }
  deleteQues() {
    if (this.deleteArr1.length === 0) {
      this.toastr.error('Please select question to be deleted');
      this.checked1 = false;
    } else {
      const dialogRef = this.dialog.open(AlertComponent, {
        width: '350px',
        data: { 'title': 'cares', 'id': this.deleteArr1, 'API': 'questions/delete' }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (!result) {
          this.data1.forEach(element => {
            element.checked = false;
            this.checked1 = false;
          });
          this.deleteArr1 = [];
        } else {
          if (result['status']) {
            this.toastr.success(result['message']);
          }
          this.checked1 = false;
          this.getCaresQuestionsFunction();
        }
        this.deleteButton['_elementRef'].nativeElement.classList.remove('cdk-program-focused');
        this.deleteButton['_elementRef'].nativeElement.classList.remove('cdk-focused');

      });
    }

  }
  dropTable(event: CdkDragDrop<[]>) {
    const prevIndex = this.dataSource1.filteredData.findIndex((d) => d === event.item.data);
    const arr = {
      _id: event.item.data._id,
      previous_order: prevIndex + 1 + (this.pagiPayload.pageIndex * this.pagiPayload.pageSize),
      current_order: event.currentIndex + 1 + (this.pagiPayload.pageIndex * this.pagiPayload.pageSize)

    };
    if (prevIndex !== event.currentIndex) {
      this.exchangeOrder(arr);
    }

    moveItemInArray(this.dataSource1.filteredData, prevIndex, event.currentIndex);
    this.table.renderRows();
  }

  async exchangeOrder(arr) {
    const data = {
      care_id: this.pagiPayload.parentCareId,
      _id: arr._id,
      previous_order: arr.previous_order,
      current_order: arr.current_order
    };

    const action = {
      type: 'POST',
      target: 'questions/exchangeOrder'
    };
    const payload = data;
    const result = await this.apiService.apiFn(action, payload);

  }

  async changeStatus(event, question_id) {
    const action = { type: 'POST', target: 'questions/changeStatus' };
    const payload = { 'status': event.checked, 'questionId': question_id };
    const result = await this.apiService.apiFn(action, payload);
  }

  questionType(type) {
    const ind = this.Question_Types.findIndex(item => item.type === type);
    if (ind > -1) {
      return this.Question_Types[ind].name;
    }
  }
}

export interface PagiElement {
  length: number;
  pageIndex: number;
  pageSize: number;
  previousPageIndex: number;
  parentCareId: string;
}

export interface PagiElement {
  length: number;
  pageIndex: number;
  pageSize: number;
  previousPageIndex: number;
  search: '';
}
