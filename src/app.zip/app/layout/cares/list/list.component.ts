import { Component, OnInit, ViewChild, HostListener, ElementRef } from '@angular/core';
import { MatTableDataSource, MatSort, PageEvent } from '@angular/material';
import { Router } from '@angular/router';
import { ApiService } from './../../../shared/services/api/api.service';
import { AlertComponent } from '../../../shared/modals/alert/alert.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ExcelService } from './../../../shared/services/excel.service';
import { CommonService } from './../../../shared/services/common.service';
import { ToastrService } from 'ngx-toastr';
import { fromEvent } from 'rxjs';
import {
  debounceTime,
  map,
  distinctUntilChanged,
  filter,
  tap
} from 'rxjs/operators';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {

  constructor(
    private router: Router,
    private apiService: ApiService,
    public dialog: MatDialog,
    private excelService: ExcelService,
    private toastr: ToastrService,
    public _commonService: CommonService
  ) { }
  @ViewChild('searchInput') searchInput: ElementRef;
  @ViewChild('deleteButton') private deleteButton: ElementRef;
  public btnAction: Function;

  // MATPAGINATOR
  datasource: null;
  pageIndex: number;
  pageSize: number;
  length: number;
  checked;
  deleteArr = [];
  deleteItem = [];
  data;
  dataSource;
  isShow: boolean;
  topPosToStartShowing = 100;
  displayedColumns = [];
  organiz; floorlist; faclist;
  @ViewChild(MatSort) sort: MatSort;
  sortActive = 'name';
  sortDirection: 'asc' | 'desc' | '';
  count;
  actualDataCount;
  search: any;
  /**
   * Pre-defined columns list for user table
   */
  columnNames = [

    {
      id: 'name',
      value: 'Name',
      sort: true
    }
    , {
      id: 'default_selection',
      value: 'Selection',
      sort: false
    }
    , {
      id: 'default_value',
      value: 'Default Value',
      sort: true
    },
    {
      id: 'order',
      value: 'Order',
      sort: true
    },
    {
      id: 'type',
      value: 'Type',
      sort: true
    }];
  exportdata;
  pagiPayload = {
    length: 0,
    pageIndex: 0,
    pageSize: 10,
    previousPageIndex: 0,
    search: ''
  };
  public show = false;
  @HostListener('window:scroll')
  checkScroll() {

    // window의 scroll top
    // Both window.pageYOffset and document.documentElement.scrollTop returns the same result in all the cases. window.pageYOffset is not supported below IE 9.

    const scrollPosition = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;

    if (scrollPosition >= this.topPosToStartShowing) {
      this.isShow = true;
    } else {
      this.isShow = false;
    }
  }

  // TODO: Cross browsing
  gotoTop() {
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }
  ngOnInit() {
    if (sessionStorage.getItem('pageListing')) {
      const pageListing = JSON.parse(sessionStorage.getItem('pageListing'));
      if (pageListing.careList) {
        this.pagiPayload = pageListing.careList;
      } else {
        sessionStorage.setItem('pageListing', JSON.stringify({ careList: this.pagiPayload }));
      }
    } else {
      sessionStorage.setItem('pageListing', JSON.stringify({ careList: this.pagiPayload }));
    }
    this.search = this.searchInput.nativeElement.value;
    fromEvent(this.searchInput.nativeElement, 'keyup')
      .pipe(
        debounceTime(2000),
        distinctUntilChanged(),
        tap(() => {
          this.getServerData(this.pagiPayload);
        })
      )
      .subscribe();
    this.btnAction = this.addForm.bind(this);
    this.displayedColumns = this.displayedColumns.concat(['checkbox']);
    this.displayedColumns = this.displayedColumns.concat(['icon']);
    this.displayedColumns = this.displayedColumns.concat(this.columnNames.map(x => x.id));

    this.displayedColumns = this.displayedColumns.concat(['actions']);
    // Pagination
    this.getServerData(this.pagiPayload);
  }

  selectAll() {
    if (this.checked === true) {
      this.data.forEach(element => {
        element.checked = false;
        this.deleteArr = [];
      });
    } else {
      this.data.forEach(element => {
        this.deleteArr.push(element._id);
        element.checked = true;
      });
    }
  }

  selectElement(id, check) {
    if (check === true) {
      for (let i = 0; i < this.deleteArr.length; i++) {
        if (this.deleteArr[i] === id) {
          this.deleteArr.splice(i, 1);
        }
      }
    } else if (check === undefined || check === false) {
      this.deleteArr.push(id);
    }
    if ((this.deleteArr && this.deleteArr.length) < this.actualDataCount) {
      this.checked = false;
    } else if ((this.deleteArr && this.deleteArr.length) === this.actualDataCount) {
      this.checked = true;
    }
  }

  delete() {
    if (this.deleteArr.length === 0) {
      this.toastr.error('Please select Care to be deleted');
      this.checked = false;
    } else {
      const dialogRef = this.dialog.open(AlertComponent, {
        width: '350px',
        data: { 'title': 'cares', 'id': this.deleteArr, 'API': 'cares/delete' }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (!result) {
          this.data.forEach(element => {
            element.checked = false;
            this.checked = false;
          });
          this.deleteArr = [];
        } else {
          if (result['status']) {
            this.toastr.success(result['message']);
          }
          this.checked = false;
          this.getServerData(this.pagiPayload);
        }
        this.deleteButton['_elementRef'].nativeElement.classList.remove('cdk-program-focused');
        this.deleteButton['_elementRef'].nativeElement.classList.remove('cdk-focused');
        document.getElementById('searchInput').focus();
        document.getElementById('searchInput').blur();
      });
    }

  }

  createTable(arr) {
    const tableArr: Element[] = arr;
    this.dataSource = new MatTableDataSource(tableArr);
  }

  addForm() { // Custom-code!
    this.router.navigate(['/cares/form']);
  }

  viewCare(id) {
    this.router.navigate(['/cares/view', id]);
  }

  editCare(id) {
    this.router.navigate(['/cares/form', id]);
  }

  async toggle() {
    this.show = !this.show;
  }

  async changeName(name) {
  }

  async changeFac(outCome) {
  }

  async changeSelection(selection) {
  }

  async changeDefaultvalue(deftaultvalue) {

  }
  async changeOrder(order) {
  }
  async changeType(type) {
  }

  deleteCare(id) {
    this.deleteItem.push(id);
    const dialogRef = this.dialog.open(AlertComponent, {
      width: '350px',
      data: { 'title': 'cares', 'id': this.deleteItem, 'API': 'cares/delete' }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (result['status']) {
          this.toastr.success(result['message']);
        }
        this.getServerData(this.pagiPayload);
        this.checked = false;
      }

    });
  }

  async exportCares() {
    const action = {
      type: 'GET',
      target: 'cares/export'
    };
    const payload = {};
    let result = await this.apiService.apiFn(action, payload);

    if (result['status']) {
      const data = result['data'];
      this.exportdata = data['_cares'];
      const cares = this.prepareUsersForCSV();
      this.excelService.exportAsExcelFile(cares, 'Cares_Report');
    }
  }

  prepareUsersForCSV() {
    const cares = [];
    this.exportdata.forEach(item => {
      cares.push({
        'Name': item.name ? item.name : '-',
        'Default_outcome': item.default_outcome ? item.default_outcome : '-',
        'Default_selection': item.default_selection ? item.default_selection : '-',
        'Default_value': item.default_value ? item.default_value : '-',
        'Order': item.order ? item.order : '-',
        'Type': item.type ? item.type : '-',
        'Deleted': item.deleted ? item.deleted : '-'
      });
    });
    return cares;
  }

  public async getCaresDataFunction() {
    const action = {
      type: 'GET',
      target: 'cares'
    };
    const payload = this.pagiPayload;
    let result = await this.apiService.apiFn(action, payload);
    this.count = result['data']['_count'];
    if (result['status']) {
      result = result['data']['_cares'].map(item => {
        return {
          ...item,
          icon: item.icon && item.icon != undefined ? item.icon : '',
          name: item.name,
          default_selection: item.default_selection ? item.default_selection.displayName : '-',
          default_value: item.default_value ? item.default_value : '-',
          order: item.order,
          type: item.type
        };
      });
      this.data = result;
      if (this.data && this.data.length > 0) {
        this.actualDataCount = this.data.length;
      }
      this.createTable(result);
      this._commonService.setLoader(false);
    }
  }

  sortData(sort?: PageEvent) {
    if (sort['direction'] === '') {
      this.sort.active = sort['active'];
      this.sort.direction = 'asc';
      this.sort.sortChange.emit({ active: sort['active'], direction: 'asc' });
      this.sort._stateChanges.next();
      return;
    }
    this._commonService.setLoader(true);
    this.pagiPayload['sort'] = sort;
    sessionStorage.setItem('pageListing', JSON.stringify({ careList: this.pagiPayload }));
    this.getCaresDataFunction();
  }

  public async getServerData(event?: PageEvent) {

    this._commonService.setLoader(true);
    this.pagiPayload.previousPageIndex = event.previousPageIndex;
    this.pagiPayload.pageIndex = event.pageIndex;
    this.pagiPayload.pageSize = event.pageSize;
    this.pagiPayload.length = event.length;
    this.pagiPayload.search = this.search;
    sessionStorage.setItem('pageListing', JSON.stringify({ careList: this.pagiPayload }));
    this.getCaresDataFunction();

  }

}

export interface Element {
  position: number;
  name: string;
  weight: number;
  symbol: string;
}

export interface PagiElement {
  length: number;
  pageIndex: number;
  pageSize: number;
  previousPageIndex: number;
}

