import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from './../../../shared/services/api/api.service';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../../../shared/services/common.service';
import { Subscription } from 'rxjs/Rx';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})

export class FormComponent implements OnInit {
  floorsectorForm: FormGroup;
  organiz; faclist; inputImage;
  private subscription: Subscription;
  constructor(private fb: FormBuilder,
    private router: Router,
    private apiService: ApiService,
    private route: ActivatedRoute,
    private toastr: ToastrService,
    public commonService: CommonService) { }
  floorlist;
  floorsector = {
    _id: null,
    organization: '',
    fac_id: '',
    floor: '',
    sector: '',
    floorplan: ''
  };
  loader = false;
  paramId; facilityId;
  newsector;
  floor_fac;
  sectorArr = [];

  async ngOnInit() {
    this.subscription = this.commonService.contentdata.subscribe(async (contentVal: any) => {
      if (contentVal.org && contentVal.fac) {
        this.floorsector.organization = contentVal.org;
        this.floorsector.fac_id = contentVal.fac;
        this.floor_fac = contentVal.fac;
        if (this.route.params['_value']['id'] && this.route.params['_value']['id'] !== '0') {
          this.loader = true;
          this.paramId = this.route.params['_value']['id'];
          const action1 = { type: 'POST', target: 'floorsector/view' };
          const payload1 = { floorId: this.route.params['_value']['id'] };
          const result1 = await this.apiService.apiFn(action1, payload1);
          this.floorsector = result1['data'];
          this.newsector = '';
          this.loader = false;
        }
      }
    });

    this.subscription = this.commonService.floorcontentdata.subscribe(async (data: any) => {
      if (data) {
        this.floorlist = data;
      }
    });

  }

  cancel() {
    this.router.navigate(['./floorsector']);
  }

  async submit(f, floorsector, type) {
    let valid = f.form.status;
    if (!floorsector._id) {
      if (floorsector.sector.length === 0 && this.sectorArr && !this.sectorArr.length) {
        valid = 'INVALID';
      }
    }

    if (valid === 'VALID') {
      floorsector.sector = this.sectorArr.length ? this.sectorArr : floorsector['sector'];
      this.loader = true;

      if (this.route.params['_value']['org']) {
        this.floorsector.organization = this.route.params['_value']['org'];
      }

      if (this.route.params['_value']['fac']) {
        this.floorsector.fac_id = this.route.params['_value']['fac'];
      }

      floorsector.floor_fac = this.floor_fac;
      const action = { type: 'POST', target: 'floorsector/add' };
      const payload = floorsector;

      const result = await this.apiService.apiFn(action, payload);
      this.loader = false;

      if (result['status']) {
        this.toastr.success(result['message']);
        this.floorlist = result['floorlist'].map(function (obj) {
          const rObj = {};
          rObj['label'] = obj.floor;
          rObj['value'] = obj._id;
          rObj['sector'] = obj.sector;
          return rObj;
        });
        this.commonService.setFloor(this.floorlist);
        if (type === 0) {
          this.router.navigate(['/floorsector']);
        } else {
          if (this.route.params['_value']['org']) {
            this.router.navigate(['/zones/form', 0, this.route.params['_value']['org'], this.route.params['_value']['fac'], result['data']['_id'], result['data']['sector'][0]['_id']]);
          } else {
            this.router.navigate(['/zones/form', 0, this.floorsector.organization, this.floorsector.fac_id, result['data']['_id'], result['data']['sector'][0]['_id']]);
          }
        }
      } else {
        if (this.toastr.currentlyActive === 0) {
          this.toastr.error(result['message']);
        }
      }
    } else {
      if (this.toastr.currentlyActive === 0) {
        this.toastr.error('Please enter floor/sector details');
      }
    }
  }

  async addSector(sector, floor) {
    this.newsector = sector.trim();
    if (this.newsector === '') {
      if (this.toastr.currentlyActive === 0) {
        this.toastr.error('Please enter sector to be added');
      }
    } else {
      const compArr = this.floorsector['sector'];
      let arr, newArr;
      arr = JSON.stringify(compArr);
      newArr = JSON.parse(arr);
      if (newArr.some(item => item.name === this.newsector)) {
        this.toastr.error('This sector is already been added');
      } else {
        this.sectorFn(sector, floor);
      }
    }
  }
  async sectorFn(sector, floor) {
    this.loader = true;
    const action = { type: 'POST', target: 'floorsector/add_sector' };
    const payload = { sector: sector, floor: floor };
    const result = await this.apiService.apiFn(action, payload);

    if (result['status']) {
      this.loadSector();
      if (this.toastr.currentlyActive === 0) {
        this.toastr.success('Sector added successfully');
      }

    } else {
      this.loadSector();
      if (this.toastr.currentlyActive === 0) {
        this.toastr.error((result['message']));
      }
    }
  }

  addSectorNew(sector) {
    this.floorsector['newsector'] = sector.trim();
    if (this.floorsector['newsector'] === '') {
      if (this.toastr.currentlyActive === 0) {
        this.toastr.error('Please enter sector');
      }
    } else {
      if (this.sectorArr.length) {
        const op = this.sectorArr.filter(data => (data.name === this.floorsector['newsector']));

        if (op.length) {
          this.toastr.error('This sector is already been added');
          return false;
        } else {
          this.floorsector['newsector'] !== '' ? this.sectorArr.push({ name: this.floorsector['newsector'] }) : this.sectorArr;
          if (this.toastr.currentlyActive === 0) {
            this.toastr.success('Sector added successfully');
          }
          this.floorsector['newsector'] = '';
          return false;
        }

      } else {
        this.sectorArr.push({ name: this.floorsector['newsector'] });
        if (this.toastr.currentlyActive === 0) {
          this.toastr.success('Sector added successfully');
        }
        this.floorsector['newsector'] = '';
      }
    }
  }

  async removeSectorNew(sector) {
    for (let i = 0; i < this.sectorArr.length; i++) {
      if (this.sectorArr[i].name === sector) {
        this.toastr.success('Sector removed successfully');
        this.sectorArr.splice(i, 1);
      }
    }
    this.floorsector['sector'] = '';
  }

  async removeSector(sector, zone) {
    this.loader = true;
    const action = { type: 'POST', target: 'floorsector/remove_sector' };
    const payload = { sectorId: sector, zoneId: zone };
    const result = await this.apiService.apiFn(action, payload);
    if (result['status']) {
      await this.loadSector();
      if (this.toastr.currentlyActive === 0) {
        this.toastr.success('Sector removed successfully');
      }
    }
  }

  async loadSector() {
    if (this.route.params['_value']['id']) {
      const action1 = { type: 'POST', target: 'floorsector/view' };
      const payload1 = { floorId: this.route.params['_value']['id'] };
      const result1 = await this.apiService.apiFn(action1, payload1);
      this.floorsector['sector'] = result1['data']['sector'];
      this.newsector = '';
      this.loader = false;
    }
  }

  allwoAlphaAndNum(key) {
    const result = this.commonService.allwoAlphaAndNum(key);
    return result;
  }

}
