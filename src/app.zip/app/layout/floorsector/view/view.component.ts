import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from './../../../shared/services/api/api.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent implements OnInit {

  constructor(private route: ActivatedRoute,
    private router: Router,
    private apiService: ApiService) { }

  floorsector;
  loader = false;
  async ngOnInit() {
    this.loader = true;
    const id = this.route.params['_value']['id'];
    const action = { type: 'POST', target: 'floorsector/view' };
    const payload = { floorId: id };
    const result = await this.apiService.apiFn(action, payload);

    this.floorsector = result['data'];
    this.floorsector['sector'] = this.floorsector['sector'].map(itm => itm.name).toString();
    this.floorsector['totalzones'] = result['data']['totalzones'];
    this.loader = false;
  }

  editFloorsector(id) {
    this.router.navigate(['./floorsector/form', id]);
  }

  cancel() {
    this.router.navigate(['/floorsector']);
  }

}
