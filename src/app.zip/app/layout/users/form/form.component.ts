import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroupDirective, NgForm, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from './../../../shared/services/api/api.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { ToastrService } from 'ngx-toastr';
import { MatTableDataSource } from '@angular/material';
import {Subscription, Observable, Subject } from 'rxjs';
import { isObject } from 'util';

export interface PeriodicElement {
  org_name: string;
  org_id: string;
  fac_name: string;
  fac_id: string;
}

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {
  emailNotMatch: Boolean = false;
  corrCheckEmail = false;
  workingEmailNotMatch: Boolean = false;
  corrCheckWorkEmail = false;
  subscription: Subscription;
  private subject = new Subject<any>();
  constructor(private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private apiService: ApiService,
    private toastr: ToastrService,
    public _commonService: CommonService) {

    }
  userForm: FormGroup;
  organiz; faclist; positionsz; job_type;
  org;
  fac;
  shiftArr;
  sendcount: Number = 0;
  public facList = [];
  floorsector;
  multifacility: any;
  multiorg: any;
  userFacilityList: PeriodicElement[];
  displayedColumns = ['org', 'fac', 'action'];
  dataSource = new MatTableDataSource(this.userFacilityList);
  places: Array<any> = [];
  showfaclist: boolean;
  ismultifac: Boolean = false;
  paramId: Boolean;
  userTypeList;

  user: any = {
    first_name: '',
    last_name: '',
    job_title: '',
    other_job_title: '',
    role_id: '',
    email: '',
    confirmEmail: '',
    work_email: '',
    confirmWork_email: '',
    home_phone: '',
    mobile_phone: '',
    employeeId: '',
    shiftNo: '',
    organization: '',
    security_phrase: '',
    facility: [],
    enable_livedashboard: ''
  };

  async ngOnInit() {
    this._commonService.setLoader(true);
    this.shiftArr = this._commonService.shiftTime();
    this.showfaclist = false;
    const actionPosition = { type: 'GET', target: 'users/positions' };
    const payloadPosition = {};
    const resultPosition = await this.apiService.apiFn(actionPosition, payloadPosition);
    this.positionsz = resultPosition['data']['_positions'];
    this.userType();
    if (this.route.params['_value']['id']) {
      this._commonService.setLoader(true);
      this.paramId = true;
      const action = { type: 'POST', target: 'users/view' };
      const payload = { userId: this.route.params['_value']['id'] };
      const result = await this.apiService.apiFn(action, payload);
      this.user = result['data'];
      delete this.user.security_phrase;
      this.user['role_id'] = result['data']['role_id']['_id'];
      if (result['data']['facility'].length > 0) {
        // this.user.organization = result['data']['facility'][0]['org']['_id'];
        this.multiorg = result['data']['facility'][0]['org'] ? result['data']['facility'][0]['org']['org_name'] : '';
        this.changeOrg(this.user.organization);
        this.ismultifac = true;
        this.showfaclist = true;
        // this.user.fac = result['data']['facility'][0]['fac']['_id'];
        this.multifacility = result['data']['facility'][0]['fac']['fac_name'];
      } else {
        this.ismultifac = false;
        this.showfaclist = false;
      }

      // multi facility table show
      this.userFacilityList = result['data']['facility'].map(item => ({
        org_id: item.org._id, org_name: item.org.org_name, fac_id: item.fac._id,
        fac_name: item.fac.fac_name, selected: item.selected })
      );

      this.dataSource = new MatTableDataSource(this.userFacilityList);
      // this.user.shiftNo
      this.user.confirmEmail = result['data']['email'];
      this.user.confirmWork_email = result['data']['work_email'];
      this.job_type = (this.user.job_title) ? this.user.job_title.position_name.toLowerCase() : '';
      this.user.job_title = (this.user.job_title) ? this.user.job_title._id : '';
    }
    // get organization list:
    const action = { type: 'GET', target: 'organization/orglist' };
    const payload = {};
    const result = await this.apiService.apiFn(action, payload);
    this.organiz = result['data'];

    this._commonService.setLoader(false);

  }

  async changeOrg(org) {
    this.org = org;
    const action = { type: 'GET', target: 'facility/faclist' };
    const payload = { 'org_id': org };
    const result = await this.apiService.apiFn(action, payload);
    this.faclist = result['data'];
    this.user.fac = '';
  }

  async changeFac(fac, e) {
    this.fac = fac;
  }
  async changeAccesslevel(postion) {
    this.user.role_id = postion;
  }
  async changePosition(e) {
    const target = e.source.selected._element.nativeElement;
    this.job_type = target.innerText.trim().toLowerCase();
  }

  select(org, fac) {
    if (!org || org === undefined) {
      this.multifacility = fac;
    } else if (!fac || fac === undefined) {
      this.multiorg = org;
    }
  }

  cancel() {
    this.router.navigate(['/users']);
  }

  async onSave(f, user, flag) {
    let vaild = f.form.status;
    if (user.first_name) {
      user.first_name = user.first_name.trim();
    }

    if (user.last_name) {
      user.last_name = user.last_name.trim();
    }

    if (user.job_title) {
      user.job_title = user.job_title.trim();
    }

    // user.role_id = user.role_id.trim();
    if (user.first_name === '' || user.last_name === '' || user.job_title === '' || user.role_id === '') {
      vaild = 'INVALID';
    }
    if (vaild === 'VALID') {
      const str = ('' + user.employeeId);
      user.employeeId = str.padStart(6, '0');

      if (user.confirmEmail === user.email) {
        // this.emailNotMatch = true
        if (user.confirmWork_email === user.work_email) {
          // this.workingEmailNotMatch = false;
          if (!this.ismultifac) {
            this.user['facility'] = [{
              org: this.org,
              fac: this.fac
            }];

          } else {
            this.user['facility'] = this.userFacilityList.map(item => ({
              org: item.org_id, fac: item.fac_id, selected : item['selected'] })
            );
          }
          if (this.route.params['_value']['id'] && this.user['facility'].some(item => item.fac === this.user['fac']
           && this.user['organization'] === item.org)) {

            if (this.toastr.currentlyActive === 0) {
              this.toastr.error('Facility already added');
            }
          } else {
            if (this.route.params['_value']['id'] && this.user['organization'] && this.user['fac']) {
              this.user['facility'].push({
                org: this.user['organization'],
                fac: this.user['fac'],
                selected: false
              });
            }
            this._commonService.setLoader(true);
            const clientKey = sessionStorage.getItem('authReducer');
            // this.user['facility'] = this.fac;
            const client = JSON.parse(clientKey);
            this.user['client_key'] = client.client_key;

           // return;
            const action = { type: 'POST', target: 'users/add' };
            const payload = this.user;
            const result = await this.apiService.apiFn(action, payload);
            if (flag === 'mail') {
              await this.sendMail(this.user);
            }
            this._commonService.setLoader(false);
            if (result['status']) {
              if (this.toastr.currentlyActive === 0) {
                this.toastr.success(result['message']);
              }
              this.router.navigate(['/users']);
            } else {
              if (this.toastr.currentlyActive === 0) {
              this.toastr.error(result['message']);
              }
            }
          }


        } else {
          this.toastr.error('Confirm work email must be the same as work email');
          this.workingEmailNotMatch = true;
        }
      } else {
        this.toastr.error('Confirm personal email must be the same as personal email');
        this.emailNotMatch = true;
      }

    }
  }

  checkAlpha(key) {
    const result = this._commonService.allwoOnlyAlpha(key);
    return result;
  }

  prependZeros(num) {
    const str = ('' + num);
    return str.padStart(6, '0');
  }

  async addFacilityList(user) {
    if (user.organization === '' || user.organization === undefined) {
      this.toastr.error('Please select organization');
    } else if (user.fac === '' || user.fac === undefined) {
      this.toastr.error('Please select facility');
    } else {
     // this.loader = true;
      this.ismultifac = true;
      if (this.userFacilityList === undefined || this.userFacilityList.length < 1) {
        this.userFacilityList = [
          {
            'org_id': user.organization,
            'org_name': this.multiorg,
            'fac_id': user.fac,
            'fac_name': this.multifacility
          }
        ];
      } else {
        if (this.userFacilityList.some(item => item.fac_name.toLowerCase().trim() === this.multifacility.toLowerCase().trim() &&
         item.org_name.toLowerCase().trim() === this.multiorg.toLowerCase().trim())) {
          if (this.toastr.currentlyActive === 0) {
            this.toastr.error('Facility already added');
          }
        } else {
          this.userFacilityList.push({
            org_id: user.organization,
            org_name: this.multiorg,
            fac_id: user.fac,
            fac_name: this.multifacility
          });
        }
      }
      // this.loader = false;
      if (this.userFacilityList.length > 0) {
        this.showfaclist = true;
        this.ismultifac = true;
        this.dataSource = new MatTableDataSource(this.userFacilityList);
      } else {
        this.ismultifac = false;
        this.showfaclist = false;
      }
      this.user['organization'] = '';
      this.user['fac'] = '';
    }
  }
  // }
  async onRemoveFac(i) {
    this.userFacilityList.splice(i, 1);
    if (this.userFacilityList.length > 0) {
      this.showfaclist = true;
      this.ismultifac = true;
      this.dataSource = new MatTableDataSource(this.userFacilityList);
    } else if (this.userFacilityList.length === 0) {
      this.showfaclist = false;
      this.ismultifac = false;
    }
  }

  async corrCheEmail(e, no, f) {
    if (no === '0') {
      if (this.user.email === e.target.value) {
        this.emailNotMatch = false;
        f.form.controls['confirmEmail'].setErrors(null);
      } else {
        this.emailNotMatch = true;
        f.form.controls['confirmEmail'].setErrors({ 'incorrect': true });
      }
    } else if (no === '1') {
      if (this.user.work_email === e.target.value) {
        this.workingEmailNotMatch = false;
        f.form.controls['confirmWork_email'].setErrors(null);
      } else {
        this.workingEmailNotMatch = true;
        f.form.controls['confirmWork_email'].setErrors({ 'incorrect': true });
      }
    }
  }

  async userType() {
    const action = { type: 'GET', target: 'users/user_type' };
    const payload = {
      'role_type': 'users'
    };
    const result = await this.apiService.apiFn(action, payload);
    if (result['status']) {
      this.userTypeList = result['data']['_roles'];
    }
  }

  onChangelivedashboard(e) {

  }

  async sendMail(user) {
    if (this.sendcount === 0) {
        this._commonService.setLoader(true);
        const action = {
          type: 'POST',
          target: 'users/email'
        };
        const payload = { userIds: [user._id] };
        const result = await this.apiService.apiFn(action, payload);
        this._commonService.setLoader(false);
        if (result['success'] === true) {
          if (this.toastr.currentlyActive === 0) {
            this.toastr.success(result['message']);
          }
          this.sendcount = 1;
        } else {
          if (this.toastr.currentlyActive === 0) {
            this.toastr.success(result['message']);
          }
        }
    } else {
      if (this.toastr.currentlyActive === 0) {
        this.toastr.error('You already sent the invitation');
      }
    }
  }
}
