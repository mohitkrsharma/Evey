import { Component, OnInit, ViewChild, HostListener, ElementRef } from '@angular/core';
import { MatTableDataSource, MatSort, PageEvent, MatPaginator } from '@angular/material';
import { Router } from '@angular/router';
import { ApiService } from './../../../shared/services/api/api.service';
import { ExcelService } from './../../../shared/services/excel.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AlertComponent } from '../../../shared/modals/alert/alert.component';
import { ToastrService } from 'ngx-toastr';
import { fromEvent, Subscription } from 'rxjs';
import { CommonService } from './../../../shared/services/common.service';
import { debounceTime, map, distinctUntilChanged, filter, tap } from 'rxjs/operators';
import * as moment from 'moment';
import * as XLSX from 'xlsx';
type AOA = any[][];

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {
  constructor(
    private router: Router,
    private apiService: ApiService,
    private excelService: ExcelService,
    private dialog: MatDialog,
    private toastr: ToastrService,
    public _commonService: CommonService
  ) { }


  @ViewChild('deleteButton') private deleteButton: ElementRef;
  public btnAction: Function;
  public filtershow = false;
  private subscription: Subscription;
  filesdata: AOA = [];
  uploadOrgFac;
  fac; org;
  defaultErr: any;
  errorMsg: any = [];
  // MATPAGINATOR
  // pageEvent: PageEvent;
  datasource: null;
  pageIndex: number;
  pageSize: number;
  length: number;
  checked;
  deleteArr = [];
  deleteItem = [];
  data;
  arr = [];
  dataSource;
  count;
  isShow: boolean;
  topPosToStartShowing = 100;
  displayedColumns = [];
  organization; facility;
  // ddp list variable
  organiz;
  search: any;
  fac_list;
  pagiPayload: PagiElement = {
    length: 0,
    pageIndex: 0,
    pageSize: 10,
    previousPageIndex: 0,
    search: '',
    sort: { active: 'name', direction: 'asc' },
    org_id: '',
    fac_id: ''
  };
  actualDataCount;
  bulkorg; bulkfac;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  sortActive = 'name';
  sortDirection: 'asc' | 'desc' | '';
  positionsz: any;
  /**
   * Pre-defined columns list for user table
   */
  userIds = [];
  columnNames = [
    {
      id: 'name',
      value: 'User Name',
      sort: true
    }
    , {
      id: 'facility',
      value: 'Facility',
      sort: false
    },
    // , {
    //   id: "work_email",
    //   value: "Email"
    // }
    {
      id: 'job_title',
      value: 'Position',
      sort: true
    },
    {
      id: 'role',
      value: 'Access Level',
      sort: false
    }
  ];
  selectedOrganization;
  selectedFacility;
  suspend_user;
  @ViewChild('searchInput') searchInput: ElementRef;


  exportdata; filedata;
  public show = false;
  @HostListener('window:scroll')
  checkScroll() {

    // window의 scroll top
    // Both window.pageYOffset and document.documentElement.scrollTop 
    // returns the same result in all the cases. window.pageYOffset is not supported below IE 9.

    const scrollPosition = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
    if (scrollPosition >= this.topPosToStartShowing) {
      this.isShow = true;
    } else {
      this.isShow = false;
    }
  }

  // TODO: Cross browsing
  gotoTop() {
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }
  ngOnInit() {
    const errValues = this._commonService.errorMessages();
    this.defaultErr = errValues[0].user_errors;
    this._commonService.setLoader(true);
    if (sessionStorage.getItem('pageListing')) {
      const pageListing = JSON.parse(sessionStorage.getItem('pageListing'));
      if (pageListing.userList) {
        this.pagiPayload.previousPageIndex = pageListing.userList.previousPageIndex;
        this.pagiPayload.pageIndex = pageListing.userList.pageIndex;
        this.pagiPayload.pageSize = pageListing.userList.pageSize;
        this.pagiPayload.length = pageListing.userList.length;
      } else {
        sessionStorage.setItem('pageListing', JSON.stringify({ userList: this.pagiPayload }));
      }
    } else {
      sessionStorage.setItem('pageListing', JSON.stringify({ userList: this.pagiPayload }));
    }

    this.search = this.searchInput.nativeElement.value;
    // searching
    fromEvent(this.searchInput.nativeElement, 'keyup')
      .pipe(
        // tslint:disable-next-line:max-line-length
        debounceTime(1000), // The user can type quite quickly in the input box, and that could trigger a lot of server requests. With this operator, we are limiting the amount of server requests emitted to a maximum of one every 150ms
        distinctUntilChanged(), // This operator will eliminate duplicate values
        tap(() => {
          this.getServerData(this.pagiPayload);
        })
      )
      .subscribe();

    this.btnAction = this.addForm.bind(this);
    this.displayedColumns = this.displayedColumns.concat(['checkbox']);
    this.displayedColumns = this.displayedColumns.concat(this.columnNames.map(x => x.id));
    this.displayedColumns = this.displayedColumns.concat(['enable_livedashboard']);
    this.displayedColumns = this.displayedColumns.concat(['suspend_user']);
    this.displayedColumns = this.displayedColumns.concat(['actions']);

    this.getOrganizationlist();
    this.getServerData(this.pagiPayload);

    this._commonService.setLoader(false);

  }

  download() {
    for (let i = 0; i < 10; i++) {
      this.arr.push({});
    }
    const users = this.prepareForExport();
    this.excelService.exportAsExcelFile(users, 'Add User');
  }

  filter() {
    this.filtershow = !this.filtershow;
    this.show = false;
  }

  toggle() {
    this.show = !this.show;
    this.filtershow = false;
    this.organization = '';
    this.facility = '';
    delete this.pagiPayload['org_name'];
    delete this.pagiPayload['fac_name'];
  }

  uploadFile(evt: any, org, fac) {
    if (org && fac) {
      this.uploadOrgFac = { org, fac };
      console.log('this.uploadOrgFac', this.uploadOrgFac);
      /* wire up file reader */
      const target: DataTransfer = <DataTransfer>(evt.target);
      if (target.files.length !== 1) { throw new Error('Cannot use multiple files'); }
      const reader: FileReader = new FileReader();
      reader.onload = (e: any) => {
        /* read workbook */
        const bstr: string = e.target.result;
        const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

        /* grab first sheet */
        const wsname: string = wb.SheetNames[0];
        const ws: XLSX.WorkSheet = wb.Sheets[wsname];

        /* save data */
        this.filesdata = XLSX.utils.sheet_to_json(ws);
        console.log(this.filesdata);
        this.checkdata();
        // .then((res) => {
        //   // this.uploadFiles(this.filesdata,org,fac);
        // }).catch((err) => {
        //   console.log("Some error",err)
        // })
      };
      reader.readAsBinaryString(target.files[0]);
    } else {
      // this.loader = false;
      this.toastr.error('Please select organization and facility');
      this.filedata = '';
    }

  }
  async checkdata() {
    const actionPosition = { type: 'GET', target: 'users/positions' };
    const payloadPosition = {};
    const resultPosition = await this.apiService.apiFn(actionPosition, payloadPosition);
    this.positionsz = resultPosition['data']['_positions'];
    console.log('this.positionsz', this.positionsz);
    const isSave = true, countError = 0;
    this.errorMsg = [];
    this.filesdata.map((item, j) => {
      console.log('fksjgfksgfkjs', item, j);

      console.log('check ');
      if (item['First Name'] !== undefined) {
        if (!item['First Name'].toString().match(/^[a-zA-Z ]*$/)) {
          this.errorMsg.push(`Line No. ${j + 1} ${this.defaultErr.first_name_allow}`);
          // this.toastr.error(msg);
        }
      } else {
        this.errorMsg.push(`Line No. ${j + 1} ${this.defaultErr.first_name_required}`);
        // this.toastr.error("User first name not found/filled");
      }
      if (item['Last Name'] !== undefined) {
        if (!item['Last Name'].toString().match(/^[a-zA-Z ]*$/)) {
          this.errorMsg.push(`Line No. ${j + 1} ${this.defaultErr.last_name_allow}`);
          // this.toastr.error("User last name must contain only letter and spaces");
        }
      } else {
        this.errorMsg.push(`Line No. ${j + 1} ${this.defaultErr.last_name_required}`);
        // this.toastr.error("User last name not found/filled");
      }

      if (item['Personal Email'] !== undefined) {
        if (!this.isValidEmail(item['Personal Email'])) {
          this.errorMsg.push(`Line No. ${j + 1} ${this.defaultErr.personal_email}`);
          // this.toastr.error(`Invalid "Personal email" address`);
        }
      }
      if (item['Work Email'] !== undefined) {
        if (!this.isValidEmail(item['Work Email'])) {
          this.errorMsg.push(`Line No. ${j + 1} ${this.defaultErr.work_email}`);
          // this.toastr.error(`Invalid "Work email" address`);
        }
      } else {
        this.errorMsg.push(`Line No. ${j + 1} ${this.defaultErr.work_email_required}`);
        // this.toastr.error("User work email not found/filled");
      }

      if (item['Secondary Phone'] !== undefined) {
        if (!item['Secondary Phone'].toString().match(/^\d+/)) {
          this.errorMsg.push(`Line No. ${j + 1} ${this.defaultErr.secondary_no}`);
          // this.toastr.error(`Invalid "Secondary Phone"`);
        } else {
          if (item['Secondary Phone'].toString().length === 10) {

          } else {
            this.errorMsg.push(`Line No. ${j + 1} ${this.defaultErr.secondary_no_len}`);
            // this.toastr.error(`Invalid "Secondary Phone" please enter 10 digit Mob. no.`);
          }
        }
      }

      if (item['Primary Phone'] !== undefined) {
        if (!item['Primary Phone'].toString().match(/^\d+/)) {
          this.errorMsg.push(`Line No. ${j + 1} ${this.defaultErr.primary_no}`);
          // this.toastr.error(`Invalid "Primary Phone"`);
        } else {
          if (item['Primary Phone'].toString().length === 10) {

          } else {
            this.errorMsg.push(`Line No. ${j + 1} ${this.defaultErr.primary_no_len}`);
            // this.toastr.error(`Invalid "Primary Phone" please enter 10 digit Mob. no.`);
          }
        }
      } else {

        this.errorMsg.push(`Line No. ${j + 1} ${this.defaultErr.primary_no_requires}`);
      }
      if (item['Employee ID'] === undefined) {
        this.errorMsg.push(`Line No. ${j + 1} ${this.defaultErr.employee_id}`);
        // this.toastr.error("User Employee ID not found/filled");
      }
      if (item['Position'] !== undefined) {
        if (this.positionsz.find((i) => i.position_name === item['Position']) === undefined) {
          this.errorMsg.push(`Line No. ${j + 1} ${this.defaultErr.postion}`);
          // this.toastr.error("Please choose User Position not found/filled");
        }
      } else {
        this.errorMsg.push(`Line No. ${j + 1} ${this.defaultErr.postion}`);
        // this.toastr.error("User Position not found/filled");
      }
    });
    console.log(' isSave,countError', this.errorMsg);
    if (!this.errorMsg.length) {
      this.uploadFiles(this.filesdata, this.uploadOrgFac['org'], this.uploadOrgFac['fac']);
    } else {
      this.filedata = '';
      this.filesdata = [];
      return 0;
    }
    // return ({ isSave, countError });
  }

  async isValidEmail(email) {
    return /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email);
  }


  async uploadFiles(data, organization, facility) {
    console.log('finalllll uploadFiles', data, organization, facility);
    if (organization && facility) {
      if (data && !data.length) {
        this.toastr.error('Not found user details in your excel sheet');
        this.filedata = '';
        this.filesdata = [];
      } else {
        this._commonService.setLoader(true);
        const payload = {
          filedata: data,
          organization: organization,
          facility: facility
        };
        const action = {
          type: 'POST',
          target: 'users/upload'
        };
        const result = await this.apiService.apiFn(action, payload);
        this.filedata = '';
        this.filesdata = [];
        this.organization = '';
        this.facility = '';
        this._commonService.setLoader(false);
        if (result['status']) {
          this.toastr.success(result['message']);
        } else {
          this.toastr.error(result['message']);
        }
      }
    } else {
      this._commonService.setLoader(false);
      this.toastr.error('Please select organization and facility');
      this.filedata = '';
    }

  }

  prepareForExport() {
    const user = [];
    this.arr.forEach(item => {
      user.push({
        'First Name': null,
        'Last Name': null,
        'Work Email': null,
        'Home Phone': null,
        'Mobile Phone': null
      });
    });
    return user;
  }

  getName(first, last) {
    return first.concat(last);
  }

  createTable(arr) {
    const tableArr: Element[] = arr;
    this.dataSource = new MatTableDataSource(tableArr);
    // this.dataSource.sort = this.sort;
  }

  addForm() { // Custom-code!
    this.router.navigate(['/users/form']);
  }

  editUser(id) {
    this.router.navigate(['/users/form', id]);
  }

  viewUser(id) {
    this.router.navigate(['/users/view', id]);
  }

  deleteUser(id) {
    this.deleteArr = [];
    const dialogRef = this.dialog.open(AlertComponent, {
      width: '350px',
      data: { 'title': 'user', 'id': id, 'API': 'users/delete' }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.checked = false;
      if (result && result['status']) {
        this.toastr.success(result['message']);
        this.getServerData(this.pagiPayload);
      } else {
        this.toastr.error(result['message']);
      }
    });
  }

  selectAll() {
    if (this.checked === true) {
      this.data.forEach(element => {
        element.checked = false;
        this.deleteArr = [];
      });
    } else {
      this.data.forEach(element => {
        this.deleteArr.push(element._id);
        element.checked = true;
      });
    }
  }


  selectElement(id, check) {
    if (check === true) {
      for (let i = 0; i < this.deleteArr.length; i++) {
        if (this.deleteArr[i] === id) {
          this.deleteArr.splice(i, 1);
        }
      }
    } else if (check === undefined || check === false) {
      this.deleteArr.push(id);
    }
    if ((this.deleteArr && this.deleteArr.length) < this.actualDataCount) {
      this.checked = false;
    } else if ((this.deleteArr && this.deleteArr.length) === this.actualDataCount) {
      this.checked = true;
    }
  }


  delete() {
    if (this.deleteArr.length === 0) {
      if (this.toastr.currentlyActive === 0) {
        this.toastr.error('Please select users to be deleted');
        this.checked = false;
      }
    } else {
      const dialogRef = this.dialog.open(AlertComponent, {
        width: '350px',
        data: { 'title': 'users', 'id': this.deleteArr, 'API': 'users/delete' }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result && result['status']) {
          this.toastr.success(result['message']);
          this.getServerData(this.pagiPayload);
          this.checked = false;
        } else {
          this.data.forEach(element => {
            element.checked = false;
            this.checked = false;
          });
          this.deleteArr = [];
        }
        this.deleteButton['_elementRef'].nativeElement.classList.remove('cdk-program-focused');
        this.deleteButton['_elementRef'].nativeElement.classList.remove('cdk-focused');
        document.getElementById('searchInput').focus();
        document.getElementById('searchInput').blur();
      });
    }
  }

  async exportUser() {
    this._commonService.setLoader(true);
    const action = {
      type: 'GET',
      target: 'users/export'
    };
    const payload = this.pagiPayload;
    let result = await this.apiService.apiFn(action, payload);
   // result = result['data'];
    if (result['status']) {
      const data = result['data'];
      this.exportdata = data;
      const users = this.prepareUsersForCSV();
      this.excelService.exportAsExcelFile(users, 'Users_Report');
    }
  }

  // async sendMail(id) {
  //   this.userIds.push(id)
  //   let action = {
  //     type: 'POST',
  //     target: 'users/email'
  //   }
  //   let payload = { userIds: this.userIds };
  //   var result = await this.apiService.apiFn(action, payload);
  // }

  prepareUsersForCSV() {
    const users = [];
    this.exportdata.forEach(item => {
      const facility = item['facility'].map(itm => itm.fac ? itm.fac.fac_name : '-');
      const org = item['facility'].map(itm => itm.org ? itm.org.org_name : '-');
      const unique = (value, index, self) => {
        return self.indexOf(value) === index;
      };
      const arr = facility.filter(unique);
      const arr1 = org.filter(unique);
      users.push({
        'Name': item.first_name + ' ' + item.last_name,
        // 'Lastname': item.last_name,
        'Username': item.username,
        'Position': item.job_title,
        'Access Level': item.role_id ? item.role_id['role_name'] : '-',
        'Personal Email': item.email,
        'Work Email': item.work_email,
        'Praimary Phone': item.home_phone,
        'Secondary Phone': item.mobile_phone,
        'Employee Id': item.employeeId ? item.employeeId : '-',
        'Organization': item['facility'] ? arr1.toString() : '-',
        'facility': item['facility'] ? arr.toString() : '-',
        'Created Date': item.date ? moment(item.date).format('MMMM Do YYYY') : '-'

      });
    });
    this._commonService.setLoader(false);
    return users;
  }

  public async getUsersDataFunction() {
    const action = {
      type: 'GET',
      target: 'users'
    };
    const payload = this.pagiPayload;
    console.log('payload    -----======>>>>>>>   ', payload);
    let result = await this.apiService.apiFn(action, payload);
    console.log('ressssssssssssss    -----======>>>>>>>   ', result);
    if (result['status']) {
      if ((!result['data']['_users'] || result['data']['_users'].length === 0) && this.pagiPayload.pageIndex > 0) {
        this.paginator.previousPage();
      } else {
        this.count = result['data']['_count'];
        result = result['data']['_users'].map(item => {
          const facility = item['_facility'].map(itm => itm.fac ? itm.fac.fac_name : '-');
          const unique = (value, index, self) => {
            return self.indexOf(value) === index;
          };
          const arr = facility.filter(unique);
          return {
            ...item,
            name: item.last_name + ',' + ' ' + item.first_name,
            facility: item['_facility'] ? (arr).toString().replace(/,/g, ', ') : '-',
            work_email: item.work_email ? item.work_email : '-',
            role: item.role ? item.role : '-',
            job_title: item.job_title ? item.job_title : '-',
            active: item.active === null ? true : item.active
          };
        });
        this._commonService.setLoader(false);
        this.data = result;
        console.log('list data', this.data);
        if (this.data && this.data.length > 0) {
          this.actualDataCount = this.data.length;
        }
        this.createTable(result);
        this.checked = false;
        this.deleteArr = [];
      }
    }
  }

  sortData(sort?: PageEvent) {
    if (sort['direction'] === '') {
      this.sort.active = sort['active'];
      this.sort.direction = 'asc';
      this.sort.sortChange.emit({ active: sort['active'], direction: 'asc' });
      this.sort._stateChanges.next();
      return;
    }
    this._commonService.setLoader(true);
    this.pagiPayload['sort'] = sort;
    sessionStorage.setItem('pageListing', JSON.stringify({ userList: this.pagiPayload }));
    this.getUsersDataFunction();
  }

  public async getServerData(event?: PageEvent) {
    this._commonService.setLoader(true);
    this.pagiPayload.previousPageIndex = event.previousPageIndex;
    this.pagiPayload.pageIndex = event.pageIndex;
    this.pagiPayload.pageSize = event.pageSize;
    this.pagiPayload.length = event.length;
    this.pagiPayload.search = this.search;
    this.pagiPayload.org_id = event['organization'];
    this.pagiPayload.fac_id = event['facility'];
    sessionStorage.setItem('pageListing', JSON.stringify({ userList: this.pagiPayload }));
    this.getUsersDataFunction();
  }

  async sendMail() {
    if (this.deleteArr.length === 0) {
      if (this.toastr.currentlyActive === 0) {
        this.toastr.error('Please select users to be invite');
      }
    } else {
      this._commonService.setLoader(true);
      const action = {
        type: 'POST',
        target: 'users/email'
      };
      const link = window.location.origin;
      const payload = { userIds: this.deleteArr , linkurl : link};
      const result = await this.apiService.apiFn(action, payload);
      if (result['success'] === true) {
        if (this.toastr.currentlyActive === 0) {
          this.toastr.success(result['message']);
        }
        this.deleteArr = [];
      } else {
        if (this.toastr.currentlyActive === 0) {
          this.toastr.success(result['message']);
        }
      }
      this.getServerData(this.pagiPayload);
      this.deleteArr = [];
      this.checked = false;
    }
  }


  async changeOrg(org, type) {
    this.filedata = '';
    if (type === 'bulk') {
      this.bulkorg = org.value;
      const action = { type: 'GET', target: 'facility/faclist' };
      const payload = { 'org_id': org };
      const result = await this.apiService.apiFn(action, payload);
      this.fac_list = result['data'];
    } else {
      this.facility = '';
      this.pagiPayload = {
        length: 0,
        pageIndex: 0,
        pageSize: 10,
        previousPageIndex: 0,
        search: this.search,
        sort: this.pagiPayload.sort,
        org_id: this.pagiPayload.org_id,
        fac_id: this.pagiPayload.fac_id
      };
      this.org = org;
      this.pagiPayload['org_name'] = this.org;
      const action = { type: 'GET', target: 'facility/faclist' };
      const payload = { 'org_id': org };
      const result = await this.apiService.apiFn(action, payload);
      this.fac_list = result['data'];
      this.pagiPayload['fac_name'] = '';
      this.getServerData(this.pagiPayload);
    }

  }

  async changeFac(fac, type) {
    this.filedata = '';
    if (type === 'bulk') {
      this.bulkfac = fac.value;
    } else {
      this.pagiPayload = {
        length: 0,
        pageIndex: 0,
        pageSize: 10,
        previousPageIndex: 0,
        search: this.search,
        sort: this.pagiPayload.sort,
        org_id: this.pagiPayload.org_id,
        fac_id: this.pagiPayload.fac_id
      };
      this.fac = fac;
      this.pagiPayload['org_name'] = this.org;
      this.pagiPayload['fac_name'] = this.fac;
      this.getServerData(this.pagiPayload);
    }

  }


  async getOrganizationlist() {
    const action = { type: 'GET', target: 'organization/orglist' };
    const payload = {};
    const result = await this.apiService.apiFn(action, payload);
    this.organiz = result['data'];
  }

  resetFilter() {
    this.filtershow = false;
    this.organization = '';
    this.facility = '';
    delete this.pagiPayload['org_name'];
    delete this.pagiPayload['fac_name'];
    this.getServerData(this.pagiPayload);
  }

  // searching
  onChange(item, event) {
    this.search = item;
    setTimeout(() => {
      this.getServerData(this.pagiPayload);
    }, 2000);
  }

  async onChangelivedashboard(event, user_id) {
    sessionStorage.setItem('enable_livedashboard', event.checked);
    const userlist = [];
    userlist.push(user_id);
    const action = { type: 'POST', target: 'users/user_enable_live' };
    const payload = { 'userList': userlist, value: event.checked };
    const result = await this.apiService.apiFn(action, payload);
    if (result['status']) {
      this.toastr.success(result['message']);
    } else {
      this.toastr.error(result['message']);
    }
  }

  async suspendUser(event, user_id) {
    if (event.checked === true) {
      const action = { type: 'POST', target: 'users/suspend_user' };
      const payload = { 'active': event.checked, 'userId': user_id };
      const result = await this.apiService.apiFn(action, payload);
      console.log("result of enable disable user", result);
    } else {
      const payload = { 'active': event.checked, 'userId': user_id };
      ;
      const dialogRef = this.dialog.open(AlertComponent, {
        width: '350px',
        data: { 'title': 'suspend_user', 'id': payload, 'API': 'users/suspend_user' }
      });
      dialogRef.afterClosed().subscribe(result => {
        this._commonService.setLoader(true);
        this.getUsersDataFunction();
      });
    }


  }

}


export interface Element {
  position: number;
  name: string;
  weight: number;
  symbol: string;
}

export interface PagiElement {
  length: number;
  pageIndex: number;
  pageSize: number;
  previousPageIndex: number;
  search: '';
  sort: Object;
  org_id: '';
  fac_id: '';
}
