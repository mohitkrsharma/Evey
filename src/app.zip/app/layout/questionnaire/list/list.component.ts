import { Component, OnInit, ViewChild, HostListener, ElementRef, TemplateRef } from '@angular/core';
import { MatTableDataSource, MatSort, PageEvent } from '@angular/material';
import { Router } from '@angular/router';
import { ApiService } from './../../../shared/services/api/api.service';
import { AlertComponent } from '../../../shared/modals/alert/alert.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material/dialog';
import { ExcelService } from './../../../shared/services/excel.service';
import { CommonService } from './../../../shared/services/common.service';
import { ToastrService } from 'ngx-toastr';
import { fromEvent } from 'rxjs';
import { MatOption } from '@angular/material';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import {
  debounceTime,
  map,
  distinctUntilChanged,
  filter,
  tap
} from 'rxjs/operators';
import { bypassSanitizationTrustResourceUrl } from '@angular/core/src/sanitization/bypass';

import { MatTable } from '@angular/material/table';
import { CdkDragDrop, moveItemInArray, transferArrayItem, CdkDragHandle } from '@angular/cdk/drag-drop';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {

  constructor(
    private router: Router,
    private apiService: ApiService,
    public dialog: MatDialog,
    private excelService: ExcelService,
    private toastr: ToastrService,
    private fb: FormBuilder,
    public _commonService: CommonService
  ) { this.createPropertyForm(); }
  @ViewChild('table') table: MatTable<any>;
  @ViewChild('addQuestion') addQuestion: TemplateRef<any>;
  @ViewChild('searchInput') searchInput: ElementRef;
  @ViewChild('deleteButton') private deleteButton: ElementRef;
  public btnAction: Function;

  // MATPAGINATOR
  // pageEvent: PageEvent;
  datasource: null;
  pageIndex: number;
  pageSize: number;
  length: number;
  checked;
  deleteArr = [];
  deleteItem = [];
  data;
  dataSource;
  isShow: boolean;
  topPosToStartShowing = 100;
  displayedColumns = [];
  organiz; floorlist; faclist;
  @ViewChild(MatSort) sort: MatSort;
  sortActive = 'order';
  sortDirection: 'asc' | 'desc' | '';
  count;
  actualDataCount;
  search: any;
  /**
   * Pre-defined columns list for user table
   */
  columnNames = [

    {
      id: 'question',
      value: 'Question',
      sort: false
    },
    {
      id: 'type',
      value: 'Type',
      sort: false
    }];
  exportdata;
  pagiPayload = {
    length: 0,
    pageIndex: 0,
    pageSize: 10,
    previousPageIndex: 0,
    search: '',
  };
  public show = false;
  @HostListener('window:scroll')


  public Question_Types: any = [
    {
      'type': 'checkbox',
      'name': 'Multiple choice'
    }, {

      'type': 'date',
      'name': 'Date Picker'
    }, {

      'type': 'radio',
      'name': 'Radio'
    }, {

      'type': 'select',
      'name': 'Dropdown'
    }, {
      'type': 'text',
      'name': 'Input'
    }, {
      'type': 'textarea',
      'name': 'Text area'
    }];
  dialogRefs = null;
  isEdit = false;
  isOptionField: boolean;
  question: any = {
    is_visitor: true,
    type: '',
    question: '',
    field_label: this.fb.array([
      this.setInputType(),
    ]),
  };
  questionForm: FormGroup;
  public temparray: any = [];
  editId: any = null;
  btnClass: string;
  checkScroll() {

    // window의 scroll top
    // Both window.pageYOffset and document.documentElement.scrollTop returns the same result in all the cases. window.pageYOffset is not supported below IE 9.

    const scrollPosition = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;

    if (scrollPosition >= this.topPosToStartShowing) {
      this.isShow = true;
    } else {
      this.isShow = false;
    }
  }

  // TODO: Cross browsing
  gotoTop() {
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }
  ngOnInit() {
    if (sessionStorage.getItem('pageListing')) {
      const pageListing = JSON.parse(sessionStorage.getItem('pageListing'));
      if (pageListing.questionList) {
        this.pagiPayload = pageListing.questionList;
      } else {
        sessionStorage.setItem('pageListing', JSON.stringify({ questionList: this.pagiPayload }));
      }
    } else {
      sessionStorage.setItem('pageListing', JSON.stringify({ questionList: this.pagiPayload }));
    }
    this.search = this.searchInput.nativeElement.value;
    fromEvent(this.searchInput.nativeElement, 'keyup')
      .pipe(
        debounceTime(2000),
        distinctUntilChanged(),
        tap(() => {
          this.getServerData(this.pagiPayload);
        })
      )
      .subscribe();
    this.displayedColumns = this.displayedColumns.concat(['checkbox']);
    this.displayedColumns = this.displayedColumns.concat(['position']);
    this.displayedColumns = this.displayedColumns.concat(this.columnNames.map(x => x.id));
    this.displayedColumns = this.displayedColumns.concat(['change_status']);

    this.displayedColumns = this.displayedColumns.concat(['actions']);
    // Pagination
    this.getServerData(this.pagiPayload);
  }

  selectAll() {
    if (this.checked === true) {
      this.data.forEach(element => {
        element.checked = false;
        this.deleteArr = [];
      });
    } else {
      this.data.forEach(element => {
        this.deleteArr.push(element._id);
        element.checked = true;
      });
    }
  }

  selectElement(id, check) {
    if (check === true) {
      for (let i = 0; i < this.deleteArr.length; i++) {
        if (this.deleteArr[i] === id) {
          this.deleteArr.splice(i, 1);
        }
      }
    } else if (check === undefined || check === false) {
      this.deleteArr.push(id);
    }
    if ((this.deleteArr && this.deleteArr.length) < this.actualDataCount) {
      this.checked = false;
    } else if ((this.deleteArr && this.deleteArr.length) === this.actualDataCount) {
      this.checked = true;
    }
  }

  delete() {
    if (this.deleteArr.length === 0) {
      this.toastr.error('Please select Question to be deleted');
      this.checked = false;
    } else {
      const dialogRef = this.dialog.open(AlertComponent, {
        width: '350px',
        data: { 'title': 'questions', 'id': this.deleteArr, 'API': 'questions/delete' }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (!result) {
          this.data.forEach(element => {
            element.checked = false;
            this.checked = false;
          });
          this.deleteArr = [];
        } else {
          if (result['status']) {
            this.toastr.success(result['message']);
          }
          this.checked = false;
          this.getServerData(this.pagiPayload);
        }
        this.deleteButton['_elementRef'].nativeElement.classList.remove('cdk-program-focused');
        this.deleteButton['_elementRef'].nativeElement.classList.remove('cdk-focused');
        document.getElementById('searchInput').focus();
        document.getElementById('searchInput').blur();
      });
    }

  }

  createTable(arr) {
    const tableArr: Element[] = arr;
    this.dataSource = new MatTableDataSource(tableArr);
  }

  deleteQuestion(id) {
    this.deleteItem.push(id);
    const dialogRef = this.dialog.open(AlertComponent, {
      width: '350px',
      data: { 'title': 'questions', 'id': this.deleteItem, 'API': 'questions/delete' }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result != false) {
        if (result['status']) {
          this.toastr.success(result['message']);
        }
        this.getServerData(this.pagiPayload);
        this.checked = false;
      }
    });
  }

  public async getQuestionsDataFunction() {
    const action = {
      type: 'GET',
      target: 'questions'
    };
    const payload = this.pagiPayload;
    let result = await this.apiService.apiFn(action, payload);

    this.count = result['data']['_count'];
    if (result['status']) {
      result = result['data']['_questions'].map(item => {
        return {
          ...item,
          question: item.question,
          order: item.order,
          type: this.questionType(item.type)
        };
      });
      this.data = result;
      if (this.data && this.data.length > 0) {
        this.actualDataCount = this.data.length;
      }
      this.createTable(result);
      this._commonService.setLoader(false);
    }
  }

  sortData(sort?: PageEvent) {
    if (sort['direction'] === '') {
      this.sort.active = sort['active'];
      this.sort.direction = 'asc';
      this.sort.sortChange.emit({ active: sort['active'], direction: 'asc' });
      this.sort._stateChanges.next();
      return;
    }
    this._commonService.setLoader(true);
    this.pagiPayload['sort'] = sort;
    sessionStorage.setItem('pageListing', JSON.stringify({ questionList: this.pagiPayload }));
    this.getQuestionsDataFunction();
  }

  public async getServerData(event?: PageEvent) {
    this._commonService.setLoader(true);
    this.pagiPayload.previousPageIndex = event.previousPageIndex;
    this.pagiPayload.pageIndex = event.pageIndex;
    this.pagiPayload.pageSize = event.pageSize;
    this.pagiPayload.length = event.length;
    this.pagiPayload.search = this.search;
    sessionStorage.setItem('pageListing', JSON.stringify({ questionList: this.pagiPayload }));
    this.getQuestionsDataFunction();

  }

  get optionsPoints() {
    return this.questionForm.get('options') as FormArray;
  }
  createPropertyForm() {
    this.questionForm = this.fb.group({
      _id: [null, []],
      is_visitor: [true, []],
      type: ['', [Validators.required]],
      question: ['', [Validators.required]],
      options: this.fb.array([
        this.setInputType(),
      ])
    });
  }

  /* Add multiple input to the form */
  setInputType() {
    return this.fb.group({
      label: ['', []],
    });
  }

  /* Add option for Radio, Dropdown and Multi Checkboxes */
  addOption() {
    this.temparray = <FormArray>this.questionForm.controls['options'];
    this.temparray.push(this.setInputType());
  }

  /* Remove option for Radio, Dropdown and Multi Checkboxes */
  removeOption(key) {
    this.temparray = <FormArray>this.questionForm.controls['options'];
    this.temparray.removeAt(key);
  }

  addquestion() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.maxWidth = '700px';
    dialogConfig.panelClass = 'repeatDialog';
    dialogConfig.disableClose = true;
    dialogConfig.closeOnNavigation = true;
    this.dialogRefs = this.dialog.open(this.addQuestion, dialogConfig);
  }

  closeQuestionDialog(): void {
    this.dialogRefs.close();
    this.isEdit = false;
    this.isOptionField = false;
    this.questionForm.reset();
    this.temparray = <FormArray>this.questionForm.controls['options'];
    this.temparray = <FormArray>this.questionForm.controls['options'];
    for (let i = this.temparray.length - 1; i >= 2; i--) {
      this.temparray.removeAt(i);
    }
  }

  getFieldType(event = '') {
    if (this.question.type === 'radio' || this.question.type === 'select' || this.question.type === 'checkbox') {
      this.btnClass = this.question.type + 'btn';
      this.isOptionField = true;
      this.temparray = <FormArray>this.questionForm.controls['options'];
      if (this.temparray.length < 2) {
        this.temparray.push(this.setInputType());
      }
    } else {
      this.isOptionField = false;
      this.btnClass = '';
      this.temparray = [this.setInputType()];
    }
  }

  async saveQuestionDialog(report, isValid) {
    if (this.questionForm.valid) {
      this._commonService.setLoader(true);
      const data = {
        '_id': this.questionForm.controls._id.value,
        'is_visitor': true,
        'type': this.questionForm.controls.type.value,
        'question': this.questionForm.controls.question.value,
        'options': (this.isOptionField) ? this.questionForm.controls.options.value : [],

      };

      const action = {
        type: 'POST',
        target: 'questions/add'
      };
      const payload = data;
      const result = await this.apiService.apiFn(action, payload);
      if (result['data']['status']) {
        this.toastr.success(result['message']);

        this.closeQuestionDialog();
        this.getServerData(this.pagiPayload);
        this._commonService.setLoader(true);
      } else {
        this._commonService.setLoader(false);
        this.toastr.error(result['message']);
      }
    } else {
      this.toastr.error('Please fill all fields');
      this._commonService.setLoader(false);
    }
  }

  async editQuestion(questionId) {
    this.isEdit = true;
    this._commonService.setLoader(true);
    const action = {
      type: 'POST', target: 'questions/view'
    };
    const payload = { questionId: questionId };
    let result = await this.apiService.apiFn(action, payload)
    this.question = result['data']['_question'];
    this._commonService.setLoader(false);
    this.temparray = <FormArray>this.questionForm.controls['options'];

    if (this.question.options.length > 1) {
      this.question.options.forEach((element, ind) => {
        if (ind >= this.temparray.length) {
          this.addOption();
        }

      });
    }
    this.questionForm.patchValue(this.question);
    this.getFieldType();
    this.addquestion();

  }

  dropTable(event: CdkDragDrop<[]>) {
    const prevIndex = this.dataSource.filteredData.findIndex((d) => d === event.item.data);
    const arr = {
      _id: event.item.data._id,
      previous_order: prevIndex + 1 + (this.pagiPayload.pageIndex * this.pagiPayload.pageSize),
      current_order: event.currentIndex + 1 + (this.pagiPayload.pageIndex * this.pagiPayload.pageSize)
    };
    if (prevIndex !== event.currentIndex) {
      this.exchangeOrder(arr);
    }

    moveItemInArray(this.dataSource.filteredData, prevIndex, event.currentIndex);
    this.table.renderRows();
  }

  async exchangeOrder(arr) {
    const data = {
      _id: arr._id,
      previous_order: arr.previous_order,
      current_order: arr.current_order
    };

    const action = {
      type: 'POST',
      target: 'questions/exchangeOrder'
    };
    const payload = data;

    const result = await this.apiService.apiFn(action, payload);

  }
  async changeStatus(event, question_id) {
    const action = { type: 'POST', target: 'questions/changeStatus' };
    const payload = { 'status': event.checked, 'questionId': question_id };
    const result = await this.apiService.apiFn(action, payload);
  }

  questionType(type) {
    const ind = this.Question_Types.findIndex(item => item.type === type);
    if (ind > -1) {
      return this.Question_Types[ind].name;
    }
  }
}

export interface Element {
  position: number;
  name: string;
  weight: number;
  symbol: string;
}

export interface PagiElement {
  length: number;
  pageIndex: number;
  pageSize: number;
  previousPageIndex: number;
}

