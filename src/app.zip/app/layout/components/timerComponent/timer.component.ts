import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { Observable, timer, range } from 'rxjs'
import { take, map } from 'rxjs/operators';
@Component({
  selector: 'timer',

  template: `<p [style.color]="areTenSecsRemainings?'red':''" *ngIf="isShow">
<button mat-raised-button
        matTooltip="Info about the action"
        aria-label="Button that displays a tooltip when focused or hovered over">
  Action
</button>
<mat-icon matTooltip="Info about the action">alarm</mat-icon> {{timerValue?.days|number :'2.0'}} days, {{timerValue?.hours|number :'2.0'}}:{{timerValue?.minutes|number :'2.0'}}:{{timerValue?.seconds.toFixed() |number :'2.0' }}</p>`,

})
export class TimerComponent implements OnInit {
  @Input() endDate: number
  @Input() id:string;
  @Output('onComplete') timerOver: EventEmitter<any> = new EventEmitter<any>();
  timerValue
  areTenSecsRemainings: boolean = false;
  value;
  isShow: boolean;
  constructor() { }

  ngOnInit() {
    this.changeTime();
   }

  changeTime(){
    let t1 = new Date(this.endDate);
    let t2 = new Date();
    if (t1 > t2) {
      this.isShow = true;
    } else {
      this.isShow = false;
    }
    let dif = t1.getTime() - t2.getTime();

    let Seconds_from_T1_to_T2 = dif / 1000;
    this.value = Math.abs(Seconds_from_T1_to_T2);
    let source$: Observable<number> = range(0, this.value);

    source$ = timer(0, 1000).pipe(
      take(this.value),
      map(() => --this.value)
    );

    source$.subscribe(seconds => {


      let remainingSecs = seconds;
      let days = Math.floor(seconds / (3600 * 24));
      seconds -= days * 3600 * 24;
      let hrs = Math.floor(seconds / 3600);
      seconds -= hrs * 3600;
      let mins = Math.floor(seconds / 60);
      seconds -= mins * 60;
      if (remainingSecs < 60) this.areTenSecsRemainings = true
      let res = {
        'days': days,
        'hours': hrs,
        'minutes': mins,
        'seconds': seconds
      }
      if (days == 0 && hrs == 0 && mins == 0 && seconds < 1) {
        this.isShow = false;
        this.timerOver.emit({endTimer:this.id})
      }
      this.timerValue = res;
    }, () => this.timerOver.emit('TIMER ERROR'), () => this.timerOver.emit('TIMER OVER'))
  
  }

}
