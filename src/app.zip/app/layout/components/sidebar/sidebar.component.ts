import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { ApiService } from 'src/app/shared/services/api/api.service';
import { insertRefFn } from '../../../shared/store/shiftReport/action';
import { insertFn } from '../../../shared/store/auth/action';
import { Socket } from 'ngx-socket-io';
import { CommonService } from './../../../shared/services/common.service';
import { AuthGuard } from './../../../shared/guard/auth.guard';

interface ShiftRepState {
    _shiftRep: object;
}

interface AuthState {
    _authUser: object;
}

@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.scss']
})

export class SidebarComponent implements OnInit {
    panelOpenState = false;
    public showMenu: string;
    username;
    data;
    jobTitle;
    captionName;
    haveData: any;
    socket;
    constructor(
        private _authUser: Store<AuthState>,
        private _shiftRep: Store<ShiftRepState>,
        private _apiService: ApiService,
        private _socket: Socket,
        public _commonService: CommonService,
        public _authGuard: AuthGuard
    ) { }

    async ngOnInit() {
        this._authUser.select('authState').subscribe(sub => {
            this.haveData = sub;
        });
        if (!this.haveData['userName']) {
            this.showMenu = '';
            const action2 = { type: 'GET', target: 'users/user_detail' };
            const payload2 = {};
            const userDetails = await this._apiService.apiFn(action2, payload2);
            if (userDetails['status'] === true) {
                this.captionName = userDetails['data']['first_name'].substring(0, 1) + userDetails['data']['last_name'].substring(0, 1);
                const userName = userDetails['data']['first_name'] + ' ' + userDetails['data']['last_name'];
                this._shiftRep.dispatch(insertRefFn({ userName: userName }));
                this._authUser.dispatch(insertFn({
                    userName: userName,
                    first_name: userDetails['data']['first_name'],
                    last_name: userDetails['data']['last_name'],
                    jobTitle: userDetails['data']['job_title']['position_name'],
                    captionName: this.captionName
                }));
                this.setUserData();
            } else {
                this._authGuard.destroyToken(null);
            }
        } else {
            this.setUserData();
        }
    }

    setUserData() {
        this.data = JSON.parse(sessionStorage.getItem('authReducer'));
        this.username = this.data.first_name + ' ' + this.data.last_name;
        this.jobTitle = this.data.jobTitle;
        this.captionName = this.data.captionName;

        const thisObj = this;
        setTimeout(function () {
            thisObj.iAmConnectingFn();
        }, 5000);
    }

    async iAmConnectingFn() {
        const storeObj = await this._apiService.getauthData();
        if (storeObj['userName']) {
            this.socket = this._socket.emit('newConnectedUser', {
                platform: 'web',
                token: storeObj['token'],
                full_name: storeObj['userName'],
                first_name: storeObj['first_name'],
                last_name: storeObj['last_name'],
                user_id: storeObj['user_id']
            }, function (res) {
            });
        }
    }

    addExpandClass(element: any) {
        if (element === this.showMenu) {
            this.showMenu = '0';
        } else {
            this.showMenu = element;
        }
    }
}
