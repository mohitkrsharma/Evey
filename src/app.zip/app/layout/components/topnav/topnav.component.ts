import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { ApiService } from 'src/app/shared/services/api/api.service';
import { CommonService } from 'src/app/shared/services/common.service';
import { AuthGuard } from './../../../shared/guard/auth.guard';

@Component({
    selector: 'app-topnav',
    templateUrl: './topnav.component.html',
    styleUrls: ['./topnav.component.scss']
})

export class TopnavComponent implements OnInit {
    public pushRightClass: string;
    data;
    token;
    orgdata; floorlist;
    organization; facility;
    organiz = []; fac = [];
    selectedfac: String;
    selectedorg: any;
    changeorg = false;
    dataSource; orgfac;
    constructor(
        private _router: Router,
        private _apiService: ApiService,
        public _commonService: CommonService,
        public _authGuard: AuthGuard
    ) {
        this._router.events.subscribe(val => {
            if (val instanceof NavigationEnd && window.innerWidth <= 992 && this.isToggled()) {
                this.toggleSidebar();
            }
        });
    }

    ngOnInit() {
        this.pushRightClass = 'push-right';
        this.fetchData();
    }

    async fetchData() {
        const action = { type: 'GET', target: 'users/get_org' };
        const payload = {};
        const result = await this._apiService.apiFn(action, payload);
        this.orgdata = result;
        this.organiz = await result['data'].map(function (obj) {
            const rObj = {};
            rObj['label'] = obj._id.org.org_name;
            rObj['value'] = obj._id.org._id;
            return rObj;
        });

        if (this.organiz.length === 1) {
            this.organization = this.organiz[0].label;
            this.selectedorg = this.organiz[0].value;
            this.getFac(this.selectedorg);
        } else {
            const action = { type: 'GET', target: 'users/selected_org_fac' };
            const payload = {};
            const result = await this._apiService.apiFn(action, payload);
            if (result['data'].length) {
                this.selectedorg = result['data'][0].org;
                const payload = { org: this.selectedorg };
                const action1 = { type: 'GET', target: 'users/get_user_fac' };
                const result1 = await this._apiService.apiFn(action1, payload);
                this.fac = await result1['data'].map(function (obj) {
                    const fObj = {};
                    fObj['label'] = obj._id.fac.fac_name;
                    fObj['value'] = obj._id.fac._id;
                    return fObj;
                });
                this.selectedfac = result['data'][0].fac;
                this.changeSelection(this.selectedorg, this.selectedfac);

            } else {
                this.selectedorg = result['data']['facility'][0].org;
                const payload = { org: this.selectedorg };
                const action1 = { type: 'GET', target: 'users/get_user_fac' };
                const result1 = await this._apiService.apiFn(action1, payload);
                this.fac = await result1['data'].map(function (obj) {
                    const fObj = {};
                    fObj['label'] = obj._id.fac.fac_name;
                    fObj['value'] = obj._id.fac._id;
                    return fObj;
                });
                this.selectedfac = result['data']['facility'][0].fac;
                this.changeSelection(this.selectedorg, this.selectedfac);
            }
        }
    }

    async getFac(org) {
        const payload = { org: org };
        const action1 = { type: 'GET', target: 'users/get_user_fac' };
        const result1 = await this._apiService.apiFn(action1, payload);
        this.fac = await result1['data'].map(function (obj) {
            const fObj = {};
            fObj['label'] = obj._id.fac.fac_name;
            fObj['value'] = obj._id.fac._id;
            return fObj;
        });
        if (!this.changeorg) {
            if (this.fac.length === 1) {
                this.facility = this.fac[0].label;
                this.selectedfac = this.fac[0].value;
                this.changeSelection(this.selectedorg, this.selectedfac);
            }
            if (this.organiz.length === 1 && this.fac.length !== 1) {
                let facId, orgId;
                await this.orgdata['data'].map(function (obj) {
                    obj.facility.forEach(element => {
                        if (element.selected === true) {
                            facId = element.fac;
                        }
                    });
                });
                if (facId) {
                    this.selectedfac = facId;
                    this.changeSelection(this.selectedorg, this.selectedfac);
                }
            }
        }
    }

    async selectOrganization(org) {
        this.changeorg = true;
        this.selectedfac = '';
        this.getFac(org);
    }

    isToggled(): boolean {
        const dom: Element = document.querySelector('body');
        return dom.classList.contains(this.pushRightClass);
    }

    toggleSidebar() {
        const dom: any = document.querySelector('body');
        dom.classList.toggle(this.pushRightClass);
    }

    async onLoggedout() {
        this._authGuard.destroyToken('User has been logged out successfully.');
    }

    onClickBuildVersion(): void {
        this._router.navigate(['./settings/build_restriction']);
    }

    // Change facility
    async changeSelection(org, fac) {
        const action = { type: 'POST', target: 'users/set_selected_fac' };
        const payload = { org: org, fac: fac };
        const result = await this._apiService.apiFn(action, payload);
        this.floorlist = result['data'].map(function (obj) {
            const rObj = {};
            rObj['label'] = obj.floor;
            rObj['value'] = obj._id;
            rObj['sector'] = obj.sector;
            return rObj;
        });
        this._commonService.setOrgFac(payload, this.floorlist);
        this._commonService.setFloor(this.floorlist);
    }
}
