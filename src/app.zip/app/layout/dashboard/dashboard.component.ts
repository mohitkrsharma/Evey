import { Component, OnInit, OnDestroy, ViewChild, TemplateRef } from '@angular/core';
import { PageEvent } from '@angular/material';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ApiService } from './../../shared/services/api/api.service';
import { Router } from '@angular/router';
import { CommonService } from './../../shared/services/common.service';
import * as moment from 'moment';
import { SocketService } from './../../shared/services/socket/socket.service';
import { PlatformLocation } from '@angular/common';
import { Aes256Service } from './../../shared/services/aes-256/aes-256.service';
import { Subscription } from 'rxjs';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { ChartType, MultiDataSet, Label, ChartOptions } from 'chart.js';

export interface UserData {
  id: string;
  name: string;
  progress: string;
  color: string;
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})

export class DashboardComponent implements OnInit, OnDestroy {

  public doughnutChartLabels: Label[] = ['Active', 'Battery below 30%', 'Battery below 10%'];
  public doughnutChartData: MultiDataSet = [[60, 30, 10]];
  public doughnutChartType: ChartType = 'doughnut';

  pageEvent: PageEvent;

  showLink = false;
  showstatusLink = false;
  organiz = [];
  fac = [];

  linkForm: any = {
    organization: '',
    facility: '',
    userId: '',
  };
  statusForm: any = {
    organization: '',
    facility: '',
    userId: ''
  };
  link; statuslink;
  flag = true;
  status = false;
  live = false;
  dialogRefs = null;

  @ViewChild('callRepeatDialog') callRepeatDialog: TemplateRef<any>;
  @ViewChild(MatSort) sort: MatSort;

  columnNames = [
    { id: 'resident_name', value: 'Resident' },
    { id: 'room', value: 'Rm' },
    { id: 'care', value: 'Care' },
    { id: 'user', value: 'Started By' },
    { id: 'pause_time', value: 'Pause Time' }
  ];

  dataSource;
  openCareCount = 0;
  public show = false;
  public buttonName: any = 'Show';
  displayedColumns = [];
  pagiPayload: PagiElement = {
    length: 0,
    pageIndex: 0,
    pageSize: 7,
    previousPageIndex: 0
  };

  hide = false;

  announce;
  livedashboard;
  facility;
  orginization;
  public links = false;
  public statuslinks = false;


  private subscription: Subscription;
  private subscriptiondata: Subscription;
  private announcementSubscribe: Subscription;

  constructor(
    private _apiService: ApiService,
    private _router: Router,
    private _socketService: SocketService,
    private _dialog: MatDialog,
    public _platformLocation: PlatformLocation,
    public _aes256Service: Aes256Service,
    public _commonService: CommonService
  ) {
  }

  dashBoardLink() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.maxWidth = '700px';
    dialogConfig.panelClass = 'repeatDialog';
    dialogConfig.disableClose = true;
    this.dialogRefs = this._dialog.open(this.callRepeatDialog, dialogConfig);
  }

  closeDialog(): void {
    this.dialogRefs.close();
  }

  hideAnnouncemnt(index) {
    this.announce.splice(index, 1);
  }

  /* Copy to clipboard */
  copyInputMessage(inputElement) {
    inputElement.select();
    document.execCommand('copy');
    inputElement.setSelectionRange(0, 0);
  }

  async ngOnInit() {
    this._commonService.setLoader(true);
    sessionStorage.removeItem('pageListing');
    this.livedashboard = sessionStorage.getItem('enable_livedashboard');
    this.displayedColumns = this.displayedColumns.concat(this.columnNames.map(x => x.id));
    this.subscription = this._commonService.contentdata.subscribe(async (contentVal: any) => {
      if (contentVal.org && contentVal.fac) {
        this._commonService.setLoader(true);
        const payload = {};
        payload['organization'] = this.orginization = this.pagiPayload['organization'] = contentVal.org;
        payload['facility'] = this.facility = this.pagiPayload['facility'] = contentVal.fac;
        const action = { type: 'POST', target: 'announcement/get' };
        const result = await this._apiService.apiFn(action, payload);
        this.announce = result['data'];
        this.openVisits(this.pagiPayload);
        this._commonService.setLoader(false);
      }
    });

    this.getAnnouncementFn();
    this.getOrganization();

    this.subscriptiondata = this._socketService.onTrackCareUpdateFn().subscribe(_response => {
      if (_response) {
        this.openVisits(this.pagiPayload);
      }
    });

  }

  async getOrganization() {
    const action = { type: 'GET', target: 'users/get_org' };
    const payload = {};
    const result = await this._apiService.apiFn(action, payload);
    this.organiz = await result['data'].map(function (obj) {
      const rObj = {};
      rObj['label'] = obj._id.org.org_name;
      rObj['value'] = obj._id.org._id;
      return rObj;
    });
  }

  async selectFacility(fac, type) {
    if (type === 'live') {
      this.linkForm.facility = fac;
    } else {
      this.statusForm.facility = fac;
    }
    this.showLink = false;
    this.showstatusLink = false;
  }

  async selectOrganization(org, type) {
    if (type === 'live') {
      this.linkForm.organization = org;
    } else {
      this.statusForm.organization = org;
    }
    const payload = { org: org };
    const action1 = { type: 'GET', target: 'users/get_user_fac' };
    const result1 = await this._apiService.apiFn(action1, payload);
    this.fac = await result1['data'].map(function (obj) {
      const fObj = {};
      fObj['label'] = obj._id.fac.fac_name;
      fObj['value'] = obj._id.fac._id;
      return fObj;
    });
    this.showLink = false;
    this.showstatusLink = false;
  }

  getAnnouncementFn() {
    this.announcementSubscribe = this._socketService.getAnnouncementFn().subscribe(async (res: any) => {
      if (res.length > 1) {
        const payload = {};
        payload['organization'] = this.facility;
        payload['facility'] = this.orginization;
        const action = { type: 'POST', target: 'announcement/get' };
        const result = await this._apiService.apiFn(action, payload);
        this.announce = result['data'];
      } else {
        const index = res[0].facility.findIndex(item => item.fac === this.facility && item.org === this.orginization);
        if (index > -1) {
          const _ind = this.announce.findIndex(item => item._id === res[0]._id);
          if (_ind > -1) {
            this.announce.splice(_ind, 1, res[0]);
            this.announce = this.announce.filter(_item => _item.deleted === false && _item.isactive === true);
          } else {
            this.announce.unshift(res[0]);
          }
        }
      }
    });
  }

  createTable(arr) {
    const tableArr: Element[] = arr;
    this.dataSource = new MatTableDataSource(tableArr);
    this.dataSource.sort = this.sort;
  }

  async openVisits(event?: PageEvent) {
    const action = { type: 'GET', target: 'dashboard/openvisits' };
    const payload = {
      flag: 'dash',
      startDate: moment().valueOf(),
      endDate: moment().subtract(24, 'hours').valueOf()
    };
    let result = await this._apiService.apiFn(action, payload);
    if (result['status']) {
      this.openCareCount = result['data']['_count'];
      result = result['data']['_openvisits'].map(item => {
        return {
          ...item,
          resident_name: item.resident_name ? item.resident_name : '--',
          care: item.care ? item.care.name : '--',
          careImage: item.care && item.care.image ? item.care.image : null,
          start_time: item.ts_total_time ? moment(item.ts_total_time.start_time).format('MMMM Do YYYY, HH:mm') : '--',
          pause_time: item.ts_total_time ? moment(item.ts_total_time.end_time).format('MMMM Do YYYY, HH:mm') : '--',
          user: item.user_name
        };
      });
      this.createTable(result);
    }
  }

  viewOpenvisits() {
    this._commonService.setLoader(true);
    this._router.navigate(['/open-visits']);
  }

  async onSubmit(f) {
    const valid = f.form.status;
    if (valid === 'VALID' && this.showLink === false) {
      this.showLink = true;
      this.linkForm.userId = sessionStorage.getItem('user_Id');
      const hashingPayload = (this._aes256Service.encFnWithsalt(this.linkForm)).replace(/\//g, '*');
      this.link = (this._platformLocation as any).location.origin + '/livedashboard/' + hashingPayload;
      this.links = true;
    }
  }

  async statusLink(f) {
    const valid = f.form.status;
    if (valid === 'VALID' && this.showstatusLink === false) {
      this.showstatusLink = true;
      this.statusForm.userId = sessionStorage.getItem('user_Id');
      const hashingPayload = (this._aes256Service.encFnWithsalt(this.statusForm)).replace(/\//g, '*');
      this.statuslink = (this._platformLocation as any).location.origin + '/statusdashboard/' + hashingPayload;
      this.statuslinks = true;
    }
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  goShiftReport(): void {
    this._commonService.setLoader(true);
    this._router.navigate(['/reports/shiftcereport']);
  }

  goMissedChkInReport(): void {
    this._commonService.setLoader(true);
    this._router.navigate(['/reports/missedlevel1checkin']);
  }

  goCustomReport(): void {
    this._commonService.setLoader(true);
    this._router.navigate(['/reports/report']);
  }

  goSchedule(): void {
    this._commonService.setLoader(true);
    this._router.navigate(['/scheduling']);
  }

  ngOnDestroy(): void {
    if (this.subscriptiondata) {
      this.subscriptiondata.unsubscribe();
      this.announcementSubscribe.unsubscribe();
    }
  }

}
export interface Element {
  position: number;
  name: string;
  weight: number;
  symbol: string;
}
export interface PagiElement {
  length: number;
  pageIndex: number;
  pageSize: number;
  previousPageIndex: number;
}
