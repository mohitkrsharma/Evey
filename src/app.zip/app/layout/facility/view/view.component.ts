import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from './../../../shared/services/api/api.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent implements OnInit {
  facility;
  loader = false;
  constructor(private route: ActivatedRoute,
    private router: Router,
    private apiService: ApiService,
    private _location: Location) { }

  async ngOnInit() {
    this.loader = true;
    const id = this.route.params['_value']['id'];
    const action = { type: 'POST', target: 'facility/view' };
    const payload = { facilityId: id };
    const result = await this.apiService.apiFn(action, payload);
    this.facility = result['data'];
    this.loader = false;
  }

  editFacility(id) {
    this.router.navigate(['/facility/form', id]);
  }

  cancel() {
    this._location.back();
  }


}
