// ANGULAR LIB
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule, MatCheckboxModule, MatInputModule, MatDividerModule,MatListModule } from '@angular/material';
import {
  MatTableModule, MatSortModule, MatSelectModule, MatFormFieldModule, MatCardModule,
  MatProgressSpinnerModule,
  MatMenuModule,
  MatIconModule,
  MatToolbarModule,
  MatSlideToggleModule
} from '@angular/material'
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatExpansionModule} from '@angular/material/expansion';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatPaginatorModule } from '@angular/material/paginator';
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { ReportsRoutingModule } from './reports-routing.module';
import { FormComponent } from './form/form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModuleModule } from './../../shared-module/shared-module.module';
import { GetreportComponent } from './getreport/getreport.component';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { SavereportComponent } from '../../shared/modals/savereport/savereport.component';
import { NgxMatDrpModule } from 'ngx-mat-daterange-picker';
import { ViewComponent } from './view/view.component';
import { CarebyuseComponent } from './carebyuse/carebyuse.component';
import { CarebyresidentComponent } from './carebyresident/carebyresident.component';
import { MultipleemployeeComponent } from './multipleemployee/multipleemployee.component';
import { CarebyemployeeComponent } from './carebyemployee/carebyemployee.component';
import { CareperdayComponent } from './careperday/careperday.component';
import { CarebytimeComponent } from './carebytime/carebytime.component';
import { CalendarModule } from 'primeng/calendar';
import { SingleemployeComponent } from './singleemploye/singleemploye.component';
import { ShiftperformancereportComponent } from './shiftperformancereport/shiftperformancereport.component';
import { MatRadioModule } from '@angular/material/radio';
import { ShiftreportComponent } from './shiftperformancereport/shiftreport/shiftreport.component';
import { ExportAsModule } from 'ngx-export-as';
import { OwlDateTimeModule, OwlNativeDateTimeModule, OWL_DATE_TIME_FORMATS } from 'ng-pick-datetime';
import { ViewCustomReportsComponent } from './view-custom-reports/view-custom-reports.component';
import { CarechartComponent } from './charts/carechart/carechart.component';
import { MissedcheckinbyshiftComponent } from './missedcheckinbyshift/missedcheckinbyshift.component';
// import {CalendarModule} from 'primeng/calendar';
import { ChartsModule } from 'ng2-charts/ng2-charts';

import { ListComponent } from './activity/list.component';

import { RoomCleaningReportComponent } from './roomcleaningreport/roomcleaningreport.component';
import { RoomCleanReportComponent } from './roomcleaningreport/roomcleanreport/roomcleanreport.component';
import { AmazingTimePickerModule } from 'amazing-time-picker';
export const DATE_NATIVE_FORMATS = {
  fullPickerInput: {year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', hour12: false},
  datePickerInput: {year: 'numeric', month: 'numeric', day: 'numeric', hour12: false},
  timePickerInput: {hour: 'numeric', minute: 'numeric', hour12: false},
  monthYearLabel: {year: 'numeric', month: 'short'},
  dateA11yLabel: {year: 'numeric', month: 'long', day: 'numeric'},
  monthYearA11yLabel: {year: 'numeric', month: 'long'},
  };
@NgModule({
  declarations: [FormComponent, GetreportComponent,
     ViewComponent, CarebyuseComponent, CarebyresidentComponent, MultipleemployeeComponent,
      CarebyemployeeComponent, CareperdayComponent, CarebytimeComponent, SingleemployeComponent,
       ShiftperformancereportComponent, ShiftreportComponent, ViewCustomReportsComponent,
        CarechartComponent, MissedcheckinbyshiftComponent, ListComponent,
        RoomCleaningReportComponent,RoomCleanReportComponent],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    MatButtonModule,
    MatCheckboxModule,
    MatInputModule,
    ReportsRoutingModule,
    MatCardModule,
    MatProgressSpinnerModule,
    MatMenuModule,
    MatIconModule,
    MatToolbarModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatSortModule,
    MatTableModule,
    MatPaginatorModule,
    SharedModuleModule,
    AngularMultiSelectModule,
    NgxMatDrpModule,
    MatDividerModule,
    CalendarModule,
    MatDatepickerModule,
    MatExpansionModule,
    MatRadioModule,
    NgxDaterangepickerMd.forRoot(),
    ExportAsModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule,
    MatProgressBarModule,
    ChartsModule,
    MatSlideToggleModule,
    MatListModule,
    AmazingTimePickerModule
  ],
  providers:[
    { provide: OWL_DATE_TIME_FORMATS, useValue: DATE_NATIVE_FORMATS }
  ]
})
export class ReportsModule { }



