import { Component, OnInit, ElementRef, ViewChild, HostListener } from '@angular/core';
import { Store } from '@ngrx/store';
import { ApiService } from 'src/app/shared/services/api/api.service';
import { ToastrService } from 'ngx-toastr';
import { ExcelService } from './../../../../shared/services/excel.service';
import { ExportAsService, ExportAsConfig } from 'ngx-export-as';
import * as jspdf from 'jspdf';
import * as _ from 'underscore';
import * as xlsx from 'xlsx';
import * as asyncfunc from 'async';
import * as moment from 'moment';

import { CommonService } from './../../../../shared/services/common.service';
@Component({
  selector: 'app-shiftreport',
  templateUrl: './shiftreport.component.html',
  styleUrls: ['./shiftreport.component.scss']
})

export class ShiftreportComponent implements OnInit {
  constructor(
    private apiService: ApiService,
    private excelService: ExcelService,
    private toastr: ToastrService,
    private exportAsService: ExportAsService,
    public commonService:CommonService
  ) { }

  countReportvalue;
  boxResultvalue;
  userResults = {};
  selectShift;
  shiftNo;
  residentList;
  data;
  start_date;
  end_date;
  userName;
  resultcount;
  isShow: boolean;
  topPosToStartShowing = 100;
  sTime;
  eTime;
  exportArr = [];
  allUserData: any;
  margins = {
    top: 100,
    bottom: 50,
    left: 25,
    right: 30,
    width: 550
  };

  @ViewChild('content') content: ElementRef;

  @HostListener('window:scroll')
  checkScroll() {
    // window의 scroll top
    // Both window.pageYOffset and document.documentElement.scrollTop 
    // returns the same result in all the cases. window.pageYOffset is not supported below IE 9.
    const scrollPosition = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
    if (scrollPosition >= this.topPosToStartShowing) {
      this.isShow = true;
    } else {
      this.isShow = false;
    }
  }

  // TODO: Cross browsing
  gotoTop() {
    window.scroll({ top: 0, left: 0, behavior: 'smooth' });
  } ngOnInit() {
    this.data = JSON.parse(sessionStorage.getItem('shiftRep_Reducer'));
    this.end_date = this.data.end_date;
    this.start_date = this.data.start_date;
    this.userName = this.data.userName;
    this.shiftNo = this.data.shift;
    this.loadReport();
  }

  async loadReport() {
    this.commonService.setLoader(true);
    const action = { type: 'POST', target: 'reports/shiftCountreport' };
    const payload = this.data;
  
    const result = await this.apiService.apiFn(action, payload);
    this.residentList = result['data']['reports']['reportValue'];
    this.countReportvalue = result['data']['reports']['reportValue'];
    this.boxResultvalue = result['data']['reports']['totalReport'];
    if (this.shiftNo === 1) {
      this.selectShift = '1st Shift (6:00am - 2:00pm)';
    } else if (this.shiftNo === 2) {
      this.selectShift = '2nd Shift (2:00pm - 10:00pm)';
    } else {
      this.selectShift = '3rd Shift (10:00pm - 6:00am)';
    }
    if (this.residentList && this.residentList.length > 0) {
      this.resultcount = true;
    } else {
      this.resultcount = false;
    }
    this.commonService.setLoader(false);
  }

  async getData(userID) {
    this.commonService.setLoader(true);
    const action = { type: 'POST', target: 'reports/shiftReport' };
    let payload = this.data;
    
    payload.user_id = userID;
    const result = await this.apiService.apiFn(action, payload);
    var finaldata = result['data']['_report'];
    console.log('finaldatafinaldata', finaldata);
    const action1 = { type: 'POST', target: 'reports/shiftLgonNLogout' };
    payload.user_id = userID;
    const result1 = await this.apiService.apiFn(action1, payload);
    if (result1['data']['careTypeData'] && result1['data']['careTypeData'].length > 0) {
      var newArray = await result1['data']['careTypeData'].reduce((obj, item) => {
        let o = {
          residentList: [{
            "CtotalMinutes": 0,
            "Notes": "",
            "care": "",
            "level": "",
            "outcome": item.activity_name,// === "iOS: Logout Successful"?"Logout":"Login",
            "performedDate": item.date,
            "residentName": "",
            "room": "",
            "roomDate": "",
            "roomId": "",
            "totalMinutes": 0
          }],
          "total": "total"
        }
        obj.push(o);
        return obj;
      }, [])

      if (newArray && newArray.length > 0) {
        this.userResults[userID] = [...finaldata, ...newArray];
        this.userResults[userID] = _.sortBy(this.userResults[userID], function (o) {
          return -o.residentList[0].performedDate;
        });
      }
    } else {
      this.userResults[userID] = finaldata;
    }
    this.commonService.setLoader(false);
    return this.userResults[userID];
    
  }

  async expandPanel(userID) {
    event.stopPropagation();
    if (!this.userResults.hasOwnProperty(userID)) {
      await this.getData(userID);
    }
  }

  formatDate(time) {
    if (time) {
      const secondTime =  moment(time).format('ss');
      const secondPTime = parseInt(secondTime);
      if (secondPTime < 30) {
        return moment(time).format('MMMM Do YYYY, hh:mm A');
      } else {
        return moment(time).add(1, 'minutes').format('MMMM Do YYYY, hh:mm A');
      }
    } else {
      return '';
    }
  }

  headerFooterFormatting(doc, totalPages) {
    for (let i = totalPages; i >= 1; i--) {
      doc.setPage(i);
      // header
      this.header(doc);

      this.footer(doc, i, totalPages);
      doc.page++;
    }
  }

  header(doc) {
    let count;

    doc.printHeaders = false;
    doc.printingHeaderRow = false;
    doc.tableHeaderRow = [[]];
    // if (base64Img) {
    //   doc.addImage(base64Img, 'JPEG', this.margins.left, 10, 40, 40);
    // }

    // doc.text("Report Header Template", this.margins.left + 50, 40);

  }
  footer(doc, pageNumber, totalPages) {

    const str = 'Page ' + pageNumber + ' of ' + totalPages;

    // doc.setFontSize(10);
    doc.text(str, this.margins.left, doc.internal.pageSize.height - 20);

  }

  async download(userId) {
    let startDate = new Date(this.start_date);
    let endDate = new Date(this.end_date);
    let shiftReport = await this.prepareForExport(userId, startDate, endDate);
    await this.excelService.exportAsExcelFile(shiftReport, 'Shift performance report');
  }


  async prepareForExport(userId, startDate, endDate) {
    var arr = [];
    let shiftreport = [];
    if (this.userResults.hasOwnProperty(userId)) {
      arr = this.userResults[userId];
    } else {
      await this.getData(userId)
      arr = this.userResults[userId];
    }
    let nextRow = {
      "Shift Performance Report": 'Created by :',// + this.userName,
      "": this.userName,
      " ": '',
      "  ": '',
      "   ": '',
      "    ": '',
      "     ": '',
      "      ": '',
    }

    shiftreport.push(nextRow);
    let nextRow1 = {
      "Shift Performance Report": startDate.getMonth() + "/" + startDate.getDate() + "/" + startDate.getFullYear() + ' - ' + endDate.getMonth() + "/" + endDate.getDate() + "/" + endDate.getFullYear(),
      "": '',
      " ": '',
      "  ": '',
      "   ": '',
      "    ": '',
      "     ": '',
      "      ": '',
    }
    shiftreport.push(nextRow1);
    let blackSpace = {
      "Shift Performance Report": '',
      "": '',
      " ": '',
      "  ": '',
      "   ": '',
      "    ": '',
      "     ": '',
      "      ": '',
    }
    shiftreport.push(blackSpace);
    let nextRow2 = {
      "Shift Performance Report": this.selectShift,
      "": '',
      " ": '',
      "  ": '',
      "   ": '',
      "    ": '',
      "     ": '',
      "      ": '',
    }
    shiftreport.push(nextRow2);
    shiftreport.push(blackSpace);
    let table1 = {
      "Shift Performance Report": 'Employee',
      "": 'Total Cares Performed',
      " ": 'Time on Care',
      "  ": 'Time Unassigned',
      "   ": 'Total Time',
      "    ": '',
      "     ": '',
      "      ": ''
    }
    shiftreport.push(table1);

    let userCountData = this.countReportvalue.reduce((obj, item) => {
      if (item.userData.userId == userId) {
        obj = item;
      }
      return obj;
    }, {})
    let table1Data = {
      "Shift Performance Report": userCountData.userData.first_name + ' ' + userCountData.userData.last_name,
      "": userCountData.report.totalCare,
      " ": userCountData.report.totalCareTime,
      "  ": userCountData.report.totalUnassignedTime,
      "   ": userCountData.report.totalTime,
      "    ": '',
      "     ": '',
      "      ": ''
    }
    shiftreport.push(table1Data);
    shiftreport.push(blackSpace);
    let userCareheading = {
      "Shift Performance Report": "Resident",
      "": "Level",
      " ": "Room",
      "  ": "Care",
      "   ": "Outcome",
      "    ": "Total Minutes",
      "     ": "Performed Date",
      "      ": "Note"
    }
    shiftreport.push(userCareheading);

    arr.forEach(item => {

      item.residentList.forEach(obj => {
        shiftreport.push({
          "Shift Performance Report": obj.residentName,
          "": obj.level,
          " ": obj.room,
          "  ": obj.care,
          "   ": obj.outcome,
          "    ": obj.totalMinutes,
          "     ": obj.performedDate ? this.formatDate(obj.performedDate) : '--',//new Date(obj.performedDate),
          "      ": obj.Notes,
        });
      });
      shiftreport.push({
        "Shift Performance Report": "Total",
        "": null,
        " ": null,
        "  ": null,
        "   ": null,
        "    ": item.total == "total" ? " " : item.total,
        "     ": null,
        "      ": null
      });
    });
    return shiftreport;
  }

  downloadAll() {
    let startDate = new Date(this.start_date);
    let endDate = new Date(this.end_date);
    let thisObj = this;

    asyncfunc.eachOfSeries(this.countReportvalue, function (item, i, callback) {
      if (thisObj.userResults.hasOwnProperty(item.userData.userId)) {
        callback(null, true);
      } else {
        thisObj.getData(item.userData.userId).then((res) => {
          callback(null, true);
        });
      }

    }, function (err, result) {
      if (err) {

      } else {
        let shiftReport = thisObj.prepareForExportAll(startDate, endDate);
        thisObj.excelService.exportAsExcelFile(shiftReport, 'Shift performance report');
      }

    });
  }

  prepareForExportAll(startDate, endDate) {
    var arr = [];
    let shiftreport = [];

    shiftreport.push({
      "Shift Performance Report": '',
      "": '',
      " ": '',
      "  ": '',
      "   ": '',
      "    ": '',
      "     ": '',
      "      ": '',
    });

    let nextRow = {
      "Shift Performance Report": 'Created by :',// + this.userName,
      "": this.userName,
      " ": '',
      "  ": '',
      "   ": '',
      "    ": '',
      "     ": '',
      "      ": '',
    }

    shiftreport.push(nextRow);
    let nextRow1 = {
      "Shift Performance Report": startDate.getMonth() + "/" + startDate.getDate() + "/" + startDate.getFullYear() + ' - ' + endDate.getMonth() + "/" + endDate.getDate() + "/" + endDate.getFullYear(),
      "": '',
      " ": '',
      "  ": '',
      "   ": '',
      "    ": '',
      "     ": '',
      "      ": '',
    }
    shiftreport.push(nextRow1);
    let blackSpace = {
      "Shift Performance Report": '',
      "": '',
      " ": '',
      "  ": '',
      "   ": '',
      "    ": '',
      "     ": '',
      "      ": '',
    }
    shiftreport.push(blackSpace);
    let nextRow2 = {
      "Shift Performance Report": this.selectShift,
      "": '',
      " ": '',
      "  ": '',
      "   ": '',
      "    ": '',
      "     ": '',
      "      ": '',
    }
    shiftreport.push(nextRow2);
    shiftreport.push(blackSpace);
    let table1 = {
      "Shift Performance Report": 'Employee',
      "": 'Total Cares Performed',
      " ": 'Time on Care',
      "  ": 'Time Unassigned',
      "   ": 'Total Time',
      "    ": '',
      "     ": '',
      "      ": ''
    }
    shiftreport.push(table1);

    let userCountData = this.countReportvalue;
    userCountData.forEach(item => {
      let table1Data = {
        "Shift Performance Report": item.userData.first_name + ' ' + item.userData.last_name,
        "": item.report.totalCare,
        " ": item.report.totalCareTime,
        "  ": item.report.totalUnassignedTime,
        "   ": (item.report.totalCareTime + item.report.totalUnassignedTime),
        "    ": '',
        "     ": '',
        "      ": ''
      }
      shiftreport.push(table1Data);
    })

    shiftreport.push(blackSpace);
    shiftreport.push(blackSpace);

    let uu = this.countReportvalue;
    uu.forEach(i => {
      let nameofuser = {
        "Shift Performance Report": i.userData.first_name + ' ' + i.userData.last_name,
        "": '',
        " ": '',
        "  ": '',
        "   ": '',
        "    ": '',
        "     ": '',
        "      ": '',
      }
      shiftreport.push(nameofuser);
      shiftreport.push(blackSpace);
      let userCareheading = {
        "Shift Performance Report": "Resident",
        "": "Level",
        " ": "Room",
        "  ": "Care",
        "   ": "Outcome",
        "    ": "Total Minutes",
        "     ": "Performed Date",
        "      ": "Note"
      }
      shiftreport.push(userCareheading);

      this.userResults[i.userData.userId].forEach(item => {

        item.residentList.forEach(obj => {
          shiftreport.push({
            "Shift Performance Report": obj.residentName,
            "": obj.level,
            " ": obj.room,
            "  ": obj.care,
            "   ": obj.outcome,
            "    ": obj.totalMinutes,
            "     ": obj.performedDate ? this.formatDate(obj.performedDate) : '--',//new Date(obj.performedDate),
            // "     ": obj.performedDate ? moment(obj.performedDate).format("MMMM Do YYYY, HH:mm") : '--',//new Date(obj.performedDate),
            "      ": obj.Notes,
          });
        });
        shiftreport.push({
          "Shift Performance Report": "Total",
          "": null,
          " ": null,
          "  ": null,
          "   ": null,
          "    ": item.total == "total" ? " " : item.total,
          "     ": null,
          "      ": null
        });


      });
      shiftreport.push(blackSpace);
    });
    return shiftreport;
  }
}

