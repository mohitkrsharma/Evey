import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { MatTableDataSource, MatSort, PageEvent } from '@angular/material';
import { Router } from '@angular/router';
import { ApiService } from '../../../shared/services/api/api.service';
import { MatDialog } from '@angular/material/dialog';
import { ExcelService } from '../../../shared/services/excel.service';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../../../shared/services/common.service';
import * as moment from 'moment';
import { NgxDrpOptions, PresetItem, Range } from 'ngx-mat-daterange-picker';
import * as async from 'async';


@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})

export class ListComponent implements OnInit {
  public btnAction: Function;
  exportdata;
  // MATPAGINATOR
  datasource: null;
  pageIndex: number;
  pageSize: number;
  length: number;
  platform;
  user;
  dataSource;
  isShow: boolean;
  topPosToStartShowing = 100;
  loaderexport = false;
  loadervalue = 0; loaderbuffer = 2;
  displayedColumns = [];
  exportContentVal = [];
  @ViewChild(MatSort) sort: MatSort;
  sortActive = 'name';
  sortDirection: 'asc' | 'desc' | '';
  /**
   * Pre-defined columns list for user table
   */
  columnNames = [
    {
      id: 'user',
      value: 'User',
      sort: false
    }
    , {
      id: 'activity_name',
      value: 'Activity',
      sort: false
    }
    , {
      id: 'activity_from',
      value: 'Platform',
      sort: false
    }
    , {
      id: 'date',
      value: 'Date',
      sort: true
    }];

  pagiPayload: PagiElement = {
    length: 0,
    pageIndex: 0,
    pageSize: 10,
    previousPageIndex: 0
 };

  data = [
    {
      'value': 'iOS',
      'label': 'Mobile'
    },
    {
      'value': 'Web',
      'label': 'Web'
    }
  ];
  count;
  public show = false;
  userslist;
  start_date = moment().subtract(10, 'years').set({ hour: 0, minute: 0, second: 0, millisecond: 0 }).unix() * 1000;
  end_date = moment().set({ hour: 23, minute: 59, second: 59, millisecond: 999 }).unix() * 1000;

  constructor(
    private router: Router,
    private apiService: ApiService,
    public dialog: MatDialog,
    private excelService: ExcelService,
    private toastr: ToastrService,
    private common: CommonService
  ) { }

  selected;
  alwaysShowCalendars: boolean;
  ranges: any = {
    'Today': [moment(), moment()],
    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
    'This Month': [moment().startOf('month'), moment().endOf('month')],
    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
  };
  range: Range = { fromDate: new Date(), toDate: new Date() };
  options: NgxDrpOptions;
  presets: Array<PresetItem> = [];
  @ViewChild('dateRangePicker') dateRangePicker;

  @HostListener('window:scroll')

  checkScroll() {

 // window의 scroll top
 const scrollPosition = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;

 if (scrollPosition >= this.topPosToStartShowing) {
 this.isShow = true;
 } else {
 this.isShow = false;
 }
 }

 // TODO: Cross browsing
 gotoTop() {
 window.scroll({
 top: 0,
 left: 0,
 behavior: 'smooth'
 });
 }

  ngOnInit() {
    sessionStorage.removeItem('pageListing');
    this.btnAction = this.addForm.bind(this);
    this.displayedColumns = this.displayedColumns.concat(['checkbox']);
    this.displayedColumns = this.displayedColumns.concat(this.columnNames.map(x => x.id));
    this.getServerData(this.pagiPayload);
    this.getAllusers();
  }

  updateRange(range: Range) {
    const today_st = moment();
    const today_ed = moment();
    const today_start = today_st.set({ hour: 0, minute: 0, second: 0, millisecond: 0 });
    const today_end = today_ed.set({ hour: 23, minute: 59, second: 59, millisecond: 999 });
    if (range['startDate'] && range['startDate']['_d']) {
      range['startDate'] = range['startDate'].set({ hour: 0, minute: 0, second: 0, millisecond: 0 });
      this.start_date = range['startDate']['_d'].getTime();
    }
    if (range['endDate'] && range['endDate']['_d']) {
      range['endDate'] = range['endDate'].set({ hour: 23, minute: 59, second: 59, millisecond: 999 });
      this.end_date = range['endDate']['_d'].getTime();
    } 
  }

  async getAllusers() {
    const output = [];
    const action = {
      type: 'GET',
      target: 'users/getUsers'
    };
    const payload = {};
    const result = await this.apiService.apiFn(action, payload);
    this.userslist = await result['data'].map(function (obj) {
      const robj = {};
      robj['label'] = obj['last_name'] + ', ' + obj['first_name'];
      robj['value'] = obj._id;
      return robj;
    });
    this.userslist.sort(function(a, b) {
      const nameA = a.label.toUpperCase(), nameB = b.label.toUpperCase();
      if (nameA < nameB) { // sort string ascending
          return -1;
      }
      if (nameA > nameB) {
          return 1;
      }
      return 0; // default return value (no sorting)
    });
  }

  async toggle() {
    this.show = !this.show;
  }

  changePlatform(platform) {
    this.pagiPayload = {
      length: 0,
      pageIndex: 0,
      pageSize: 10,
      previousPageIndex: 0
    };
    this.platform = platform;
    this.pagiPayload['activity_from'] = this.platform;
    this.pagiPayload['user_id'] = this.user;
    this.pagiPayload['dates'] = {
      sDate: this.start_date ? this.start_date : null, eDate: this.end_date ? this.end_date : null
   };
  }

  changeUser(user) {
    this.pagiPayload = {
      length: 0,
      pageIndex: 0,
      pageSize: 10,
      previousPageIndex: 0
    };
    this.user = user;
    this.pagiPayload['activity_from'] = this.platform;
    this.pagiPayload['user_id'] = this.user;
    this.pagiPayload['dates'] = {
      sDate: this.start_date ? this.start_date : null, eDate: this.end_date ? this.end_date : null
   };
  }

  onSubmit() {
    this.pagiPayload = {
      length: 0,
      pageIndex: 0,
      pageSize: 10,
      previousPageIndex: 0
    };
    this.pagiPayload['activity_from'] = this.platform;
    this.pagiPayload['user_id'] = this.user;
    this.pagiPayload['dates'] = {
       sDate: this.start_date ? this.start_date : null, eDate: this.end_date ? this.end_date : null
    };
    this.getServerData(this.pagiPayload);
  }

  createTable(arr) {
    const tableArr: Element[] = arr;
    this.dataSource = new MatTableDataSource(tableArr);
  }

  addForm() { // Custom-code!
    this.router.navigate(['/org/form']);
  }

  viewOrganization(id) {
    this.router.navigate(['/org/view', id]);
  }

  editOrganization(id) {
    this.router.navigate(['/org/form', id]);
  }

  async exportActivity() {
    this.common.setLoader(true);
    const that = this;
    await that.exportContentData();
    const resultAll = that.exportContentVal;
    if (resultAll.length) {
      that.loadervalue = 0;
      that.loaderbuffer = 2;
      that.loaderexport = false;
      const activity = await this.prepareUsersForCSV();
      this.excelService.exportAsExcelFile(activity, 'Activity_Report');
    }
    this.common.setLoader(false);
  }

  async exportContentData() {
    return new Promise(async (resolve) => {
        this.loaderexport = true;
        let decExist = 0;
        const limit = 500;
        const trackcount = this.count ;
        const no = trackcount <= limit ? 1 : (trackcount / limit);
        if (trackcount % limit !== 0 && trackcount > limit) {
            decExist = 1;
        }
        let arrlen;
        if (decExist === 1) {
            arrlen =  trackcount.length <= limit ? [1] : Array.from({ length: no + 1}, (v, k) => k);
        } else {
            arrlen =  trackcount.length <= limit ? [1] : Array.from({ length: no }, (v, k) => k);
        }

        const that = this;

        const asyncTasks = [];
        const doneTasks = [];
        let resultAll = [];
        arrlen.forEach(function (commitUrl, index, urls) {
            asyncTasks.push(async function (callback) {
              const action = {
                type: 'GET',
                target: 'activity'
              };
              const payload = {
                length: 0,
                pageIndex: index,
                pageSize: limit,
                previousPageIndex: 0,
                activity_from: that.platform,
                user_id: that.user,
                dates: {
                  sDate: that.start_date ? that.start_date : null,
                  eDate: that.end_date ? that.end_date : null
               }
              };

              const result =  await that.apiService.apiFn(action, payload);
              if (result['data'] && result['data']['_activity'].length) {
                const data = result['data']['_activity'];
                doneTasks[index] = data;
              }
              const totalItem = arrlen.length;
              that.loadervalue = (doneTasks.length / totalItem) * 100;
              that.loaderbuffer = that.loadervalue + 2;

              callback(null, 'resp');
            });
        });
        async.parallel(asyncTasks, function (results) {
          doneTasks.forEach(function (data, index, urls) {
            resultAll = [...resultAll, ...data];
          });
          that.exportContentVal = resultAll;
          resolve(that.exportContentVal);
        });

    });
  }

  prepareUsersForCSV() {
    const activity = [];
    const exportdata = this.exportContentVal;
    exportdata.forEach(item => {
      activity.push({
        'Activity Name': item.activity_name,
        'Activity From': item.activity_from,
        'Date': moment(item.date).format('MMMM Do YYYY, HH:mm'),
        'User': item.user_id ? item.user_id.first_name + ' ' + item.user_id.last_name : '--'
      });
    });
    return activity;
  }

  public async getActivityFunction() {
    this.common.setLoader(true);
    const action = {
      type: 'GET',
      target: 'activity'
    };
    const payload = this.pagiPayload;
    let result = await this.apiService.apiFn(action, payload);
    this.count = result['data']['_count'];
    result = result['data']['_activity'].map(item => {
      return {
        ...item,
        activity_name: item.activity_name,
        activity_from: item.activity_from,
        date: moment(item.date).format('MMMM Do YYYY, HH:mm'),
        user: item.user_id ? item.user_id.first_name + ' ' + item.user_id.last_name : '--'
      };
    });
    this.createTable(result);
    this.common.setLoader(false);
  }

  // sort data
  sortData(sort?: PageEvent) {
    if (sort['direction'] === '') {
      this.sort.active = sort['active'];
      this.sort.direction = 'asc';
      this.sort.sortChange.emit({active: sort['active'], direction: 'asc'});
      this.sort._stateChanges.next();
      return;
    }
    this.common.setLoader(true);
    this.pagiPayload['sort'] = sort;
    this.getActivityFunction();
  }

  public async getServerData(event?: PageEvent) {
    this.pagiPayload.previousPageIndex = event.previousPageIndex;
    this.pagiPayload.pageIndex = event.pageIndex;
    this.pagiPayload.pageSize = event.pageSize;
    this.pagiPayload.length = event.length;
    this.getActivityFunction();
  }

  resetFilter() {
    this.show = false;
    this.platform = '';
    this.user = '';
    delete this.pagiPayload['activity_from'];
    delete this.pagiPayload['user_id'];
    delete this.pagiPayload['dates'];
   this.start_date = moment().subtract(10, 'years').set({ hour: 0, minute: 0, second: 0, millisecond: 0 }).unix() * 1000;
   this.end_date = moment().set({ hour: 23, minute: 59, second: 59, millisecond: 999 }).unix() * 1000;
    this.selected = null;
    this.getServerData(this.pagiPayload);
  }
}

export interface Element {
  position: number;
  name: string;
  weight: number;
  symbol: string;
}

export interface PagiElement {
  length: number;
  pageIndex: number;
  pageSize: number;
  previousPageIndex: number;
}
