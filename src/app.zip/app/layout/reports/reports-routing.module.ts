import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormComponent } from './form/form.component';
import { GetreportComponent } from './getreport/getreport.component';
import { ViewComponent } from './view/view.component';
import { CarebyuseComponent } from './carebyuse/carebyuse.component';
import { CarebyresidentComponent } from './carebyresident/carebyresident.component';
import { MultipleemployeeComponent } from './multipleemployee/multipleemployee.component';
import { CarebyemployeeComponent } from './carebyemployee/carebyemployee.component';
import { CareperdayComponent } from './careperday/careperday.component';
import { CarebytimeComponent } from './carebytime/carebytime.component';
import { SingleemployeComponent } from './singleemploye/singleemploye.component';
import { ShiftperformancereportComponent } from './shiftperformancereport/shiftperformancereport.component';
import { ShiftreportComponent } from './shiftperformancereport/shiftreport/shiftreport.component';
import { ViewCustomReportsComponent } from './view-custom-reports/view-custom-reports.component';
import { CarechartComponent } from './charts/carechart/carechart.component';
import { MissedcheckinbyshiftComponent } from './missedcheckinbyshift/missedcheckinbyshift.component';
import { ListComponent } from './activity/list.component';

import { RoomCleaningReportComponent } from './roomcleaningreport/roomcleaningreport.component';
import { RoomCleanReportComponent } from './roomcleaningreport/roomcleanreport/roomcleanreport.component';

const routes: Routes = [
  {
    path: '',
    data: {
      breadcrumb: 'Reports'
    },
    children: [
      {
        path: '',
        data: {
          breadcrumb: null
        },
        component: FormComponent
      },
      {
        path: 'report',
        data: {  breadcrumb: 'Build Custom Report' },
        component: GetreportComponent
      },
      {
        path: 'view/:id',
        data: {  breadcrumb: 'View Custom Report' },
        component: ViewComponent
      },
      {
        path: 'careby/use',
        data: {  breadcrumb: 'Use' },
        component: CarebyuseComponent
      },
      {
        path: 'careby/resident',
        data: {  breadcrumb: 'Resident' },
        component: CarebyresidentComponent
      },
      {
        path: 'careby/multiple/employee',
        data: {  breadcrumb: 'Employee' },
        component: MultipleemployeeComponent
      },
      {
        path: 'careby/employee',
        data: {  breadcrumb: 'Employeessss' },
        component: CarebyemployeeComponent
      },
      {
        path: 'careperday',
        data: {  breadcrumb: 'Per Day' },
        component: CareperdayComponent
      },
      {
        path: 'carechart',
        data: {  breadcrumb: 'Care Within 24 Hours or Shift' },
        component: CarechartComponent
      },
      {
        path: 'careby/time',
        data: {  breadcrumb: 'Time' },
        component: CarebytimeComponent
      },
      {
        path: 'careby/single/employee',
        data: {  breadcrumb: 'Single Employee' },
        component: SingleemployeComponent
      },
      {
        path: 'shiftcereport',
        data: {  breadcrumb: 'Shift performance Report' },
        component: ShiftperformancereportComponent
      },
      {
        path: 'shiftperformancereport',
        data: {  breadcrumb: 'Shift Performance Report' },
        component: ShiftreportComponent
      },
      {
        path: 'view/custom/report',
        data: {  breadcrumb: 'View Custom Report' },
        component: ViewCustomReportsComponent
      },
      {
        path: 'missedlevel1checkin',
        data: {  breadcrumb: 'Missed level 1 Check In' },
        component: MissedcheckinbyshiftComponent
      },
      {
        path: 'activity',
        data: {  breadcrumb: 'Activity' },
        component: ListComponent
      },{
        path: 'roomcleaningreport',
        data: {  breadcrumb: 'Room Clean Report' },
        component: RoomCleaningReportComponent
      },
      {
        path: 'roomcleanreport',
        data: {  breadcrumb: 'Room Clean Report' },
        component: RoomCleanReportComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
 
