import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-singleemploye',
  templateUrl: './singleemploye.component.html',
  styleUrls: ['./singleemploye.component.scss']
})
export class SingleemployeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
