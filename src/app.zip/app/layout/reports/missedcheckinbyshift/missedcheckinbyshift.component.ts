import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../shared/services/api/api.service';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';
import { Router } from '@angular/router';
import { Chart } from 'chart.js';
import * as moment from 'moment';
import * as _ from 'underscore';
import { CommonService } from 'src/app/shared/services/common.service';
import { Subscription } from 'rxjs/Rx';
import { ExcelService } from '../../../shared/services/excel.service';
import { ChartType, Label, MultiDataSet, ChartDataSets, ChartOptions } from 'chart.js';
import { ExportAsService, ExportAsConfig } from 'ngx-export-as';

@Component({
  selector: 'app-missedcheckinbyshift',
  templateUrl: './missedcheckinbyshift.component.html',
  styleUrls: ['./missedcheckinbyshift.component.scss']
})
export class MissedcheckinbyshiftComponent implements OnInit {
  newDate1; newDate2;
  missedcheckl1 = {
    organization: '',
    facility: '',
    date: new Date(),
    shift: ''
  };
  isexport: Boolean = false;
  faclist: any;
  organiz: any;
  LineChart = null;
  currentDate = moment();
  shiftArr;
  fullResultData: any = [];
  show = false;
  displayedColumns = ['lastname', 'firstname', 'checkin', 'performer'];

  // chart option
  chartOptions = {
    maintainAspectRatio: false,
    cutoutPercentage: 75,
    elements: {
      arc: {
        borderWidth: 0
      }
    },
    tooltips: { enabled: false }
  };

  private Color2 = [
    {
      backgroundColor: [
        '#ef4036', '#5fac00',
      ]
    }
  ];

  chartType = ['doughnut'];
  public doughnutChartType2: ChartType = 'doughnut';

  private subscription: Subscription;
  data: any;
  username: string;

  constructor(
    private apiService: ApiService,
    private router: Router,
    public commonService: CommonService,
    private excelService: ExcelService,
    private exportAsService: ExportAsService
  ) { }
  CareData: any;
  chartLabel = [];
  finalCareDataArr = [];
  noRecord = false;
  shiftData: any;
  shiftType;
  showShiftType;
  userList: any;
  tableShow = false;
  public doc: any;
  public totalPagesExp = '{total_pages_count_string}';

  async ngOnInit() {
    this.commonService.setLoader(true);
    this.currentDate.utc();
    const shiftarray = this.commonService.shiftTime();
    this.shiftArr = [...[{ 'no': 0, 'name': 'All shift' }], ...shiftarray];

    this.subscription = this.commonService.contentdata.subscribe(async (contentVal: any) => {
      if (contentVal.org && contentVal.fac) {
        this.missedcheckl1.organization = contentVal.org;
        this.missedcheckl1.facility = contentVal.fac;
        this.commonService.setLoader(false);
      }
    });

    this.data = JSON.parse(sessionStorage.getItem('authReducer'));
    this.username = this.data.first_name + ' ' + this.data.last_name;
  }

  dateChange(ev) {
    this.missedcheckl1.shift = '';
  }

  async submit(f, data, p) {
    this.fullResultData = [];
    this.show = false;
    this.tableShow = false;
    this.userList = [];
    this.showShiftType = this.shiftType;
    let schartDate, echartDate;
    if (this.shiftData) {
      const n = this.shiftData.length;
      schartDate = this.shiftData[0].sTime;
      echartDate = this.shiftData[n - 1].eTime;
    }
    this.commonService.setLoader(true);
    const action = { type: 'POST', target: 'reports/missed_checkin' };
    const payload = {
      'org': data.organization,
      'facId': data.facility,
      'shiftData': this.shiftData,
      'schartDate': schartDate,
      'echartDate': echartDate
    };
    const result = await this.apiService.apiFn(action, payload);
    if (result['data'] && result['data'].length > 0) {
      this.fullResultData = result['data'];
      this.fullResultData = this.fullResultData.filter((obj) => {
        if (obj.timeSolt) {
          return obj;
        }
      });
    }
    if (this.fullResultData.length > 0) {
      this.show = true;
      this.userList = this.fullResultData.reduce((obj, item) => {
        const arr1 = item.userCheckinCount.reduce((data, i) => {
          const index = obj.findIndex(name => name.username === i.username);
          if (index !== -1) {
            const oldhData = obj[index].hData;
            oldhData.push({ time: (item.timeSolt.sTime + 900000), count: i.totalcount });
            obj[index] = { username: obj[index].username, hData: oldhData, total: obj[index].total + i.totalcount };
          } else {
            data.push({
              username: i.username,
              hData: [{ time: (item.timeSolt.sTime + 900000), count: i.totalcount }],
              total: i.totalcount
            });
          }
          return data;
        }, []);
        obj.push(...arr1);
        return obj;
      }, []);
      if (this.userList && this.userList.length > 0) {
        this.tableShow = true;
      } else {
        this.tableShow = false;
      }
      this.commonService.setLoader(false);
      this.baseChartFunc();
    } else {
      this.fullResultData = [];
      this.show = true;
      this.commonService.setLoader(false);
    }
  }

  cancel() {
    this.router.navigate(['/reports']);
  }

  async changeOrg(org) {
    const action = { type: 'GET', target: 'facility/faclist' };
    const payload = { 'org_id': this.missedcheckl1.organization };
    const result = await this.apiService.apiFn(action, payload);
    this.faclist = await result['data'];
  }

  getuserTime(data, time) {
    const check = data.hData.find(t => t.time === time);
    if (check) {
      return check.count;
    }
    return '';
  }

  changeShift(shiftNo) {
    let hours;
    this.newDate1 = moment(this.missedcheckl1.date);
    if (shiftNo === 0) {
      hours = Array.from({ length: 12 }, (v, k) => k);
      this.shiftType = 'All';
      this.newDate1.set({ hour: 5, minute: 45, second: 0, millisecond: 0 });
      this.newDate2 = moment(this.newDate1).add(1, 'days');
    } else if (shiftNo === 1) {
      hours = Array.from({ length: 4 }, (v, k) => k);
      this.shiftType = '1st Shift (6:00am - 2:00pm)';
      this.newDate1.set({ hour: 5, minute: 45, second: 0, millisecond: 0 });
      this.newDate2 = moment(this.newDate1).add(8, 'hours');
    } else if (shiftNo === 2) {
      hours = Array.from({ length: 4 }, (v, k) => k);
      this.shiftType = '2nd Shift (2:00pm - 10:00pm)';
      this.newDate1.set({ hour: 13, minute: 45, second: 0, millisecond: 0 });
      this.newDate2 = moment(this.newDate1).add(8, 'hours');
    } else if (shiftNo === 3) {
      hours = Array.from({ length: 4 }, (v, k) => k);
      this.shiftType = '3rd Shift (10:00pm - 6:00am)';
      this.newDate1.set({ hour: 21, minute: 45, second: 0, millisecond: 0 });
      this.newDate2 = moment(this.newDate1).add(8, 'hours');
    }
    let sTime = this.newDate1;
    let eTime = this.newDate2;
    this.shiftData = hours.reduce((obj, item) => {
      eTime = moment(sTime).add(60, 'minutes');
      const timeEnd = moment(eTime).add(75, 'minutes');
      obj.push({ sr: item, sTime: sTime['_d'].getTime(), midTime: eTime['_d'].getTime(), eTime: timeEnd['_d'].getTime() });
      sTime = moment(sTime).add(2, 'hours');
      return obj;
    }, []);
  }

  formatDate(time) {
    if (time) {
      const secondTime = moment(time).format('ss');
      const secondPTime = parseInt(secondTime);
      if (secondPTime < 30) {
        return moment(time).format('hh:mm A');
      } else {
        return moment(time).add(1, 'minutes').format('hh:mm A');
      }
    } else {
      return '';
    }
  }

  baseChartFunc() {
    const that = this;
    setTimeout(function () {
      that.fullResultData.map((value, itr) => {
        const chartName = 'doughnutChart' + itr;
        const doughnutChart2 = new Chart(chartName, {
          type: 'doughnut',
          data: {
            datasets: [{
              data: value.checkinListresult.graphData,
              backgroundColor: ['#ef4036', '#32a53e']
            }]
          },
          options: that.chartOptions
        });
      });
    }, 1000);
  }

  downloadAll() {
    const onDate = new Date(this.missedcheckl1.date);
    const thisObj = this;
    const missedCheckinReport = thisObj.prepareForExportAll(onDate);

    thisObj.excelService.exportAsExcelFile(missedCheckinReport, 'Missed Level 1 Check-in Report by Shift');

  }

  DisplayCurrentTime(sDate) {
    const date = new Date(sDate);
    let hours = date.getHours() > 12 ? date.getHours() - 12 : date.getHours();
    const am_pm = date.getHours() >= 12 ? 'PM' : 'AM';
    hours = (hours === 0) ? 12 : hours;
    const hours1 = hours < 10 ? '0' + hours : hours;
    const minutes = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes();
    return hours1 + ':' + minutes + ' ' + am_pm;
  }

  prepareForExportAll(onDate) {
    const arr = [];
    const missedCheckinReport = [];

    missedCheckinReport.push({
      'Missed Level 1 Check-in Report by Shift': '',
      '': '',
      ' ': '',
      '  ': '',
      '   ': '',
      '    ': '',
      '     ': '',
      '      ': '',
    });

    const nextRow = {
      'Missed Level 1 Check-in Report by Shift': 'Created by :', // + this.userName,
      '': this.username,
      ' ': '',
      '  ': '',
      '   ': '',
      '    ': '',
      '     ': '',
      '      ': '',
    };

    missedCheckinReport.push(nextRow);
    const nextRow1 = {
      'Missed Level 1 Check-in Report by Shift': onDate.getMonth() + '/' + onDate.getDate() + '/' + onDate.getFullYear(),
      '': '',
      ' ': '',
      '  ': '',
      '   ': '',
      '    ': '',
      '     ': '',
      '      ': '',
    };
    missedCheckinReport.push(nextRow1);
    const blackSpace = {
      'Missed Level 1 Check-in Report by Shift': '',
      '': '',
      ' ': '',
      '  ': '',
      '   ': '',
      '    ': '',
      '     ': '',
      '      ': '',
    };
    missedCheckinReport.push(blackSpace);
    const nextRow2 = {
      'Missed Level 1 Check-in Report by Shift': this.showShiftType,
      '': '',
      ' ': '',
      '  ': '',
      '   ': '',
      '    ': '',
      '     ': '',
      '      ': '',
    };
    missedCheckinReport.push(nextRow2);
    missedCheckinReport.push(blackSpace);

    if (this.tableShow) {
      let table1 = {
        'Missed Level 1 Check-in Report by Shift': 'Performer'
      };

      if (this.fullResultData.length > 0) {
        let _space = "";
        this.fullResultData.forEach((_col) => {
          table1[_space] = this.DisplayCurrentTime(_col.timeSolt.sTime + 900000);
          _space = _space + " ";

        })
        table1[_space] = "Total";

      }

      missedCheckinReport.push(table1);

      if (this.userList.length > 0) {
        this.userList.forEach((_rec) => {

          let table2 = {
            'Missed Level 1 Check-in Report by Shift': _rec.username
          };

          if (this.fullResultData.length > 0) {
            let _space = "";
            this.fullResultData.forEach((_col) => {
              table2[_space] = this.getuserTime(_rec, _col.timeSolt.sTime + 900000);
              _space = _space + " ";

            })
            table2[_space] = _rec.total;

          }

          missedCheckinReport.push(table2);
        })

      }



      missedCheckinReport.push(blackSpace);

    }

    const userCountData = this.fullResultData;
    userCountData.forEach((item, inx) => {
      const table1Data = {
        'Missed Level 1 Check-in Report by Shift': this.DisplayCurrentTime(item.timeSolt.sTime + 900000),
        '': '',
        ' ': '',
        '  ': '',
        '   ': '',
        '    ': '',
        '     ': '',
        '      ': ''
      };
      if (inx > 0) {
        missedCheckinReport.push(blackSpace);
      }
      missedCheckinReport.push(table1Data);
      const dateCount = {
        'Missed Level 1 Check-in Report by Shift': 'Check-in',
        '': item.checkinListresult.data.totalcount + '/' + item.checkinListresult.count,
        ' ': '',
        '  ': '',
        '   ': '',
        '    ': '',
        '     ': '',
        '      ': ''
      };
      missedCheckinReport.push(dateCount);
      missedCheckinReport.push(blackSpace);

      const table1 = {
        'Missed Level 1 Check-in Report by Shift': 'Last Name',
        '': 'First Name',
        ' ': 'Check-In',
        '  ': 'Performer',
        '   ': '',
        '    ': '',
        '     ': '',
        '      ': ''
      };
      missedCheckinReport.push(table1);

      if (item.missedcheckin.length > 0) {


        const userCountData1 = item.missedcheckin;
        userCountData1.forEach(_item => {
          const table1Data1 = {
            'Missed Level 1 Check-in Report by Shift': _item.resident_last_name,
            '': _item.resident_first_name,
            ' ': (_item.check_in_time === 0) ? '-' : this.formatDate(_item.check_in_time),
            '  ': _item.user_name,
            '   ': '',
            '    ': '',
            '     ': '',
            '      ': ''
          };
          missedCheckinReport.push(table1Data1);
        });
      }

    });

    missedCheckinReport.push(blackSpace);
    missedCheckinReport.push(blackSpace);
    return missedCheckinReport;
  }
}

export interface PresetItem {
  presetLabel: string;
  range: Range;
}

export interface Range {
  fromDate: Date;
  toDate: Date;
}

export interface CalendarOverlayConfig {
  panelClass?: string;
  hasBackdrop?: boolean;
  backdropClass?: string;
  shouldCloseOnBackdropClick?: boolean;
}

export interface NgxDrpOptions {
  presets: Array<PresetItem>;
  format: string;
  range: Range;
  excludeWeekends?: boolean;
  locale?: string;
  fromMinMax?: Range;
  toMinMax?: Range;
  applyLabel?: string;
  cancelLabel?: string;
  animation?: boolean;
  calendarOverlayConfig?: CalendarOverlayConfig;
  placeholder?: string;
  startDatePrefix?: string;
  endDatePrefix?: string;
}

export interface Element {
  position: number;
  name: string;
  weight: number;
  symbol: string;
}

export interface PagiElement {
  length: number;
  pageIndex: number;
  pageSize: number;
  previousPageIndex: number;
}


