import { Component, OnInit } from '@angular/core';
import { ApiService } from './../../../../shared/services/api/api.service';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';
import { Router } from '@angular/router';
import { Chart } from 'chart.js';
import * as moment from 'moment';
import * as asyncfunc from 'async';
import * as _ from 'underscore';
import { CommonService } from 'src/app/shared/services/common.service';
import { MatRadioChange } from '@angular/material';
import { MatTableDataSource } from '@angular/material';
import { Subscription } from 'rxjs/Rx';
import { ExcelService } from '../../../../shared/services/excel.service';

export interface PeriodicElement {
  careName: string;
  total: number;
}

@Component({
  selector: 'app-carechart',
  templateUrl: './carechart.component.html',
  styleUrls: ['./carechart.component.scss']
})
export class CarechartComponent implements OnInit {
  shiftsTimeUTC; shifteTimeUTC; shiftsMinute; shifteMinute; newDate1; newDate2;
  careChart = {
    organization: '',
    facility: '',
    cType: 1,
    date: new Date(),
    startTime: new Date(),
    shift: ''
  };
  isexport: Boolean = false;
  displayedColumns = ['care', 'total'];
  show = false;
  faclist: any;
  organiz: any;
  LineChart = null;
  currentDate = moment();
  shiftArr;
  tType;
  private subscription: Subscription;

  constructor(
    private apiService: ApiService,
    private router: Router,
    public commonService: CommonService,
    private excelService: ExcelService,
  ) { }
  chartdata: PeriodicElement[];
  dataSource = new MatTableDataSource(this.chartdata);
  CareData: any;
  chartLabel = [];
  finalCareDataArr = [];
  noRecord = false;
  shiftData: {};
  shiftType;
  columnNames = [
    {
      id: 'date',
      value: 'Date',
      title: 'Date',
      name: 'date',
      dataKey: 'Date'
    }, {
      id: 'quantity',
      value: 'Quantity',
      title: 'Quantity',
      name: 'quantity',
      dataKey: 'Quantity'
    }
  ];
  colorArray = [
    '#ff4000', '#c900c9', '#c4c400', '#00c8ff',
    '#d49800', '#3366E6', '#80ff80', '#cf0000',
    '#29474d', '#416332', '#964848', '#576b94', '#48631e',
    '#FF99E6', '#CCFF1A', '#FF1A66', '#E6331A', '#33FFCC',
    '#66994D', '#B366CC', '#4D8000', '#B33300', '#CC80CC',
    '#66664D', '#991AFF', '#E666FF', '#4DB3FF', '#1AB399',
    '#E666B3', '#33991A', '#CC9999', '#B3B31A', '#00E680',
    '#4D8066', '#809980', '#E6FF80', '#1AFF33', '#999933',
    '#FF3380', '#CCCC00', '#66E64D', '#4D80CC', '#9900B3',
    '#E64D66', '#4DB380', '#FF4D4D', '#99E6E6', '#6666FF'
  ];

  exportdata;
  public doc: any;
  public totalPagesExp = '{total_pages_count_string}';

  async ngOnInit() {
    this.commonService.setLoader(true);
    this.currentDate.utc();
    this.tType = 1;
    this.shiftArr = this.commonService.shiftTime();
    this.careChart.date = (this.currentDate.subtract(1, 'days'))['_d'];

    this.careChart.startTime = new Date();
    this.subscription = this.commonService.contentdata.subscribe(async (contentVal: any) => {
      if (contentVal.org && contentVal.fac) {
        this.careChart.organization = contentVal.org;
        this.careChart.facility = contentVal.fac;
        this.commonService.setLoader(false);
      }
    });
  }
  onChange(mrChange: MatRadioChange) {
    this.tType = mrChange.value;
  }

  async submit(f, data, p) {
    this.finalCareDataArr = [];
    this.chartLabel = [];
    this.chartdata = [];
    let vaild = f.form.status;
    data.organization = this.careChart.organization;
    data.facility = this.careChart.facility;
    if (data.organization === '' || data.facility === '' || (p._validSelected === null || p._validSelected === undefined || p._validSelected === '')) {
      vaild = 'INVALID';
    }
    if (vaild === 'VALID') {
      this.commonService.setLoader(true);
      let time = moment(data.startTime);
      let compHour = time.hour();

      let sHourUTC = time.hours();
      let sMinuteUTC = time.minutes();

      // convert Date into UTC
      let sDate = moment(p._validSelected);
      let eDate = moment(p._validSelected);
      if (this.tType === 1) {
        sDate.set({ hour: sHourUTC, minute: sMinuteUTC, second: 0, millisecond: 0 });
        compHour = sHourUTC;
      } else {
        sDate.set({ hour: this.shiftsTimeUTC, minute: this.shiftsMinute, second: 0, millisecond: 0 });
      }
      let utcsDate = sDate['_d'].getTime();

      if (this.tType === 1) {
        eDate = eDate.add(1, 'days');
        eDate.set({ hour: sHourUTC, minute: sMinuteUTC, second: 0, millisecond: 0 });
        compHour = sHourUTC;
      } else {
        eDate = sDate.add(8, 'hours');
      }
      eDate = eDate['_d'].getTime();
      if (this.tType === 1) {
        this.shiftData = null;
      }
      const action = { type: 'POST', target: 'reports/chart_shift_report' };
      const payload = {
        'org': data.organization,
        'facId': data.facility,
        'schartDate': utcsDate,
        'echartDate': eDate,
        'hour': sHourUTC,
        'minute': sMinuteUTC,
        'shiftData': this.shiftData,
        'shiftType': this.shiftType
      };

      const result = await this.apiService.apiFn(action, payload);
      this.CareData = result['data']['_report'];
      const thisObj = this;
      if (this.CareData && this.CareData.length > 0) {
        asyncfunc.eachOfSeries(this.CareData, function (item, i, callback) {
          let row, arr1, arr2, final;
          if (thisObj.tType === 1) {
            row = _.sortBy(item.finalCareData, 'hour');
            arr1 = _.filter(row, (num) => { if (num.hour < compHour) { return num; } });
            arr2 = _.filter(row, (num) => { if (num.hour >= compHour) { return num; } });
            final = [...arr2, ...arr1];
            item.finalCareData = final;
            const labelArr = final.map(x => {
              const d = moment();
              // d.utc();
              d.set({ hour: x.hour, minute: 0, second: 0, millisecond: 0 });
              d.local();
              const res = d.hour();
              return `${res.toString()}-${(res + 1).toString()}`;
            }
            );
            thisObj.chartLabel = labelArr;
          } else {
            if (thisObj.shiftType !== 2) {
              final = _.sortBy(item.finalCareData, 'hour');
            } else {
              let final1, row;
              row = _.sortBy(item.finalCareData, 'hour');
              const array1 = _.filter(row, (num) => { if (num.hour < thisObj.shiftsTimeUTC) { return num; } });
              const array2 = _.filter(row, (num) => { if (num.hour >= thisObj.shiftsTimeUTC) { return num; } });
              final1 = [...array2, ...array1];
              final = final1;
            }
            const labelArr = final.map(x => {

              const d = moment();
              d.utc();
              d.set({ hour: x.hour, minute: 0, second: 0, millisecond: 0 });
              d.local();
              const res = d.hour();
              return `${res.toString()}-${(res + 1).toString()}`;
            }
            );
            thisObj.chartLabel = labelArr;
          }
          const arrr = [];
          const tablearr = [];
          const obj = {
            'label': final[0].careName,
            'data': final.map(x => x.notime),
            'fill': false,
            'lineTension': 0.2,
            'borderColor': thisObj.colorArray[i],
            'borderWidth': 1.7
          };
          const tableData = {
            'careName': final[0].careName,
            'total': obj.data.reduce((x, y) => {
              return x + y;
            })
          };
          arrr.push(obj);
          tablearr.push(tableData);
          thisObj.chartdata = [...thisObj.chartdata, ...tablearr];
          thisObj.finalCareDataArr = [...thisObj.finalCareDataArr, ...arrr];
          callback(null, true);


        }, async function (err, result) {
          if (err) {

          } else {
            const name = '';
            await thisObj.showCahrt(thisObj.finalCareDataArr, thisObj.chartLabel, name, {
              xAxes: [{
                display: true,
                scaleLabel: {
                  display: true,
                  labelString: 'Time'
                }
              }],
              yAxes: [{
                display: true,
                scaleLabel: {
                  display: true,
                  labelString: 'Total Cares'
                }
              }]
            });
          }
        });
        this.show = true;
        this.commonService.setLoader(false);
        this.noRecord = true;
      } else {
        const name = 'No record found!';
        await thisObj.showCahrt([{
          'label': [],
          'data': [],
          'fill': false,
          'lineTension': 0,
          'borderColor': '#ffffff',
          'borderWidth': 0
        }], [], name, {
          xAxes: [{
            display: false,
            scaleLabel: {
              display: true,
              labelString: 'Cares'
            }
          }],
          yAxes: [{
            display: false,
            scaleLabel: {
              display: true,
              labelString: 'Value'
            }
          }]
        });
        // this.noRecord = false;
        this.show = false;
        this.commonService.setLoader(false);
      }
    }
  }

  showCahrt(data, cLabel, name, res) {
    if (data && data.length > 0) {
      if (this.LineChart != null) {
        this.LineChart.destroy();
      }
      var canvas = <HTMLCanvasElement>document.getElementById('lineChart');
      var ctx = canvas.getContext('2d');

      this.LineChart = new Chart(ctx, {

        type: 'line',
        data: {
          labels: cLabel,
          datasets: data
        },
        options: {
          responsive: true,
          title: {
            text: name,
            display: true
          },
          scales: res
        }
      });
      if (this.chartdata && this.chartdata.length > 0) {
        this.isexport = true;
      } else {
        this.isexport = false;
      }
      this.dataSource = new MatTableDataSource(this.chartdata);

      if (name === 'No record found!') {
        this.noRecord = false;
      }
    } else {
      this.noRecord = false;
    }
  }
  cancel() {
    this.router.navigate(['/reports']);
  }
  async changeOrg(org) {
    const action = { type: 'GET', target: 'facility/faclist' };
    const payload = { 'org_id': this.careChart.organization };
    const result = await this.apiService.apiFn(action, payload);
    this.faclist = await result['data'];
  }
  async changeFac(fac) {

  }
  async changeCType(t) {
    if (t == 2) {
      this.careChart.shift = "";
    } else {
      this.careChart.startTime = new Date();
    }
    this.tType = t;
  }
  changeShift(shiftNo) {
    this.newDate1 = moment();
    this.newDate2 = moment();
    if (shiftNo === 1) {
      this.shiftType = 1;
      this.newDate1.set({ hour: 6, minute: 0, second: 0, millisecond: 0 });
      this.newDate2.set({ hour: 14, minute: 0, second: 0, millisecond: 0 });
    } else if (shiftNo === 2) {
      this.shiftType = 2;
      this.newDate1.set({ hour: 14, minute: 0, second: 0, millisecond: 0 });
      this.newDate2.set({ hour: 22, minute: 0, second: 0, millisecond: 0 });
    } else if (shiftNo === 3) {
      this.shiftType = 3;
      this.newDate1.set({ hour: 22, minute: 0, second: 0, millisecond: 0 });
      this.newDate2.set({ hour: 6, minute: 0, second: 0, millisecond: 0 });
    }
    this.shiftsTimeUTC = this.newDate1.hours();
    this.shifteTimeUTC = this.newDate2.hours();
    this.shiftsMinute = this.newDate1.minutes();
    this.shifteMinute = this.newDate2.minutes();
    this.shiftData = {
      'shiftsTimeUTC': this.newDate1.utc().hours(),
      'shifteTimeUTC': this.newDate2.utc().hours(),
      'shiftsMinute': this.newDate1.utc().minutes(),
      'shifteMinute': this.newDate2.utc().minutes()
    };
  }
  excelExport() {
    if (this.chartdata && this.chartdata.length > 0) {
      this.exceldownload(this.chartdata);
    }
  }

  async exceldownload(data) {
    let excelData = []
    let pagetitle = {
      "Care Within 24 Hours or Shift": "",// + this.userName,
      "": ""
    };
    excelData.push(pagetitle);
    let title = {
      "Care Within 24 Hours or Shift": "Care Name",// + this.userName,
      "": "Total"
    };
    excelData.push(title);
    data.forEach(obj => {
      excelData.push({
        "Care Within 24 Hours or Shift": obj.careName,// + this.userName,
        "": obj.total
      });
    });
    await this.excelService.exportAsExcelFile(excelData, 'Care Within 24 Hours or Shift');
  }
}
export interface PresetItem {
  presetLabel: string;
  range: Range;
}
export interface Range {
  fromDate: Date;
  toDate: Date;
}
export interface CalendarOverlayConfig {
  panelClass?: string;
  hasBackdrop?: boolean;
  backdropClass?: string;
  shouldCloseOnBackdropClick?: boolean;
}
export interface NgxDrpOptions {
  presets: Array<PresetItem>;
  format: string;
  range: Range;
  excludeWeekends?: boolean;
  locale?: string;
  fromMinMax?: Range;
  toMinMax?: Range;
  applyLabel?: string;
  cancelLabel?: string;
  animation?: boolean;
  calendarOverlayConfig?: CalendarOverlayConfig;
  placeholder?: string;
  startDatePrefix?: string;
  endDatePrefix?: string;
}
export interface Element {
  position: number;
  name: string;
  weight: number;
  symbol: string;
}
export interface PagiElement {
  length: number;
  pageIndex: number;
  pageSize: number;
  previousPageIndex: number;
}

