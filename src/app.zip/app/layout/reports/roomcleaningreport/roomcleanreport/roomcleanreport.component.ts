import { Component, OnInit, ElementRef, ViewChild, HostListener } from '@angular/core';
import { Store } from '@ngrx/store';
import { ApiService } from 'src/app/shared/services/api/api.service';
import { ToastrService } from 'ngx-toastr';
import { ExcelService } from './../../../../shared/services/excel.service';
import { CommonService } from './../../../../shared/services/common.service';
import { ExportAsService, ExportAsConfig } from 'ngx-export-as';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as _ from 'underscore';
import * as xlsx from 'xlsx';
import * as asyncfunc from 'async';
import * as moment from 'moment';

@Component({
  selector: 'app-roomcleanreport',
  templateUrl: './roomcleanreport.component.html',
  styleUrls: ['./roomcleanreport.component.scss']
})

export class RoomCleanReportComponent implements OnInit {
  careIdName: any;
  doc: any;
  constructor(
    private apiService: ApiService,
    private excelService: ExcelService,
    private toastr: ToastrService,
    private exportAsService: ExportAsService,
    public commonService: CommonService
  ) { }

  countReportvalue;
  boxResultvalue;
  userResults = {};
  selectShift;
  shiftNo;
  residentList;
  data;
  start_date;
  end_date;
  userName;
  resultcount;
  isShow: boolean;
  topPosToStartShowing = 100;
  sTime;
  eTime;
  exportArr = [];
  allUserData: any;
  margins = {
    top: 100,
    bottom: 50,
    left: 25,
    right: 30,
    width: 550
  };

  @ViewChild('content') content: ElementRef;



  @HostListener('window:scroll')
  checkScroll() {
    // window의 scroll top
    // Both window.pageYOffset and document.documentElement.scrollTop 
    // returns the same result in all the cases. window.pageYOffset is not supported below IE 9.
    const scrollPosition = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
    if (scrollPosition >= this.topPosToStartShowing) {
      this.isShow = true;
    } else {
      this.isShow = false;
    }
  }

  // TODO: Cross browsing
  gotoTop() {
    window.scroll({ top: 0, left: 0, behavior: 'smooth' });
  } async ngOnInit() {
    this.load_careIdName();
    this.data = JSON.parse(sessionStorage.getItem('shiftRep_Reducer'));
    this.end_date = this.data.end_date;
    this.start_date = this.data.start_date;
    this.userName = this.data.userName;
    this.shiftNo = this.data.shift;
    this.loadReport();
  }

  async loadReport() {
    this.commonService.setLoader(true);
    const action = { type: 'POST', target: 'reports/roomCleanReport' };
    const payload = this.data;

    const result = await this.apiService.apiFn(action, payload);
    this.residentList = result['data']['reports']['reportValue'];
    this.countReportvalue = result['data']['reports']['reportValue'];
    this.boxResultvalue = result['data']['reports']['totalReport'];
    if (this.shiftNo === 1) {
      this.selectShift = '1st Shift (6:00am - 2:00pm)';
    } else if (this.shiftNo === 2) {
      this.selectShift = '2nd Shift (2:00pm - 10:00pm)';
    } else {
      this.selectShift = '3rd Shift (10:00pm - 6:00am)';
    }
    if (this.residentList && this.residentList.length > 0) {
      this.resultcount = true;
    } else {
      this.resultcount = false;
    }
    this.commonService.setLoader(false);
  }

  async getData(userID) {
    const ind = this.countReportvalue.findIndex((item) => item.userData._id == userID)
    if (ind > -1) {

      this.userResults[userID] = this.countReportvalue[ind].records;
      this.commonService.setLoader(false);
      return this.userResults[userID];
    }

  }

  async load_careIdName() {
    const action = {
      type: 'GET', target: 'cares/careIdName'
    }
    const payload = {};
    let result = await this.apiService.apiFn(action, payload)
    this.careIdName = result['data'];

  }



  trackcareDetail(_arr) {
    return _arr = _arr.filter((_item) => {
      for (const property in _item) {
        return _item[property] = _item[property].filter(__item => {
          for (const property in __item) {
            return (__item[property] != "Performed") ? true : false;
          }
        })
      }
    })
  }

  timeConvert(num) {
    let hours = (num / 60);
    let rhours = Math.floor(hours);
    let minutes = (hours - rhours) * 60;
    let rminutes = Math.round(minutes);
    return rhours + " hrs " + rminutes + " min";
  }


  formatDate(time, onlyTime = false) {
    if (time) {
      const secondTime = moment(time).format('ss');
      const secondPTime = parseInt(secondTime);
      if (onlyTime == false) {
        if (secondPTime < 30) {
          return moment(time).format('MMMM Do YYYY, hh:mm A');
        } else {
          return moment(time).add(1, 'minutes').format('MMMM Do YYYY, hh:mm A');
        }
      } else {
        if (secondPTime < 30) {
          return moment(time).format('hh:mm A');
        } else {
          return moment(time).add(1, 'minutes').format('hh:mm A');
        }
      }

    } else {
      return '';
    }
  }


  formatDate1(time) {
    if (time) {
      return moment(time).format('MMMM Do YYYY');
    } else {
      return '';
    }
  }
  async expandPanel(userID) {
    event.stopPropagation();
    if (!this.userResults.hasOwnProperty(userID)) {
      await this.getData(userID);
    }
  }

  async getPrint() {

    let rentalPage = 0;

    this.doc = undefined;
    this.doc = new jsPDF('p', 'pt', 'letter');

    const _self = this;

    const pageHeight = 30;//(_self.doc.internal.pageSize.height / 2.4) + 135;
    _self.doc.setFontType('bold');
    _self.doc.setFontSize(16);
    _self.doc.text(`Room Clean Report`, 30, pageHeight);

    _self.doc.setFontType('normal');
    _self.doc.setFontSize(11);
    _self.doc.text(`Report Generated by ${this.userName},  Western Home, Standard Center`, 30, pageHeight + 15);
    _self.doc.text(`Shift :${this.selectShift}`, 30, pageHeight + 30);
    _self.doc.text(`${this.formatDate1(this.start_date)} - ${this.formatDate1(this.end_date)}`, 30, pageHeight + 45);

    _self.doc.rect(50, pageHeight + 60, 140, 75);
    _self.doc.text(`${this.boxResultvalue.totalCarePerformed}`, 100, pageHeight + 90);
    _self.doc.text(`Rooms Cleans Performed`, 60, pageHeight + 110);
    _self.doc.rect(240, pageHeight + 60, 140, 75);
    _self.doc.text(`${this.boxResultvalue.totalCareRefused}`, 290, pageHeight + 90);
    _self.doc.text(`Refused Cleaning`, 250, pageHeight + 110);
    _self.doc.rect(430, pageHeight + 60, 140, 75);
    _self.doc.text(`${(this.boxResultvalue.totalTime > 60) ? this.timeConvert(this.boxResultvalue.totalTime) : this.boxResultvalue.totalTime + 'min'}`, 440, pageHeight + 90);
    _self.doc.text(`Total Time`, 440, pageHeight + 110);

    setTimeout(() => {
      this.doc.autoPrint();
      window.open(this.doc.output('bloburl'), '_blank');
    }, 1000);

  }


  headerFooterFormatting(doc, totalPages) {
    for (let i = totalPages; i >= 1; i--) {
      doc.setPage(i);
      // header
      this.header(doc);

      this.footer(doc, i, totalPages);
      doc.page++;
    }
  }

  header(doc) {
    let count;
    doc.printHeaders = false;
    doc.printingHeaderRow = false;
    doc.tableHeaderRow = [[]];

  }

  footer(doc, pageNumber, totalPages) {
    const str = 'Page ' + pageNumber + ' of ' + totalPages;
    doc.text(str, this.margins.left, doc.internal.pageSize.height - 20);

  }


  downloadAll() {
    let startDate = new Date(this.start_date);
    let endDate = new Date(this.end_date);
    let thisObj = this;

    asyncfunc.eachOfSeries(this.countReportvalue, function (item, i, callback) {
      if (thisObj.userResults.hasOwnProperty(item.userData._id)) {
        callback(null, true);
      } else {
        thisObj.getData(item.userData._id).then((res) => {
          callback(null, true);
        });
      }

    }, function (err, result) {
      if (err) {

      } else {
        let shiftReport = thisObj.prepareForExportAll(startDate, endDate);
        thisObj.excelService.exportAsExcelFile(shiftReport, 'Room Clean Report');
      }

    });
  }

  prepareForExportAll(startDate, endDate) {
    var arr = [];
    let shiftreport = [];

    shiftreport.push({
      "Room Clean Report": '',
      "": '',
      " ": '',
      "  ": '',
      "   ": '',
      "    ": '',
      "     ": '',
      "      ": '',
    });

    let nextRow = {
      "Room Clean Report": 'Created by :',// + this.userName,
      "": this.userName,
      " ": '',
      "  ": '',
      "   ": '',
      "    ": '',
      "     ": '',
      "      ": '',
    }

    shiftreport.push(nextRow);
    let nextRow1 = {
      "Room Clean Report": startDate.getMonth() + "/" + startDate.getDate() + "/" + startDate.getFullYear() + ' - ' + endDate.getMonth() + "/" + endDate.getDate() + "/" + endDate.getFullYear(),
      "": '',
      " ": '',
      "  ": '',
      "   ": '',
      "    ": '',
      "     ": '',
      "      ": '',
    }
    shiftreport.push(nextRow1);
    let blackSpace = {
      "Room Clean Report": '',
      "": '',
      " ": '',
      "  ": '',
      "   ": '',
      "    ": '',
      "     ": '',
      "      ": '',
    }
    shiftreport.push(blackSpace);
    let nextRow2 = {
      "Room Clean Report": this.selectShift,
      "": '',
      " ": '',
      "  ": '',
      "   ": '',
      "    ": '',
      "     ": '',
      "      ": '',
    }
    shiftreport.push(nextRow2);
    shiftreport.push(blackSpace);
    let table1 = {
      "Room Clean Report": 'Rooms Cleans Performed',
      "": 'Refused Cleaning',
      " ": 'Total Time',
      "  ": '',
      "   ": '',
      "    ": '',
      "     ": '',
      "      ": ''
    }
    shiftreport.push(table1);
    let table1Val = {
      "Room Clean Report": this.boxResultvalue.totalCarePerformed,
      "": this.boxResultvalue.totalCareRefused,
      " ": (this.boxResultvalue.totalTime > 60) ? this.timeConvert(this.boxResultvalue.totalTime) : this.boxResultvalue.totalTime + 'min',
      "  ": '',
      "   ": '',
      "    ": '',
      "     ": '',
      "      ": ''
    }
    shiftreport.push(table1Val);
    shiftreport.push(nextRow2);
    shiftreport.push(blackSpace);
    let table2 = {
      "Room Clean Report": 'Performer',
      "": 'Total Cares Performed',
      " ": 'Total Cares Refused',
      "  ": 'Total Time',
      "   ": '',
      "    ": '',
      "     ": '',
      "      ": ''
    }
    shiftreport.push(table2);

    let userCountData = this.countReportvalue;
    userCountData.forEach(item => {
      let table1Data = {
        "Room Clean Report": item.userData.first_name + ' ' + item.userData.last_name,
        "": item.total_performed,
        " ": item.total_refused,
        "  ": (item.total_min > 60) ? this.timeConvert(item.total_min) : item.total_min + 'min',
        "   ": '',
        "    ": '',
        "     ": '',
        "      ": ''
      }
      shiftreport.push(table1Data);
    })

    shiftreport.push(blackSpace);
    shiftreport.push(blackSpace);

    let uu = this.countReportvalue;
    uu.forEach(i => {
      let nameofuser = {
        "Room Clean Report": "Performer:" + i.userData.first_name + ' ' + i.userData.last_name,
        "": '',
        " ": '',
        "  ": '',
        "   ": '',
        "    ": '',
        "     ": '',
        "      ": '',
      }
      shiftreport.push(nameofuser);
      shiftreport.push(blackSpace);

      this.userResults[i.userData._id].forEach(item => {
        let _residentDeatil = {
          "Room Clean Report": `Resident : ${item.residentData.first_name} ${item.residentData.last_name} `
        };
        let _room = {
          "Room Clean Report": `Room : ${item.roomData.room} `
        };
        let _status = {
          "Room Clean Report": `Status : ${item.resident_status}`
        };
        let _totalTime = {
          "Room Clean Report": `Total Time : ${item.totalMin}min`
        };
        let _dateTime = {
          "Room Clean Report": `${this.formatDate(item.startTime)} -${this.formatDate(item.endTime, true)}`
        };

        shiftreport.push(_residentDeatil, _room, _status, _totalTime, _dateTime);

        shiftreport.push(blackSpace);
        let userCareheading = {
          "Room Clean Report": "Care",
          "": "Outcome",
          " ": "Notes"
        }
        shiftreport.push(userCareheading);

        item.items.forEach(obj => {
          shiftreport.push({
            "Room Clean Report": (obj.careData.type == 'room_cleaning') ? obj.careData.name : "",
            "": obj.care_value,
            " ": obj.care_notes,

          });
          if (obj.careData.type == 'room_cleaning' && obj.track_details && obj.care_value != 'Refused') {
            let _arr = this.trackcareDetail(obj.track_details.arr_room_clean)
            _arr.forEach(itm => {
              for (const property in itm) {
                if (itm[property].length > 0) {


                  let _care = this.careIdName[property];

                  itm[property].forEach((val) => {

                    for (const property1 in val) {
                      let _subCare = {
                        "Room Clean Report": `${_care}--${this.careIdName[property1]}--${val[property1]}`

                      };
                      shiftreport.push(_subCare);
                    }
                  })
                }
              }
            })
          }

        });
        shiftreport.push(blackSpace);

      });
      shiftreport.push(blackSpace);
      shiftreport.push(blackSpace);

    });
    return shiftreport;
  }
}

