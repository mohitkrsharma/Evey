import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/shared/services/common.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {

  constructor(private router: Router,
    private commonService: CommonService) { }

  ngOnInit() {
    this.commonService.content.subscribe(updatedTitle => {
    });

    sessionStorage.removeItem("pageListing");
  }

  getReport() {
    this.router.navigate(['/reports/report']);
  }
  getShiftReport() {
    this.router.navigate(['/reports/shiftcereport']);
  }

  carebyUse() {
    this.router.navigate(['/reports/careby/use']);
  }

  carebyResident() {
    this.router.navigate(['/reports/careby/resident']);
  }

  multipleEmployee() {
    this.router.navigate(['/reports/careby/multiple/employee']);
  }

  carebyEmployee() {
    this.router.navigate(['/reports/careby/employee']);
  }

  careperday() {
    this.router.navigate(['/reports/careperday']);
  }

  carebyTime() {
    this.router.navigate(['/reports/careby/time']);
  }

  singleEmployee() {
    this.router.navigate(['/reports/careby/single/employee']);
  }
  carechart() {
    this.router.navigate(['/reports/carechart']);
  }
  activity_list() {
    this.router.navigate(['/reports/activity']);
  }
  missedCheckin() {
    this.router.navigate(['/reports/missedlevel1checkin']);
  }
}
