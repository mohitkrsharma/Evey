import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multipleemployee',
  templateUrl: './multipleemployee.component.html',
  styleUrls: ['./multipleemployee.component.scss']
})
export class MultipleemployeeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
