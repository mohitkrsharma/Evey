import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from './../../../shared/services/api/api.service';
import { MatTableDataSource, MatSort, PageEvent } from '@angular/material';
import * as moment from 'moment';
import { ExcelService } from './../../../shared/services/excel.service';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as async from 'async';
import { CommonService } from 'src/app/shared/services/common.service';
@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent implements OnInit {

  constructor(
    private _route: ActivatedRoute,
    private _apiService: ApiService,
    private _excelService: ExcelService,
    public _commonService: CommonService
    ) { }

  recordMessage: string;
  loaderexport = false;
  loadervalue = 0; loaderbuffer = 2;
  count: any;
  public doc: any;
  public result: any;
  reportData; exportData;
  exportContentVal = [];
  displayedColumns = [];
  pageEvent: PageEvent;
  datasource;
  isShow: boolean;
  topPosToStartShowing = 100;
  public totalPagesExp = '{total_pages_count_string}';
  sortActive = 'name';
  sortDirection: 'asc' | 'desc' | '';
  data;
  inculdeA = {
    'isCallLight': 'CL',
    'isNotify': 'N',
    'is_out_of_fac': 'O',
    'isFind': 'F',
    'isNFC': 'NF'
  };

  // Column names in table
  columnNames = [
    {
      id: 'name',
      value: 'Resident',
      title: 'Resident',
      name: 'name',
      dataKey: 'Resident',
      sort: false
    },
    {
      id: 'facility',
      value: 'Facility',
      title: 'Facility',
      name: 'facility',
      dataKey: 'Facility',
      sort: true
    },
    {
      id: 'level',
      value: 'Level',
      title: 'Level',
      name: 'level',
      dataKey: 'Level',
      sort: true
    },
    {
      id: 'status',
      value: 'Includes',
      title: 'Status',
      name: 'status',
      dataKey: 'status',
      sort: false
    },
    {
      id: 'room',
      value: 'Zone',
      title: 'Zone',
      name: 'room',
      dataKey: 'Room',
      sort: true
    }
    , {
      id: 'user',
      value: 'Staff',
      title: 'Staff',
      name: 'user',
      dataKey: 'Staff',
      sort: true
    }
    , {
      id: 'care',
      value: 'Care',
      title: 'Care',
      name: 'care',
      dataKey: 'Care',
      sort: false
    },
    {
      id: 'outcome',
      value: 'Outcome',
      title: 'Outcome',
      name: 'outcome',
      dataKey: 'Outcome',
      sort: false
    }
    , {
      id: 'total_minutes',
      value: 'Total Minutes',
      title: 'Total Minutes',
      name: 'total_minutes',
      dataKey: 'Total Minutes',
      sort: true
    }
    , {
      id: 'ts_date_created',
      value: 'Performed Date',
      title: 'Performed Date',
      name: 'ts_date_created',
      dataKey: 'Performed Date',
      sort: true
    },
    {
      id: 'care_notes',
      value: 'Notes',
      title: 'Notes',
      name: 'care_notes',
      dataKey: 'Notes',
      sort: true
    }
  ];
  dataSource;
  // viewdata;

  @ViewChild(MatSort) sort: MatSort;
  pagiPayload = {
    length: 0,
    pageIndex: 0,
    pageSize: 10,
    previousPageIndex: 0,
    sort: { active: '', direction: 'asc' }
  };

  @HostListener('window:scroll')
  checkScroll() {

    // window의 scroll top
    // Both window.pageYOffset and document.documentElement.scrollTop
    // returns the same result in all the cases. window.pageYOffset is not supported below IE 9.

    const scrollPosition = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;

    if (scrollPosition >= this.topPosToStartShowing) {
      this.isShow = true;
    } else {
      this.isShow = false;
    }
  }

  // TODO: Cross browsing
  gotoTop() {
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }

  async ngOnInit() {
    this._commonService.setLoader(true);
    this.displayedColumns = this.displayedColumns.concat(this.columnNames.map(x => x.id));
    this.getServerData(this.pagiPayload);
  }

  // create angular material table
  createTable(arr) {
    const tableArr: Element[] = arr;
    this.dataSource = new MatTableDataSource(tableArr);
    // this.dataSource.sort = this.sort;
  }

  // Get list of reports
  public async getReportDataFunction() {
    const id = this._route.params['_value']['id'];
    const action = { type: 'POST', target: 'reports/view' };
    const payload = { reportId: id, pagination: this.pagiPayload };
    let result = await this._apiService.apiFn(action, payload);

    // this.viewdata = result['data']['view']
    this.count = (result['data'] && result['data']['count']) ? result['data']['count'] : 0;
    if (result['data'] && result['data']['resp'].length) {
      result = result['data']['resp'].map(
        _ => {
          const keypair = [];
          if (_.trackStatuses != null) {
            const peopleArray = Object.keys(_.trackStatuses).map(i => {
              if (_.trackStatuses[i]) { keypair.push(i); }
            });
          }
          return {
            ..._,
            time_duration: _.ts_time_track,
            name: this.formatName(_),
            room: _.room_id ? _.room_id.room ? _.room_id.room : '-' : '-',
            care: _.care_name ? _.care_name : '-',
            outcome: _.care_value ? _.care_value : '-',
            total_minutes: _.ts_total_minutes,
            // total_minutes: Math.round(_.ts_total_minutes / 1000) != 0 ? Math.round(_.ts_total_minutes / 1000) : '1',
            user: _.user_id ? `${_.user_id.first_name ? _.user_id.first_name : ''} ${_.user_id.last_name ? _.user_id.last_name : ''}` : '',
            care_notes: _.care_notes ? _.care_notes : '--',
            ts_date_created: moment(_.ts_total_time.start_time).format('MMMM Do YYYY, HH:mm:ss'),
            // this.formatDate(_.ts_total_time.start_time),
            level: _.care_level && _.care_level['name'] ? _.care_level['name'] : '-',
            facility: (_.facilityData && _.facilityData.length) ? _.facilityData[0]['fac_name'] : '-',
            status: keypair
          };
        });


      this.data = result;
      if (this.pagiPayload.sort && this.pagiPayload.sort.active === 'care') {
        this.data.sort(function (a, b) {
          const nameA = a.care.toUpperCase(), nameB = b.care.toUpperCase();
          if (nameA < nameB) {
            return -1;
          }
          if (nameA > nameB) {
            return 1;
          }
          return 0; // default return value (no sorting)
        });
      }
      if (this.pagiPayload.sort && this.pagiPayload.sort.active === 'outcome') {
        this.data.sort(function (a, b) {
          const nameA = a.outcome.toUpperCase(), nameB = b.outcome.toUpperCase();
          if (nameA < nameB) {
            return -1;
          }
          if (nameA > nameB) {
            return 1;
          }
          return 0; // default return value (no sorting)
        });
      }
      this.exportData = result;
      this.createTable(this.data);
      this._commonService.setLoader(false);
    } else {
      this.recordMessage = 'No Record Found';
      this._commonService.setLoader(false);
    }
  }

  // sort table data in asc or desc order
  sortData(sort?: PageEvent) {
    if (sort['direction'] === '') {
      this.sort.active = sort['active'];
      this.sort.direction = 'asc';
      this.sort.sortChange.emit({ active: sort['active'], direction: 'asc' });
      this.sort._stateChanges.next();
      return;
    }
    this._commonService.setLoader(true);
    this.pagiPayload.sort = { active: this.sort.active, direction: this.sort.direction };
    this.getReportDataFunction();
  }

  async getServerData(event?: PageEvent) {
    this._commonService.setLoader(true);
    this.pagiPayload.previousPageIndex = event.previousPageIndex;
    this.pagiPayload.pageIndex = event.pageIndex;
    this.pagiPayload.pageSize = event.pageSize;
    this.pagiPayload.length = event.length;
    this.getReportDataFunction();
  }

  // get resident names
  formatName(row) {
    // tslint:disable-next-line: max-line-length
    return (row.resident_id) ? (row.resident_id && row.resident_id.length) ? row.resident_id.map(item => `${item.first_name} ${item.last_name}`).toString() : (row.resident_id && !row.resident_id.length) ? `${row.resident_id.first_name} ${row.resident_id.last_name}` : (!row.resident_id || row.resident_name === ' ') && !row.care_id ? row.room_id.residents_id.map(_ => `${_.first_name} ${_.last_name}`).toString().replace('[', ' ').replace(']', ' ') : row.room_id.residents_id.map(_ => `${_.first_name} ${_.last_name}`).toString().replace('[', ' ').replace(']', ' ') : '-';
  }

  formatDate(ts_date_created) {
    if (ts_date_created) {
      return moment(ts_date_created).format('MMMM Do YYYY, HH:mm:ss');
    } else {
      return '';
    }
  }

  // Export PDF
  async exportContentData() {
    // this.loader = true;
    return new Promise(async (resolve) => {
      if (this.exportContentVal.length) {
        resolve(this.exportContentVal);
      } else {
        this.loaderexport = true;
        const actionCount = {
          type: 'GET',
          target: 'reports/export_count'
        };
        const payloadCount = { reportId: this._route.params['_value']['id'] };
        const resultCount = await this._apiService.apiFn(actionCount, payloadCount);

        let decExist = 0;
        const limit = 2500;
        const trackcount = resultCount['data'];


        const no = trackcount <= limit ? 1 : (trackcount / limit);
        if (trackcount % limit !== 0 && trackcount > limit) {
          decExist = 1;
        }
        let arrlen;
        if (decExist === 1) {
          arrlen = trackcount.length <= limit ? [1] : Array.from({ length: no + 1 }, (v, k) => k);
        } else {
          arrlen = trackcount.length <= limit ? [1] : Array.from({ length: no }, (v, k) => k);
        }

        // console.log('resultCountresultCountresultCount',arrlen, resultCount);
        const reportId = this._route.params['_value']['id'];
        const that = this;

        let resultAll = [];
        async.eachOfSeries(arrlen, async function (item, index, callback) {
          // console.log(item,index);
          // let action = { type: 'GET', target: 'reports/export' }
          const action = { type: 'POST', target: 'reports/view' };
          const payload = { reportId: reportId, pagination: { pageIndex: item, pageSize: limit } };
          const result = await that._apiService.apiFn(action, payload);
          if (result['data'] && result['data']['resp'].length) {
            const data = result['data']['resp'];
            resultAll = [...resultAll, ...data];
          }
          const totalItem = arrlen.length;
          that.loadervalue = (item / totalItem) * 100;
          that.loaderbuffer = that.loadervalue + 2;

          callback(null, result);
        }, async function (result) {
          that.exportContentVal = resultAll;
          resolve(that.exportContentVal);
          // return resultAll;
        });
      }
    });
  }

  // Export PDF
  async exportPdf() {

    const that = this;
    await this.exportContentData();
    const resultAll = this.exportContentVal;
    // console.log('resultresultresult',result,resultAll)
    if (resultAll.length) {
      const data = resultAll.map(
        _ => {

          return {
            ..._,
            time_duration: _.ts_time_track,
            name: that.formatName(_),
            room: _.room_id ? _.room_id.room ? _.room_id.room : '' : '',
            care: _.care_name ? _.care_name : '-',
            outcome: _.care_value ? _.care_value : '-',
            // care:_.care_name ? _.care_name  : _.care_name2 ? _.care_name2 : _.care_id.name ,
            //    outcome: _.care_value != null ? _.care_value : _.care_value == null && _.care_type !== 'UnTrack' ? _.care_type : '',
            // total_minutes: Math.round(_.ts_total_minutes / 1000) != 0 ? Math.round(_.ts_total_minutes / 1000) : '1',
            total_minutes: _.ts_total_minutes,
            // timeTrackData: _.ts_time_track[(_.ts_time_track.length) - 1].end_time,
            user: _.user_id ? `${_.user_id.first_name ? _.user_id.first_name : ''} ${_.user_id.last_name ? _.user_id.last_name : ''}` : '',
            care_notes: _.care_notes ? _.care_notes : '--',
            ts_date_created: moment(_.ts_total_time.start_time).format('MMMM Do YYYY, HH:mm:ss'),
            // this.formatDate(_.ts_total_time.start_time),
            // ts_date_created: moment(_.ts_date_created).format('MMMM Do YYYY, HH:mm:ss'),// this.formatDate(_.ts_date_created),
            level: _.care_level && _.care_level['name'] ? _.care_level['name'] : '-',
            facility: (_.facilityData && _.facilityData.length) ? _.facilityData[0]['fac_name'] : '-',
            find: (_.trackStatuses && _.trackStatuses.isFind != null) ? 'Yes' : 'No',
            call_light: (_.trackStatuses && _.trackStatuses.isCallLight != null) ? 'Yes' : 'No',
            notify: (_.trackStatuses && _.trackStatuses.isNotify != null) ? 'Yes' : 'No',
            is_out_of_Fac: (_.trackStatuses && _.trackStatuses.is_out_of_Fac != null) ? 'Yes' : 'No'
          };
        });
      that.exportData = data;
      let pdfdata;
      if (that.exportData.length) {
        pdfdata = that.exportData.map((it, itr) => {
          return {
            'Resident': it.name,
            'Level': it.level,
            'Find': it.find,
            'Call Light': it.call_light,
            'Facility': it.facility,
            'Out Of Facility': it.is_out_of_Fac,
            'Notify Care Team': it.notify,
            // 'Find':it.find && it.is_find!=null ?'Yes':'No',
            'Room': it.room,
            'Staff': it.user,
            'Care': it.care,
            'Outcome': it.outcome,
            'Total Minutes': it.total_minutes,
            'Performed Date': it.ts_date_created,
            'Notes': it.care_notes
            // 'Time Duration': JSON.stringify(arr).replace(/start_time/g, 'Start Time').
            // replace(/end_time/g, 'End Time').replace("[", "").replace(']', "")
          };
        });

      }
      that.doc = undefined;
      that.doc = new jsPDF('l', 'mm', 'a3');
      that.pageContent(true);
      /// this.doc.addPage();
      that.pageContent(false);
      const doc = new jsPDF('p', 'pt');
      that.columnNames.push({
          id: 'find',
          value: 'Find',
          title: 'Find',
          name: 'find',
          dataKey: 'Find',
          sort: false
        },
        {
          id: 'call_light',
          value: 'Call Light',
          title: 'Call Light',
          name: 'call_light',
          dataKey: 'Call Light',
          sort: false
        },
        {
          id: 'is_out_of_Fac',
          value: 'Out Of Facility',
          title: 'Out Of Facility',
          name: 'is_out_of_Fac',
          dataKey: 'Out Of Facility',
          sort: false
        },
        {
          id: 'notify',
          value: 'Notify Care Team',
          title: 'Notify Care Team',
          name: 'notify',
          dataKey: 'Notify Care Team',
          sort: false
        }
      );

      for (let i = 0; i < that.columnNames.length; i++) {
        if (that.columnNames[i]['id'] === 'status') {
          that.columnNames.splice(i, 1);
        }
      }

      await that.doc.autoTable(that.columnNames, ((pdfdata && pdfdata.length) ? pdfdata : ['No visits tracked']), {
        theme: 'striped',
        headerStyles: {
          // fillColor: 212,
          textColor: 20,
          halign: 'center',
          fontStyle: 'normal'
        },
        addPageContent: () => {
          that.pageContent(false);
        },
        // startY: 20,
        // margin: {
        //   top: 33,
        //   bottom: 20
        // },
        styles: {
          overflow: 'linebreak',
          lineColor: [221, 221, 221],
          lineWidth: 0.3,
          halign: 'center',
          valign: 'middle'
        },
        columnStyles: {
          'Sno': {
            columnWidth: 20
          },
          'Resident': {
            columnWidth: 20
          },
          // 'Zone': {
          //   columnWidth: 20
          // },
          'Staff': {
            columnWidth: 20
          },
          // 'Facility': {
          //   columnWidth: 20
          // },
          'Level': {
            columnWidth: 15
          },
          'Find': {
            columnWidth: 10
          },
          'Call Light': {
            columnWidth: 10
          },
          'Out Of Facility': {
            columnWidth: 10
          },
          // 'Care': {
          //   columnWidth: 20
          // },
          // 'Outcome': {
          //   columnWidth: 20
          // },
          // 'Total Minutes': {
          //   columnWidth: 20
          // },
          // 'Performed Date': {
          //   columnWidth: 30
          // },
          'Notes': {
            columnWidth: 30
          }
          // 'Time Duration': {
          //   columnWidth: 50
          // }
        },

        // tslint:disable-next-line: no-shadowed-variable
        drawRow: (row, data) => {
          if (row.index === 0 && row.raw === 'No visits tracked') {
            that.doc.rect(data.settings.margin.left, row.y, data.table.width, 8);
            that.doc.autoTableText(row.raw, data.settings.margin.left + data.table.width / 2, row.y + row.height / 2, {
              halign: 'center',
              valign: 'middle'
            });
            return false;
          }
        }
      });
      that.doc.putTotalPages(that.totalPagesExp);
      that.doc.save('Custom Report');
      that._commonService.setLoader(false);
      for (let i = 0; i < that.columnNames.length; i++) {
        if (that.columnNames[i]['id'] === 'find') {
          that.columnNames.splice(i, 1);
        }
        if (that.columnNames[i]['id'] === 'call_light') {
          that.columnNames.splice(i, 1);
        }
        if (that.columnNames[i]['id'] === 'is_out_of_Fac') {
          that.columnNames.splice(i, 1);
        }
        if (that.columnNames[i]['id'] === 'notify') {
          that.columnNames.splice(i, 1);
        }
      }
      that.columnNames.push({
        id: 'status',
        value: 'Includes',
        title: 'Status',
        name: 'status',
        dataKey: 'status',
        sort: false
      });
      // this.getServerData(this.pagiPayload)
      that.loadervalue = 0;
      that.loaderbuffer = 2;
      that.loaderexport = false;
      return;
    }
    // });

  }

  // page content design setup for pdf
  // tslint:disable-next-line: no-unnecessary-initializer
  pageContent(isHeader = undefined) {
    if (isHeader) {
    }
    // FOOTER
    let str = 'Page ' + this.doc.internal.getNumberOfPages();
    if (typeof this.doc.putTotalPages === 'function') {
      str = str + ' of ' + this.totalPagesExp;
    }
    this.doc.setFontSize(10);
    this.doc.setTextColor('#636c72');

    this.doc.text('Report Created by Evey.', 15, this.doc.internal.pageSize.height - 10);
    this.doc.text(str, this.doc.internal.pageSize.width + 25, this.doc.internal.pageSize.height - 10, null, null, 'right');
  }

  // export excel report
  async exportXlsx() {
    // const first_promise= await first_function();
    await this.exportContentData();
    const resultAll = this.exportContentVal;

    if (resultAll) {
      const data = resultAll.map(
        _ => {

          return {
            ..._,
            time_duration: _.ts_time_track,
            name: this.formatName(_),
            room: _.room_id ? _.room_id.room ? _.room_id.room : '' : '',
            care: _.care_name ? _.care_name : '-',
            outcome: _.care_value ? _.care_value : '-',
            total_minutes: _.ts_total_minutes,
            // timeTrackData: _.ts_time_track[(_.ts_time_track.length) - 1].end_time,
            user: _.user_id ? `${_.user_id.first_name ? _.user_id.first_name : ''} ${_.user_id.last_name ? _.user_id.last_name : ''}` : '',
            care_notes: _.care_notes ? _.care_notes : '--',
            ts_date_created: moment(_.ts_total_time.start_time).format('MMMM Do YYYY, HH:mm:ss'),
            // this.formatDate(_.ts_total_time.start_time),
            // ts_date_created: moment(_.ts_date_created).format('MMMM Do YYYY, HH:mm:ss'),//this.formatDate(_.ts_date_created),
            level: _.care_level && _.care_level['name'] ? _.care_level['name'] : '-',
            facility: (_.facilityData && _.facilityData.length) ? _.facilityData[0]['fac_name'] : '-',
            // find:_.is_find && _.is_find!=null?_.is_find:'-'
          };
        });
      this.exportData = data;
      const report = this.prepareUsersForCSV();
      this._excelService.exportAsExcelFile(report, 'Report');
    }
  }

  // prepare csv data to be generated
  prepareUsersForCSV() {
    const report = [];
    this.exportData.forEach(item => {

      report.push({
        'Resident': item.name ? item.name : '-',
        'Facility': item.facility ? item.facility : '-',
        'Level': (item.level) ? item.level : '-',
        'Find': (item.trackStatuses && item.trackStatuses.isFind != null) ? 'Yes' : 'No',
        'Call Light': (item.trackStatuses && item.trackStatuses.isCallLight != null) ? 'Yes' : 'No',
        'Out Of Facility': (item.trackStatuses && item.trackStatuses.is_out_of_Fac != null) ? 'Yes' : 'No',
        'Notify Care Team': (item.trackStatuses && item.trackStatuses.isNotify != null) ? 'Yes' : 'No',
        'Zone': item.room ? item.room : '-',
        'Staff': item.user ? item.user : '-',
        'Care': item.care ? item.care : '-',
        'Outcome': item.outcome ? item.outcome : '-',
        'Total Minutes': item.total_minutes,
        'Performed Date': item.ts_date_created,
        'Notes': item.care_notes ? item.care_notes : '-'
        // tslint:disable-next-line: max-line-length
        // "facility" :(_.resident_id.length && _.resident_id.length ===1  && _.resident_id[0].facility && _.resident_id[0].facility.length)?_.resident_id[0].facility[0].fac['fac_name']:'-'
        // tslint:disable-next-line: max-line-length
        // 'Time Duration': JSON.stringify(arr).replace(/start_time/g, 'Start Time').replace(/end_time/g, 'End Time').replace('[', '').replace(']', '')
      });
    });
    // this.loader = false;
    this.loadervalue = 0;
    this.loaderbuffer = 2;
    this.loaderexport = false;
    return report;

  }

}
export interface Element {
  position: number;
  name: string;
  weight: number;
  symbol: string;
}

// export interface PagiElement {
//   length: number;
//   pageIndex: number;
//   pageSize: number;
//   previousPageIndex: number;
//   sort: Object;
// }

