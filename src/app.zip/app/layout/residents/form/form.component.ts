import { Component, OnInit, TemplateRef, ViewChild,OnDestroy } from '@angular/core';
import { FormControl, FormGroupDirective, NgForm, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from './../../../shared/services/api/api.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from 'src/app/shared/services/common.service';
import { now } from 'moment';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { SocketService } from './../../../shared/services/socket/socket.service';
import { Subscription } from 'rxjs/Rx';
@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit,OnDestroy {
  floorFinalList;
  paramId: Boolean = false;
  emailNotMatch: Boolean = false;
  disable_checkin: Boolean = false;
  @ViewChild('callConfirmDialog') callConfirmDialog: TemplateRef<any>;
  @ViewChild('confirmStatus') confirmStatus: TemplateRef<any>;
  dialogConfig = new MatDialogConfig();
  dialogRefs: any;
  isolation_end_date: any = "";
  constructor(
    private fb: FormBuilder,
    private apiService: ApiService,
    private router: Router,
    private route: ActivatedRoute,
    private toastr: ToastrService,
    public commonService: CommonService,
    private dialog: MatDialog,
    private socketService: SocketService
  ) { }
  residentForm: FormGroup;
  organiz; faclist; floorlist; zonelist; seclist;
  statusData; carelevelData;
  loader = false;
  resident: any = {
    first_name: '',
    last_name: '',
    organization: '',
    facility: '',
    floor: '',
    sector: '',
    resident_status: '',
    care_level: '',
    billingId: '',
    email: '',
    confirmemail: '',
    home_phone: '',
    mobile_phone: '',
    is_out_of_fac: false,
    hospice: false,
    two_am_checkin: false

  };
  emergency = {
    isprimary: false,
    emergency_first_name: '',
    emergency_last_name: '',
    emergency_relation: '',
    emergency_email: '',
    emergency_confirmemail: '',
    emergency_home_phone: '',
    emergency_mobile_phone: '',
    emergency_notes: '',
  };

  public resident_relationship = [{ label: 'Spouse', value: 'Spouse' },
  { label: 'Child', value: 'Child' },
  { label: 'Relative', value: 'Relative' },
  { label: 'Significant Other', value: 'Significant Other' },
  { label: 'Friend', value: 'Friend' }];

  oldFacility: string;
  oldStatus: string;

  subscription: Subscription = new Subscription();
  async ngOnInit() {
    this.loadCarelevel();
    this.statusData = [
      { label: 'Active', value: 'Active' },
      { label: 'Deceased', value: 'Deceased' },
      { label: 'Moved', value: 'Moved' },
      { label: 'Transferred', value: 'Transferred' },
      { label: 'Hospitalized', value: 'Hospitalized' },
      { label: 'Temp Hospitalization', value: 'Temp Hospitalization' },
      { label: 'Vacation', value: 'Vacation' },
      { label: 'Skilled Nursing', value: 'Skilled Nursing' },
      { label: 'Pending', value: 'Pending' },
      { label: 'Other', value: 'Other' }];

    if (!this.route.params['_value']['id']) {
      // get organization list:
      const action = { type: 'GET', target: 'organization/orglist' };
      const payload = {};
      const result = await this.apiService.apiFn(action, payload);
      this.organiz = await result['data']; // .map(function (obj) {
    }

    if (this.route.params['_value']['id']) {
      this.loader = true;
      this.paramId = true;
      const action = { type: 'POST', target: 'residents/view' };
      const payload = { residentId: this.route.params['_value']['id'] };
      const result = await this.apiService.apiFn(action, payload);
      this.resident = result['data'];
      this.isolation_end_date = result['isolation_end_date'];
      
      if (result['data']['emergency']) {
        this.emergency['emergency_first_name'] = result['data']['emergency']['first_name'];
        this.emergency['emergency_last_name'] = result['data']['emergency']['last_name'];
        this.emergency['emergency_relation'] = result['data']['emergency']['relation'];
        this.emergency['emergency_email'] = result['data']['emergency']['email'];
        this.emergency['emergency_home_phone'] = result['data']['emergency']['homephone'];
        this.emergency['emergency_mobile_phone'] = result['data']['emergency']['mobilephone'];
        this.emergency['emergency_notes'] = result['data']['emergency']['notes'];
        this.emergency['emergency_confirmemail'] = result['data']['emergency']['email'];
      }
      const final_data = { ...result['data'] };

      this.resident['is_out_of_fac'] = final_data['is_out_of_fac'];
      this.resident['hospice'] = final_data['hospice'];
      this.resident['two_am_checkin'] = final_data['two_am_checkin'];
      this.resident['confirmemail'] = final_data['email'];
      
      if (final_data['care_level']['name'] === 'Level 1' || final_data['resident_status'] === 'Deceased' || final_data['resident_status'] === 'Moved' || final_data['resident_status'] === 'Transferred') {
        this.disable_checkin = true;
      }
      this.resident['care_level'] = final_data['care_level']['_id'];
      this.resident['organization'] = final_data['facility'][0]['org']['_id'];
      this.changeOrg(this.resident['organization'], 0);
      this.resident['facility'] = final_data['facility'][0]['fac']['_id'];
      this.oldFacility = final_data['facility'][0]['fac']['_id'];
      this.oldStatus = final_data['resident_status'];

      this.loader = false;
    } else {
      this.changeStatus('Active', 0);
    }

    // get organization list:
    const action = { type: 'GET', target: 'organization/orglist' };
    const payload = {};
    const result = await this.apiService.apiFn(action, payload);
    this.organiz = await result['data']; // .map(function (obj) {

    this.subscription.add(this.socketService.onResidentOutOfFacilityFn().subscribe(async (_response: any) => {
      if (_response) {
        if (this.resident._id != undefined && this.resident._id === _response._id) {
          this.resident['is_out_of_fac'] = _response.is_out_of_fac;
        }
      }
    }) );

    this.subscription.add( this.socketService.onResidentIsIsolationFn().subscribe(async (_response: any ) => {
      if (_response) {
       // console.log("socket data>>",_response,this.resident._id)
         
        if(_response._ids.indexOf(this.resident._id)>-1){
          let EndTime=(this.isolation_end_date=="")? _response.end_time_isolation:((_response.end_time_isolation>this.isolation_end_date)?_response.end_time_isolation:this.isolation_end_date);
          this.isolation_end_date="";
          setTimeout(()=>{
            this.isolation_end_date=EndTime;
          },0)
        }

      }
    }) );
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  repeatChanged() {
    this.dialogConfig.maxWidth = '500px';
    this.dialogRefs = this.dialog.open(this.callConfirmDialog, this.dialogConfig);
  }

  onNoClick(): void {
    this.resident.facility = this.oldFacility;
    this.dialogRefs.close(['result']['status'] = false);
  }

  onCancel(): void {
    this.resident.resident_status = this.oldStatus;
    this.dialogRefs.close(['result']['status'] = false);
  }

  async changeOrg(org, flag) {
    this.resident.facility = '';
    const action = { type: 'GET', target: 'facility/faclist' };
    const payload = { 'org_id': org };
    const result = await this.apiService.apiFn(action, payload);
    this.faclist = await result['data']; // .map(function (obj) {
    if (flag) {
      this.floorlist = null;

    }
  }

  async changeFac(fac, flag) {
    const action = { type: 'GET', target: 'floorsector/floorsector_list' };
    const payload = { 'facId': fac };
    const result = await this.apiService.apiFn(action, payload);
    this.floorlist = result['data'];
    this.floorFinalList = [...result['data']];
    if (flag) {
    }
  }


  async changeStatus(status, flag) {
    this.resident['resident_status'] = status;
    if (this.resident['resident_status'] !== 'Active') {
      // this.zonelist = [];
    } else {
      // this.changeSector(this.resident['sector'], flag)
    }
  }

  async changeCareLevel(carelevel,status, flag) {

    if (carelevel.label === 'Level 1' || status === 'Deceased' || status === 'Moved' || status === 'Transferred') {
      this.disable_checkin = true;
      this.resident.two_am_checkin = false;
    } else {
      this.disable_checkin = false;
    }
    this.resident['care_level'] = carelevel;
  }

  async changeRoom(room, flag) {
    this.resident['room'] = room;
  }

  async onSubmit(f, resident) {
    if (this.route.params['_value']['id']) {
      this.emergency['resident_id'] = this.route.params['_value']['id'];
    }
    this.resident.emergency = this.emergency;
    let vaild = f.form.status;
    resident.first_name = resident.first_name.trim();
    resident.last_name = resident.last_name.trim();
    if (resident.first_name === '' || resident.last_name === '') {
      vaild = 'INVALID';
    }
    if (vaild === 'VALID') {
      if (this.resident.email === this.resident.confirmemail) {
        this.emailNotMatch = false;
        f.form.controls['confirmemail'].setErrors(null);
      } else {
        this.emailNotMatch = true;
        f.form.controls['confirmemail'].setErrors({ 'incorrect': true });
      }
      if (!this.emailNotMatch) {
        this.loader = true;

        if (this.route.params['_value']['id'] && this.oldFacility != this.resident.facility) {

          this.dialogConfig.maxWidth = '500px';

          const action = { type: 'POST', target: 'residents/add' };
          const payload = resident;
          this.dialogConfig.data = {
            'action': action,
            'payload': payload
          };

          // this.dialog.open(RepeatCareComponent, dialogConfig);
          this.dialogRefs = this.dialog.open(this.callConfirmDialog, this.dialogConfig);
          this.loader = false;


        } else {
          if (this.route.params['_value']['id'] && this.oldStatus != this.resident.resident_status && (this.resident.resident_status === 'Deceased' || this.resident.resident_status === 'Transferred' || this.resident.resident_status === 'Moved')) {
            this.dialogConfig.maxWidth = '500px';

            const action = { type: 'POST', target: 'residents/add' };
            const payload = resident;
            this.dialogConfig.data = {
              'action': action,
              'payload': payload
            };

            this.dialogRefs = this.dialog.open(this.confirmStatus, this.dialogConfig);
            this.loader = false;

          } else {
            const action = { type: 'POST', target: 'residents/add' };
            const payload = resident;
            this.add_residents(action, payload);
          }
        }


      }

    } else {
      if (this.toastr.currentlyActive === 0) {
        this.toastr.error('Please enter resident details');
      }
    }

  }

  async add_residents(action, payload) {
    const result = await this.apiService.apiFn(action, payload);
    this.loader = false;
    this.route.params['_value']['id'] ? this.toastr.success('Resident updated successfully') : this.toastr.success('Resident added successfully');
    this.router.navigate(['/residents']);
  }

  async facilityChangeConfirm(action, payload) {

    const action1 = { type: 'POST', target: 'zones/unassigned_resident' };
    const payload1 = { resident: this.route.params['_value']['id'] };
    const result1 = await this.apiService.apiFn(action1, payload1);


    this.loader = true;
    this.dialogRefs.close(['result']['status'] = false);
    payload['room'] = null;
    this.add_residents(action, payload);

  }


  onChangefacility(event) {
    this.resident.out_of_Fac = event.checked;
  }

  onChangeHospice(event) {
    this.resident.hospice = event.checked;
  }

  onChangeCheckin(event) {
    this.resident.two_am_checkin = event.checked;
  }

  cancel() {
    this.router.navigate(['/residents']);
  }

  checkAlpha(key) {
    const result = this.commonService.allwoOnlyAlpharesi(key);
    return result;
  }

  checkAlphalast(key) {
    const result = this.commonService.allwoOnlyAlpha(key);
    return result;
  }

  async corrCheEmail(e, f) {
    if (this.resident.email === e.target.value) {
      this.emailNotMatch = false;
      f.form.controls['confirmemail'].setErrors(null);
    } else {
      this.emailNotMatch = true;
      f.form.controls['confirmemail'].setErrors({ 'incorrect': true });
    }
  }

  async loadCarelevel() {
    const action = { type: 'GET', target: 'residents/carelevellist' };
    const payload = { date: new Date() };
    const result = await this.apiService.apiFn(action, payload);
    this.carelevelData = result['data'];
  }
}
