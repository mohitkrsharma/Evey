import { Component, OnInit ,OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from './../../../shared/services/api/api.service';
import { ToastrService } from 'ngx-toastr';
import { SocketService } from './../../../shared/services/socket/socket.service';
import { Subscription } from 'rxjs/Rx';
@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent implements OnInit ,OnDestroy  {
  isolation_end_date: any="";
  subscription: Subscription = new Subscription();
  constructor(private route: ActivatedRoute,
    private router: Router,
    private apiService: ApiService,
    private toastr: ToastrService,
    private socketService: SocketService ) { }
  resident;
  id;
  loader = false;

  async ngOnInit() {
    this.loader = true;
    this.id = this.route.params['_value']['id'];
    const action = { type: 'POST', target: 'residents/view' };
    const payload = { residentId: this.id };
    const result = await this.apiService.apiFn(action, payload);
    console.log('213154545', result);
    this.resident = result['data'];
    this.isolation_end_date=result['isolation_end_date'];
    const final_data = { ...result['data'] };
    if (final_data['room'] && final_data['room']['floor'] && final_data['room']['floor']['sector']) {
      this.resident.sector = final_data['room']['floor']['sector'].filter((item) => {
        if (item._id === final_data['room']['sector']) {
          return item.name;
        }
      });
    }

    this.loader = false;
    this.subscription.add( this.socketService.onResidentOutOfFacilityFn().subscribe(async (_response:any )=> {
      if (_response) {
        // console.log("onResidentOutOfFacilityFn >>>",_response)
        if( this.resident._id!=undefined && this.resident._id === _response._id){
        
          this.resident['is_out_of_fac']=_response.is_out_of_fac;
        }
        
        
        
      }
    }) )

    this.subscription.add( this.socketService.onResidentIsIsolationFn().subscribe(async (_response: any ) => {
      if (_response) {
        //console.log("socket data>>",_response,this.resident._id)
        
       if(_response._ids.indexOf(this.resident._id)>-1){
          let EndTime=(this.isolation_end_date=="")? _response.end_time_isolation:((_response.end_time_isolation>this.isolation_end_date)?_response.end_time_isolation:this.isolation_end_date);
          this.isolation_end_date="";
          setTimeout(()=>{
            this.isolation_end_date=EndTime;
          },0)
          
        }
       
      }
    })  );
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  editResident() {
    this.router.navigate(['/residents/form', this.route.params['_value']['id']]);
  }

  cancel() {
    this.router.navigate(['/residents']);
  }

  async onChangefacility(event) {
    const residentlist = [];
    residentlist.push(this.id);
    const action = { type: 'POST', target: 'residents/resi_outoffac' };
    const payload = { 'residentList': residentlist, value: event.checked };
    const result = await this.apiService.apiFn(action, payload);
    if (result['status']) {
      // this.toastr.show(result['message']);
    } else {
      // this.toastr.error(result['message']);
    }
  }

  async onChangeHospice(event) {
    const action = { type: 'POST', target: 'residents/resi_hospice' };
    const payload = { 'residentId': this.id, value: event.checked };
    const result = await this.apiService.apiFn(action, payload);
    if (result['status']) {
       this.toastr.success('Hospice status updated successfully');
    } else {
       this.toastr.error('Hospice status cannot be updated');
    }
  }

  async onChangeCheckin(event) {
    const action = { type: 'POST', target: 'residents/resi_two_am_checkin' };
    const payload = { 'residentId': this.id, value: event.checked };
    const result = await this.apiService.apiFn(action, payload);
    if (result['status']) {
       this.toastr.success('Checkin status updated successfully');
    } else {
       this.toastr.error('Checkin status cannot be updated');
    }
  }
}


