import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListComponent } from './list/list.component';
 import { FormComponent } from './form/form.component';
 import { ViewComponent } from './view/view.component';
const routes: Routes = [
  {
    path: '', // beacons
    data: { breadcrumb: 'Residents' },
    // component: BeaconsComponent,
    children: [
      {
        path: '',
        data: { breadcrumb: null },
        component: ListComponent
      },
      {
        path: 'form',
        data: { breadcrumb: 'Add Resident' },
        component: FormComponent
      },
      {
        path: 'view/:id',
        data: { breadcrumb: 'View Resident' },
        component: ViewComponent
      },
      {
        path:'form/:id',
        data: { breadcrumb: 'Edit Resident' },
        component: FormComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ResidentsRoutingModule { }
