import { Component, OnInit, ViewChild, HostListener, ElementRef,OnDestroy } from '@angular/core';
import { MatTableDataSource, MatSort, PageEvent, MatPaginator } from '@angular/material';
import { Router } from '@angular/router';
import { ApiService } from './../../../shared/services/api/api.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AlertComponent } from '../../../shared/modals/alert/alert.component';
import { ExcelService } from './../../../shared/services/excel.service';
import { SocketService } from './../../../shared/services/socket/socket.service';
import { ToastrService } from 'ngx-toastr';
import { Item } from 'angular2-multiselect-dropdown';
import { fromEvent } from 'rxjs';
import {Observable} from 'rxjs';
import {timer} from 'rxjs/observable/timer';
import {
  debounceTime,
  map,
  distinctUntilChanged,
  filter,
  tap
} from 'rxjs/operators';
// tslint:disable-next-line:import-blacklist
import { Subscription } from 'rxjs/Rx';
import { CommonService } from './../../../shared/services/common.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit,OnDestroy {
  @ViewChild('searchInput') searchInput: ElementRef;
  @ViewChild('deleteButton') private deleteButton: ElementRef;

  
  floorlist;
  seclist;
  org; fac; org_filter; fac_filter;
  public btnAction: Function;
  public filtershow = false;
  search: any;
  // MATPAGINATOR
  // pageEvent: PageEvent;
  datasource: null;
  pageIndex: number;
  pageSize: number;
  length: number;
  exportdata;
  dataSource;
  displayedColumns = [];
  arr = [];
  filedata; residentlevel;
  isShow: boolean;
  topPosToStartShowing = 100;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  public show = false;
  public buttonName: any = 'Show';
  sortActive = 'name';
  sortDirection: 'asc' | 'desc' | '';
  actualDataCount;
  /**
   * Pre-defined columns list for user table
   */
  columnNames = [
    {
      id: 'name',
      value: 'Resident Name',
      sort: true
    },
    // {
    //   id: 'facility',
    //   value: 'Facility',
    //   sort: true
    // },
    {
      id: 'care_level',
      value: 'Level',
      sort: true
    },
    {
      id: 'resident_status',
      value: 'Status',
      sort: true
    }
  ];
  organization; facility; floor;
  checked; faclist; floorvalue; floor_filter;
  deleteArr = [];
  deleteItem = [];
  data :any=[];
  organiz;
  pagiPayload = {
    length: 0,
    pageIndex: 0,
    pageSize: 10,
    previousPageIndex: 0,
    search: '',
    sort: { active: 'name', direction: 'asc' }
  };
  count; sector;
  carelevelData = [
    { label: 'Level 1', value: 'Level 1' },
    { label: 'Level 2', value: 'Level 2' },
    { label: 'Level 3', value: 'Level 3' },
    { label: 'Self', value: 'Self' },
    { label: 'Mobility Assistance (All Day)', value: 'Mobility Assistance (All Day)' },
    { label: 'Mobility Assistance (Per Occurrence)', value: 'Mobility Assistance (Per Occurrence)' },
    { label: 'Bathing Assistance', value: 'Bathing Assistance' },
    { label: 'Short Term Stay', value: 'Short Term Stay' },
    { label: 'Short-Term Stay (No Services)', value: 'Short-Term Stay (No Services)' }
  ];
  private subscription1: Subscription;
  subscription: Subscription = new Subscription();
  constructor(
    private router: Router,
    private apiService: ApiService,
    public dialog: MatDialog,
    private excelService: ExcelService,
    private toastr: ToastrService,
    public commonService: CommonService,
    private socketService: SocketService
  ) { }


  @HostListener('window:scroll')
  checkScroll() {
    const scrollPosition = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
    if (scrollPosition >= this.topPosToStartShowing) {
      this.isShow = true;
    } else {
      this.isShow = false;
    }
  }

  gotoTop() {
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }

  async ngOnInit() {
    if (sessionStorage.getItem('pageListing')) {
      const pageListing = JSON.parse(sessionStorage.getItem('pageListing'));
      if (pageListing.residentList) {
        this.pagiPayload.previousPageIndex = pageListing.residentList.previousPageIndex;
        this.pagiPayload.pageIndex = pageListing.residentList.pageIndex;
        this.pagiPayload.pageSize = pageListing.residentList.pageSize;
        this.pagiPayload.length = pageListing.residentList.length;
      } else {
        sessionStorage.setItem('pageListing', JSON.stringify({ residentList: this.pagiPayload }));
      }
    } else {
      sessionStorage.setItem('pageListing', JSON.stringify({ residentList: this.pagiPayload }));
    }
    this.search = this.searchInput.nativeElement.value;
    fromEvent(this.searchInput.nativeElement, 'keyup')
      .pipe(
        debounceTime(2000),
        distinctUntilChanged(),
        tap(() => {
          this.getServerData(this.pagiPayload);
        })
      )
      .subscribe();

    this.btnAction = this.addForm.bind(this);
    this.displayedColumns = this.displayedColumns.concat(['checkbox']);
    this.displayedColumns = this.displayedColumns.concat(this.columnNames.map(x => x.id));
    this.displayedColumns = this.displayedColumns.concat(['outofFac']);
    this.displayedColumns = this.displayedColumns.concat(['isVirusCheck']);
    this.displayedColumns = this.displayedColumns.concat(['actions']);

    this.subscription1 = this.commonService.contentdata.subscribe((contentVal: any) => {
      this.commonService.setLoader(true);
      if (contentVal.org && contentVal.fac) {

        this.pagiPayload['organization'] = contentVal.org;
        this.pagiPayload['facility'] = contentVal.fac;
        //console.log("herere>>",this.pagiPayload)
        this.getServerData(this.pagiPayload);
      }
    });

    this.subscription.add(this.socketService.onResidentOutOfFacilityFn().subscribe(async (_response: any ) => {
      if (_response) {
        //console.log("here --",_response) 
        const index = this.data.findIndex(item => item._id === _response._id);
        this.data[index]['outofFac'] = _response.is_out_of_fac;
        this.createTable(this.data);
      }
    }) );
    this.subscription.add(this.socketService.onResidentIsVirusCheckFn().subscribe(async (_response: any ) => {
      if (_response) {
        const index = this.data.findIndex(item => item._id === _response._id);
        if(index>-1){
        this.data[index]['isVirusCheck'] = _response.is_virus_check;
        this.createTable(this.data);
        }
      }
    }) );

    this.subscription.add( this.socketService.onResidentListIsVirusCheckFn().subscribe(async (_response: any ) => {
      if (_response) {
        
       // console.log("here list",_response) 
        _response.forEach((_item)=>{
          const index = this.data.findIndex(item => item._id === _item._id);
          if(index>-1){
          this.data[index]['isVirusCheck'] = _response.is_virus_check;
          }
        })
        this.createTable(this.data);
        
      }
    }) );

    this.subscription.add( this.socketService.onResidentIsIsolationFn().subscribe(async (_response: any ) => {
      if (_response && this.data.length>0) {
        
        const index = this.data.findIndex(item =>  _response._ids.indexOf(item._id)>-1);
        if(index>-1){
           let EndTime=(this.data[index]['isolation_end_date']=="")? _response.end_time_isolation:((_response.end_time_isolation>this.data[index]['isolation_end_date'])?_response.end_time_isolation:this.data[index]['isolation_end_date']);
           this.data[index]['isolation_end_date']="";
          setTimeout(()=>{
            this.data[index]['isolation_end_date']=EndTime;
          },0)
          
          this.createTable(this.data);
        }
       
      }
    }) );
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  download() {
    if (this.organization && this.facility) {
      for (let i = 0; i < 10; i++) {
        this.arr.push({ org_id: this.organization['_id'], fac_id: this.facility });
      }
      const residents = this.prepareForExport();
      this.excelService.exportAsExcelFile(residents, 'Add Resident');
    } else {
      this.toastr.error('Please select organization and facility');
    }
  }

  async onFileChange(event) {
    this.commonService.setLoader(true);
      const organization = this.pagiPayload['organization'];
      const facility = this.pagiPayload['facility'];
      const filesData = event.target.files;
      const filetype = filesData[0].name.split('.');
      if (filetype[1] === 'xlsx' || filetype[1] === 'xls') {
        const fd = new FormData();
        fd.append('file', filesData[0]);
        fd.append('organization', organization);
        fd.append('facility', facility);

        const action = { type: 'FORMDATA', target: 'residents/upload' };
        const payload = fd;
        const result = await this.apiService.apiFn(action, payload);
        this.commonService.setLoader(false);
        if (result['status']) {
          this.toastr.success(result['message']);
        } else {
          this.toastr.error(result['message']);
        }
        this.show = false;
        this.residentlevel = '';
        delete this.pagiPayload['org_name'];
        delete this.pagiPayload['org_filter'];
        delete this.pagiPayload['fac_filter'];
        delete this.pagiPayload['floor_filter'];
        delete this.pagiPayload['fac_name'];
        delete this.pagiPayload['floor'];
        delete this.pagiPayload['sector'];
        delete this.pagiPayload['level'];
        this.filtershow = false;
        this.filedata = '';

      } else {
        this.toastr.error('Use the sample data format for uploading residents', 'Oops!');
      }

  }


  prepareForExport() {
    const resident = [];
    this.arr.forEach(item => {
      resident.push({
        'first_name': null,
        'last_name': null,
        'email': null,
        'home_phone': null,
        'mobile_phone': null,
        'facility': item.fac_id,
        'organization': item.org_id,
        'resident_status': 'Active'
      });
    });
    return resident;

  }

  selectAll() {
    if (this.checked === true) {
      this.data.forEach(element => {
        element.checked = false;
        this.deleteArr = [];
      });
    } else {
      this.data.forEach(element => {
        this.deleteArr.push(element._id);
        element.checked = true;
      });
    }
  }

  selectElement(id, check) {
    if (check === true) {
      for (let i = 0; i < this.deleteArr.length; i++) {
        if (this.deleteArr[i] === id) {
          this.deleteArr.splice(i, 1);
        }
      }
    } else if (check === undefined || check === false) {
      this.deleteArr.push(id);
    }
    if ((this.deleteArr && this.deleteArr.length) < this.actualDataCount) {
      this.checked = false;
    } else if ((this.deleteArr && this.deleteArr.length) === this.actualDataCount) {
      this.checked = true;
    }
  }

  delete() {
    if (this.deleteArr.length === 0) {
      this.toastr.error('Please select residents to be deleted');
      this.checked = false;
    } else {
      const dialogRef = this.dialog.open(AlertComponent, {
        width: '350px',
        data: { 'title': 'residents', 'id': this.deleteArr, 'API': 'residents/delete' }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (!result) {
          this.data.forEach(element => {
            element.checked = false;
          });
          this.deleteArr = [];
          this.checked = false;
        } else {
          this.toastr.success('Resident deleted successfully');
          this.getServerData(this.pagiPayload);
          this.checked = false;
        }

        this.deleteButton['_elementRef'].nativeElement.classList.remove('cdk-program-focused');
        this.deleteButton['_elementRef'].nativeElement.classList.remove('cdk-focused');
        document.getElementById('searchInput').focus();
        document.getElementById('searchInput').blur();
      });
    }
  }

  getName(first, last) {
    return first.concat(last);
  }

  createTable(arr) {
    const tableArr: Element[] = arr;
    this.dataSource = new MatTableDataSource(tableArr);
    // this.dataSource.sort = this.sort;
  }

  viewResident(id) {
    this.router.navigate(['/residents/view', id]);
  }

  addForm() { // Custom-code!
    this.router.navigate(['/residents/form']);
  }

  editResident(id) {
    this.router.navigate(['/residents/form', id]);
  }

  toggle() {
    this.show = !this.show;
    this.filtershow = false;

    this.organization = '';
    this.facility = '',
      //   this.floor = '';
      // this.sector = '';
      this.residentlevel = '';
    delete this.pagiPayload['org_name'];
    delete this.pagiPayload['fac_name'];
    delete this.pagiPayload['floor'];
    delete this.pagiPayload['sector'];
    delete this.pagiPayload['org_filter'];
    delete this.pagiPayload['fac_filter'];
    delete this.pagiPayload['floor_filter'];
    delete this.pagiPayload['level'];
    this.getServerData(this.pagiPayload);
  }

  filter() {
    this.filtershow = !this.filtershow;
    this.show = false;

    this.organization = '';
    this.facility = '',
      //   this.floor = '';
      // this.sector = '';
      this.residentlevel = '';
    delete this.pagiPayload['org_name'];
    delete this.pagiPayload['fac_name'];
    delete this.pagiPayload['floor'];
    delete this.pagiPayload['sector'];
    delete this.pagiPayload['org_filter'];
    delete this.pagiPayload['fac_filter'];
    delete this.pagiPayload['floor_filter'];
    delete this.pagiPayload['level'];
    this.getServerData(this.pagiPayload);
  }

  deleteResident(id) {
    const dialogRef = this.dialog.open(AlertComponent, {
      width: '350px',
      data: { 'title': 'resident', 'id': id, 'API': 'residents/delete' }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result && result['status']) {
        this.toastr.success(result['message']);
        this.getServerData(this.pagiPayload);
        this.checked = false;
      }
    });
  }

  async exportResident() {
    this.commonService.setLoader(true);
    const action = {
      type: 'GET',
      target: 'residents/export'
    };
    const payload = this.pagiPayload;
    let result = await this.apiService.apiFn(action, payload);
    //result = result['data'];
    if (result['status']) {
      const data = result['data'];
      this.exportdata = data;
      const users = this.prepareUsersForCSV();
      this.excelService.exportAsExcelFile(users, 'Resident_Report');
    }
  }

  prepareUsersForCSV() {
    const residents = [];
    console.log('this.exportdata', this.exportdata);
    this.exportdata.forEach(item => {
      residents.push({
        'First Name': item.first_name ? item.first_name : '-',
        'Last Name': item.last_name ? item.last_name : '-',
        'Email': item.email ? item.email : '-',
        'Home Phone': item.home_phone ? item.home_phone : '-',
        'Mobile Phone': item.mobile_phone ? item.mobile_phone : '-',
        'Organization': (item.facility && item.facility.length > 0) && item.facility[0].org ? item.facility[0].org.org_name : '--',
        'Facility': (item.facility && item.facility.length > 0) && item.facility[0].fac ? item.facility[0].fac.fac_name : '--',
        'Care Level': (item.care_level && item.care_level['name']) ? item.care_level['name'] : '-',
        'Out of facility': item.is_out_of_fac ? 'true' : 'false',
        'Status': item.resident_status ? item.resident_status : '-'
      });
    });
    this.commonService.setLoader(false);
    return residents;
  }

  public async getResidentUsersDataFunction() { 
    let sec;
    const action = {
      type: 'GET',
      target: 'residents'
    };
    const payload = this.pagiPayload;

    let result = await this.apiService.apiFn(action, payload);
    //result = result['data'];

   // console.log("console>>>>>",result)
    this.count = result['data']['_count'];
    if (result['status']) {
      if ((!result['data']['_residents'] || result['data']['_residents'].length === 0) && this.pagiPayload.pageIndex > 0) {
        this.paginator.previousPage();
      } else {
        this.count = result['data']['_count'];

        result = result['data']['_residents'].map(item => {
          if (item.sector && item.sector.length > 0) {
            sec = (item.sector).filter((it) => {
              if (it._id === item.sectorId) {
                return it.name;
              }
            });
          }
          return {
            ...item,
            name: item.last_name + ',' + ' ' + item.first_name,
            // organization: item.organization ? item.organization : '--',
            facility: item.facility ? item.facility : '-',
            // sector: (sec && sec.length > 0) ? sec[0]['name'] : '--',
            // floor: item.floor ? item.floor : '-',
            resident_status: item.resident_status ? item.resident_status : '-',
            care_level: item.care_level ? item.care_level : '-',
            outofFac: item.outofFac ? item.outofFac : false,
            isVirusCheck: item.isVirusCheck ? item.isVirusCheck : false,
            isolation_end_date: item.isolation_end_date,
          };
        });
        this.commonService.setLoader(false);
        this.data = result;
        if (this.data && this.data.length > 0) {
          this.actualDataCount = this.data.length;
        }
        this.createTable(result);
        this.checked = false;
        this.deleteArr = [];
      }

    }
  }



  sortData(sort?: PageEvent) {
    if (sort['direction'] === '') {
      this.sort.active = sort['active'];
      this.sort.direction = 'asc';
      this.sort.sortChange.emit({ active: sort['active'], direction: 'asc' });
      this.sort._stateChanges.next();
      return;
    }
    this.commonService.setLoader(true);
    this.pagiPayload.sort = {active: this.sort.active, direction: this.sort.direction};
    sessionStorage.setItem('pageListing', JSON.stringify({ residentList: this.pagiPayload }));
    this.getResidentUsersDataFunction();
  }

  public async getServerData(event?: PageEvent) {   
    // this.loader = true;
    this.pagiPayload.previousPageIndex = event.previousPageIndex;
    this.pagiPayload.pageIndex = event.pageIndex;
    this.pagiPayload.pageSize = event.pageSize;
    this.pagiPayload.length = event.length;
    this.pagiPayload.search = this.search;
    sessionStorage.setItem('pageListing', JSON.stringify({ residentList: this.pagiPayload }));
    this.getResidentUsersDataFunction();
  }

  async onChangefacility(event, resid_id) {
    const residentlist = [];
    residentlist.push(resid_id);
    const action = { type: 'POST', target: 'residents/resi_outoffac' };
    const payload = { 'residentList': residentlist, value: event.checked };
    const result = await this.apiService.apiFn(action, payload);
    if (result['status']) {
      this.toastr.success(result['message']);
    } else {
      this.toastr.error(result['message']);
    }
  }
  async onChangeVirusCheck(event, resid_id) {
    const residentlist = [];
    residentlist.push(resid_id);
    const action = { type: 'POST', target: 'residents/resi_viruscheck' };
    const payload = { 'residentList': residentlist, value: event.checked };
    const result = await this.apiService.apiFn(action, payload);
    if (result['status']) {
      this.toastr.success(result['message']);
    } else {
      this.toastr.error(result['message']);
    }
  }

  changeLevel(level, type) {
    this.commonService.setLoader(true);
    this.pagiPayload['level'] = level.label;
    this.getServerData(this.pagiPayload);

  }

  resetFilter() {
    this.organization = '';
    this.facility = '';
    this.floor = '';
    this.residentlevel = '';
    delete this.pagiPayload['org_name'];
    delete this.pagiPayload['fac_name'];
    delete this.pagiPayload['floor'];
    delete this.pagiPayload['org_filter'];
    delete this.pagiPayload['level'];
    this.getServerData(this.pagiPayload);
  }

  // searching
  onChange(item, event) {
    this.search = item;
    setTimeout(() => {
      this.getServerData(this.pagiPayload);
    }, 2000);
  }

}

export interface Element {
  position: number;
  name: string;
  weight: number;
  symbol: string;
}

// export interface PagiElement {
//   length: number;
//   pageIndex: number;
//   pageSize: number;
//   previousPageIndex: number;
//   search: '',
//   sort: Object
// }
