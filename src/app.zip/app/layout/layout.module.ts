import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { PipesModule } from './../shared/pipes/pipes.module';
import { AgmCoreModule } from '@agm/core';
import { MatButtonModule, MatIconModule, MatListModule, MatMenuModule, MatToolbarModule, MatExpansionModule,
     MatInputModule } from '@angular/material';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { BreadcrumbComponent } from './components/breadcrumb/breadcrumb.component';
import { LoaderComponent } from './components/loader/loader.component';
import { TopnavComponent } from './components/topnav/topnav.component';
import { LayoutRoutingModule } from './layout-routing.module';
import { LayoutComponent } from './layout.component';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSelectModule, MatFormFieldModule, MatProgressSpinnerModule } from '@angular/material';
import { FormsModule } from '@angular/forms';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { MatTooltipModule } from '@angular/material/tooltip';


@NgModule({
    imports: [
        CommonModule,
        LayoutRoutingModule,
        AgmCoreModule.forRoot({
            apiKey: 'AIzaSyC2lht-_fRNIFmJ2Lj2RfEPdN9rvCSGpfw',
            libraries: ['places']
        }),
        FormsModule,
        MatMenuModule,
        MatIconModule,
        MatFormFieldModule,
        MatSelectModule,
        MatToolbarModule,
        MatExpansionModule,
        MatListModule,
        MatDialogModule,
        MatButtonModule,
        MatInputModule,
        MatProgressSpinnerModule,
        BreadcrumbModule,
		MatTooltipModule
    ],
    declarations: [
        LayoutComponent,
        TopnavComponent,
        SidebarComponent,
        BreadcrumbComponent,
        LoaderComponent
        
    ],
    providers: [ PipesModule ],
})

export class LayoutModule {}
