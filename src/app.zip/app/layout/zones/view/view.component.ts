import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from './../../../shared/services/api/api.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent implements OnInit {

  constructor(private route: ActivatedRoute,
    private router: Router,
    private apiService: ApiService,
    private toastr: ToastrService) { }
  zone;
  loader = false;

  async ngOnInit() {
    this.loader = true;
    const id = this.route.params['_value']['id'];
    const action = { type: 'POST', target: 'zones/view' };
    const payload = { zoneId: id };
    const result = await this.apiService.apiFn(action, payload);
    this.zone = result['data'];
    this.zone['total_residents'] = (result['data'].residents_id && result['data'].residents_id.length) ? result['data'].residents_id.length : '0';
    if (result['data']['floor'] && result['data']['floor']['sector']) {
      this.zone['sector'] = result['data']['floor']['sector'].filter(it => it._id === result['data']['sector']);
    }


    if (this.zone['sector'] && this.zone['sector'].length) {
      this.zone['sector'] = this.zone['sector'][0]['name'];
    } else {
      this.zone['sector'] = '-';
    }
    
    this.loader = false;
  }

  editZone(id) {
    this.router.navigate(['/zones/form', id]);
  }

  cancel() {
    this.router.navigate(['/zones']);
  }

  async onChangeReady(id, event) {
    const action = { type: 'POST', target: 'zones/ready_to_move' };
    const payload = { 'zoneId': id, value: event.checked };
    const result = await this.apiService.apiFn(action, payload);
    if (result['status']) {
       this.toastr.success('Ready to move status updated successfully');
    } else {
       this.toastr.error('Ready to move status cannot be updated');
    }
  }

}
