import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroupDirective, NgForm, FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { ApiService } from './../../../shared/services/api/api.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs/Rx';
import { CommonService } from './../../../shared/services/common.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {
  zoneForm: FormGroup;
  beacon; residents; resident;
  organiz; faclist; seclist; floorlist; zonelist;
  beaconlist = [];
  facility;organization;
  residentlist = [];
  deletedbeacon = []; deletedresident = [];
  private subscription: Subscription;
  constructor(private fb: FormBuilder,
    private apiService: ApiService,
    private router: Router,
    private route: ActivatedRoute,
    private toastr: ToastrService,
    public commonService: CommonService) {

  }

  beacons;
  flag = false;
  loader = false; count = 0;
  zone = {
    org: '',
    fac: '',
    floor: '',
    sector: '',
    type: '',
    room: '',
    ready_to_move: false
  };
  paramId;
  public roomtypes = [{ label: 'Room', value: 'room' },
  { label: 'Hallway', value: 'hallway' },
  { label: 'Other', value: 'other' },
  { label: 'Exit', value: 'exit' },
  { label: 'Dining', value: 'dining' },
  { label: 'Spa', value: 'spa' },
  { label: 'Laundry', value: 'laundry' },
  { label: 'Medcart', value: 'medcart' },
  { label: 'Weight', value: 'weight' },
  { label: 'Restroom', value: 'restroom' }
  ];

//   medcart
// weight
// restroom
  async ngOnInit() {
    this.paramId = this.route.params['_value']['id'];
    const paramVal = this.route.params;
    this.loader = true;
    this.subscription = this.commonService.contentdata.subscribe(async (contentVal: any) => {

      if (contentVal.org && contentVal.fac && contentVal.floorlist) {
        this.zone['org'] = this.organization = contentVal.org;
        this.zone['fac'] = this.facility = contentVal.fac;
      
        this.floorlist = contentVal.floorlist;
        this.seclist = null;
        this.zone.floor = '';
        this.zone.sector = '';
        
        this.loader = false;
        if (this.route.params['_value']['floor']) {
          this.flag = true;
          this.paramId = null;
          // const action = { type: 'GET', target: 'floorsector/floorsector_list' };
          // const payload = { facId: this.route.params['_value']['fac'] };
          // const result = await this.apiService.apiFn(action, payload);
          // this.floorlist = result['data'].map(function (obj) {
          //     const rObj = {};
          //     rObj['label'] = obj.floor;
          //     rObj['value'] = obj._id;
          //     rObj['sector'] = obj.sector;
          //     return rObj;
          // });
            this.zone['org'] = this.route.params['_value']['org'];
            this.zone['fac'] = this.route.params['_value']['fac'];
            this.zone['floor'] = this.route.params['_value']['floor'];
            this.changeFloor(this.route.params['_value']['floor']);
            this.zone['sector'] = this.route.params['_value']['sector'];
        }
        
        if (this.route.params['_value']['id'] && this.route.params['_value']['id'] !== "0") {
         
          this.loader = true;
          this.beaconlist=[]; this.residentlist = [];
         
          const action = { type: 'POST', target: 'zones/view' };
          const payload = { zoneId: this.route.params['_value']['id'] };
          const result = await this.apiService.apiFn(action, payload);
      
          this.zone = result['data'];
   
          this.zone['org'] = this.zone['org']['_id'] ? this.zone['org']['_id'] : this.route.params['_value']['org'];
          this.zone['fac'] = this.zone['fac']['_id'] ? this.zone['org']['_id']: this.route.params['_value']['fac'];
          this.beaconlist = result['beacons'];
          this.residentlist = result['residents'];

          this.zone['floor'] = result['data']['floor']['_id'] ? result['data']['floor']['_id'] : this.route.params['_value']['floor'] ;
          await this.changeFloor(this.zone['floor']);
          this.zone['sector'] = result['data']['sector'] ?result['data']['sector'] : this.route.params['_value']['sector'];
          this.loader = false;
         
        }
        

        this.unassignedbeacons();
      }

    });
    // this.subscription = this.commonService.floorcontentdata.subscribe(async (data: any) => {
    //   if (data) {
    //     this.floorlist = data;
    //   }
    // });
  }


  async unassignedbeacons() {
    const action1 = { type: 'POST', target: 'beacons/unassigned' };
    
    const payload1 = {
      zoneId: this.route.params['_value']['id'], org: typeof (this.zone['org']) === 'object' ? this.zone['org']['_id'] : this.zone['org'] ? this.zone['org']:this.organization
      , fac: typeof (this.zone['fac']) === 'object' ? this.zone['fac']['_id'] : this.zone['fac'] ? this.zone['fac'] :this.facility
    };
   
    const result1 = await this.apiService.apiFn(action1, payload1);
    this.beacons = result1['data']['beacons'];
    this.residents = result1['data']['residents'];
   
  }

  async changeFloor(floor) {
    if (!this.route.params['_value']['id']) {
      this.zone['sector'] = '';
    }

    if (this.floorlist) {
      const _secList = [];
      this.seclist = this.floorlist.map(function (it) {
        if (it.value === floor) {
          it['sector'].map(function (item) {
            _secList.push(item);
          });
        }
      });
      this.seclist = _secList.map(function (obj) {
        const rObj = {};
        rObj['label'] = obj.name;
        rObj['value'] = obj._id;
        return rObj;
      });
      this.seclist.sort((a, b)  =>
       (a.label).localeCompare((b.label), navigator.languages[0] || navigator.language, {numeric: true, ignorePunctuation: true}));
    } else {
      const _secList = [];
      this.seclist = this.floorlist.map(function (it) {
        if (it.value === floor) {
          it['sector'].map(function (item) {
            _secList.push(item);
          });
        }
      });
      this.seclist = _secList.map(function (obj) {
        const rObj = {};
        rObj['label'] = obj.name;
        rObj['value'] = obj._id;
        return rObj;
      });
      this.seclist.sort((a, b)  =>
      (a.label).localeCompare((b.label), navigator.languages[0] || navigator.language, {numeric: true, ignorePunctuation: true}));
    }

  }

// }).sort((a, b) => a.localeCompare(b, navigator.languages[0] || navigator.language, {numeric: true, ignorePunctuation: true}))



  async changeSector(sector) {
    const action = { type: 'GET', target: 'zones/zone_list' };
    const payload = { 'sectorId': sector };
    const result = await this.apiService.apiFn(action, payload);
    this.zonelist = result['data'].map(function (obj) {
      const rObj = {};
      rObj['label'] = obj.room;
      rObj['value'] = obj._id;
      return rObj;
    });
  }

  cancel() {
    this.router.navigate(['./zones']);
  }

  async unassignBeacon(beacon) {
    //  this.loader = true;

    this.deletedbeacon.push(beacon._id);
    this.beacons.push(beacon);
    for (let i = 0; i < this.beaconlist.length; i++) {
      if (this.beaconlist[i]._id === beacon._id) {
        this.beaconlist.splice(i, 1);
      }
    }
    this.toastr.success('Beacon unassigned successfully');

  }

  async unassignResident(resident) {
    // this.loader = true;
    this.deletedresident.push(resident._id);
    this.residents.push(resident);
    for (let i = 0; i < this.residentlist.length; i++) {
      if (this.residentlist[i]._id === resident._id) {
        this.residentlist.splice(i, 1);
      }
    }
    if (this.toastr.currentlyActive === 0) {
      this.toastr.success('Resident unassigned successfully');
    }
  }

  async assignBeacon(beacon) {
   
    // this.loader = true;
    this.beacon = '';
    if (beacon) {
     
      this.beaconlist.push(beacon);
      
      for (let i = 0; i < this.beacons.length; i++) {
        if (this.beacons[i]._id === beacon._id) {
          this.beacons.splice(i, 1);
        }
      }
      if (this.toastr.currentlyActive === 0) {
        this.toastr.success('Beacon assigned successfully');
      }
    } else {
      if (this.toastr.currentlyActive === 0) {
        this.toastr.error('Please select beacon');
      }
    }
  }

  async assignResident(resident) {
    // this.loader = true;
    if (resident) {
      this.resident = '';
      this.residentlist.push(resident);
      for (let i = 0; i < this.residents.length; i++) {
        if (this.residents[i]._id === resident._id) {
          this.residents.splice(i, 1);
        }
      }
      if (this.toastr.currentlyActive === 0) {
        this.toastr.success('Resident assigned successfully');
      }
    } else {
      if (this.toastr.currentlyActive === 0) {
        this.toastr.error('Please select resident');
      }
    }
  }

  async loadBeacons() {
    const id = this.route.params['_value']['id'];
    const action = { type: 'POST', target: 'zones/view' };
    const payload = { zoneId: id };
    const result = await this.apiService.apiFn(action, payload);
   
    this.beaconlist = result['data']['beacons'];
  }

  async loadResidents() {
    const id = this.route.params['_value']['id'];
    const action = { type: 'POST', target: 'zones/view' };
    const payload = { zoneId: id };
    const result = await this.apiService.apiFn(action, payload);
    this.residentlist = result['data']['residents'];
  }

  checkAlphanum(key) {
    const result = this.commonService.allwoAlphaAndNumAndSpace(key);
    return result;
  }

  async onSubmit(f, zone) {
    let valid = f.form.status;
    zone.room = zone.room.trim();
    if (zone.org === '' || zone.fac === '' || zone.floor === '' || zone.sector === '' || zone.room === '') {
      valid = 'INVALID';
    }

    if (valid === 'VALID') {
      const action = {
        type: 'POST',
        target: 'zones/add'
      };
      zone['beacons'] = this.beaconlist;
      zone['residents'] = this.residentlist;
      zone['deletedbeacon'] = this.deletedbeacon;
      zone['deletedresident'] = this.deletedresident;
      if (this.route.params['_value']['floor']) {
        zone['org'] = this.route.params['_value']['org'];
        zone['fac'] = this.route.params['_value']['fac'];
      }else{
        zone['org'] = this.organization;
        zone['fac'] = this.facility;
      }
      const payload = zone;
     
      const result = await this.apiService.apiFn(action, payload);
    
      if (result['status']) {
        this.toastr.success(result['message']);
        this.router.navigate(['/zones']);
      } else {
        if (this.toastr.currentlyActive === 0) {
          this.toastr.error(result['message']);
        }
      }
    } else {
      if (this.toastr.currentlyActive === 0) {
        this.toastr.error('Please enter zone details');
      }
    }
  }

  onChangeReady(event) {
    this.zone.ready_to_move = event.checked;
  }

}
