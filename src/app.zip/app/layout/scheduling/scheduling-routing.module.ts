import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormComponent } from './form/form.component';
import { CalendarComponent } from './calendar/calendar.component';
import { ScheduleComponent } from './schedule/schedule.component';
import { ListComponent } from './list/list.component';
import {MenuItem} from 'primeng/api';
import { RuleCareComponent } from './rule-care/rule-care.component';

const routes: Routes = [
  {
    path: '', // beacons
    // component: BeaconsComponent,
    data: {
      breadcrumb: 'Schedule'
    },
    children: [
      {
        path: '',
        data: {
          breadcrumb: null
        },
        component: ScheduleComponent
      },
      {
        path: 'create',
        data: {
          breadcrumb: 'Schedule Care'
        },
        component: FormComponent
      },
      {
        path: 'list',
        data: {
          breadcrumb: 'Care List'
        },
        component: ListComponent
      },
      {
        path: 'day_list/:timestamp',
        data: {
          breadcrumb: 'Day List'
        },
        component: ListComponent
      },{
        path: 'rulecare',
        data: {
          breadcrumb: 'Rule Care'
        },
        component: RuleCareComponent
      },
     

    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SchedulingRoutingModule { }



