import { Component, OnInit, TemplateRef, ViewChild, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from './../../../shared/services/common.service';
import { ApiService } from './../../../shared/services/api/api.service';
import { Subscription } from 'rxjs/Rx';
import { ToastrService } from 'ngx-toastr';
import * as moment from 'moment';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MatDialog, MatDialogConfig } from '@angular/material';
// import { RepeatCareComponent } from '../repeat-care-dialog/repeat-care.component';

@Component({
  selector: 'app-form',
  // directives: [RepeatCareComponent],
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {
  minDate: Date;
  minDateEnd: Date;
  subscription: Subscription;
  organization; facility;
  residentslist; carelistData; carelist; userslist;
  showerror = true;
  firstEdit = true;
  firstEditOption = false;
  showAddedcares  = false;
  seconddisable = true;
  secondEdit = false;
  secondEditOption = false;
  thirdEdit = false;
  thirddisable = true;
  afterpreview = false;
  thirdEditOption = false;

  dialogRefs = null;

  @ViewChild('callRepeatDialog') callRepeatDialog: TemplateRef<any>;

  repeatOptions: any = [
    { key: 'never' , value: 'Never' },
    { key: 'every_day' , value: 'Every Day' },
    { key: 'every_week' , value: 'Every Week' },
    { key: 'every_month' , value: 'Every Month' },
    { key: 'every_year' , value: 'Every Year' },
    // { key: "custom" , value: "Custom" },
  ];

  selectedResidentList = [];
  selectedResident: any = {
    resident_id: '',
    note: ''
  };

  selectedCareList = [];
  selectedCareTime = [];
  selectedCare: any = {
    care_id: '',
    note: '',
    user_id: ''
  };
  timeArray = [];
  schedularFormGroup: FormGroup;
  scheduleDuration = {
    startDate: new Date(),
    endDate: null,
  };

  scheduleRepeat = {
    index: null,
    startDate: new Date(),
    endDate: null,
    repeat_tenure: 1,
    repeat: 'every_day',
    repeat_old: null,
    repeat_on: {
      monday : true,
      tuesday : true,
      wednesday : true,
      thursday : true,
      friday : true,
      saturday : true,
      sunday : true
    },
    repeat_option: 'on_day'
  };

  constructor(
    private _formBuilder: FormBuilder,
    private _commonService: CommonService,
    private _router: Router,
    private apiService: ApiService,
    private toastr: ToastrService,
    private dialog: MatDialog
  ) {
    this.minDate = new Date();
    this.minDateEnd = new Date();
  }

  arrayNumber(n: number): number[] {
    const arrayD = Array(n).fill(n, 0, n).map((x, i) => i + 1 );
    return arrayD;
  }

  ngOnInit() {
    this.subscription = this._commonService.contentdata.subscribe((contentVal: any) => {
      this._commonService.setLoader(true);
      if (contentVal.org && contentVal.fac) {
        this.organization = contentVal.org;
        this.facility = contentVal.fac;
        this.getAllresidents();
        this.getAllusers();
        this.getAllcares();
        this._commonService.setLoader(false);
      }
    });

    this.schedularFormGroup = this._formBuilder.group({
      residentList: this._formBuilder.array([])
    });

  }

  startDateChangeEvent(type: string, event: MatDatepickerInputEvent<Date>) {
    this.scheduleRepeat.startDate = event.value;
    this.minDateEnd = event.value;
  }

  endDateChangeEvent(type: string, event: MatDatepickerInputEvent<Date>) {
    this.scheduleRepeat.endDate = event.value;
  }

  async getAllresidents() {
    const action = {
      type: 'GET',
      target: 'residents/get_res_org'
    };
    const payload = {
      'organization': [this.organization],
      'facility': [this.facility]
    };
    const result = await this.apiService.apiFn(action, payload);
    if (result['success'] && result['data']) {
      this.residentslist = [];
      await result['data'].map((obj , index ) => {
        if (obj.room) {
          const robj = {};
          robj['name'] = obj['first_name'] + ' ' + (obj['last_name']).substr(0, 1) + '. ' + ((obj['room']) ? obj['room']['room'] : '');
          robj['value'] = obj._id;
          this.residentslist.push(robj);
        }
      });
      this.residentslist.sort(function (a, b) {
        const nameA = a.name.toUpperCase(), nameB = b.name.toUpperCase();
        if (nameA < nameB) {  return -1; }
        if (nameA > nameB) { return 1; }
        return 0; // default return value (no sorting)
      });
    }

  }

  async getAllusers() {
    const action = {
      type: 'GET',
      target: 'users/get_users_org_fac'
    };
    const payload = {
      'organization': [this.organization],
      'facility': [this.facility]
    };
    const result = await this.apiService.apiFn(action, payload);
    console.log('resultresultresultresult ---> ', result);
    this.userslist = await result['data'].map(function (obj) {
      const robj = {};
      robj['value'] = obj['last_name'] + ', ' + obj['first_name'];
      robj['key'] = obj._id;
      return robj;
    });
    this.userslist.sort(function (a, b) {
      const nameA = a.value.toUpperCase(), nameB = b.value.toUpperCase();
      if (nameA < nameB) {  return -1; }
      if (nameA > nameB) { return 1; }
      return 0; // default return value (no sorting)
    });
  }

  async getAllcares() {
    const action = {
      type: 'GET',
      target: 'cares/getCares'
    };
    const payload = {};
    const result = await this.apiService.apiFn(action, payload);
    this.carelistData = result['data'];
    this.carelist = await result['data'].map(function (obj) {
      const robj = {};
      robj['value'] = obj['name'];
      robj['key'] = obj._id;
      return robj;
    });

  }

  goSchedular() {
    this._router.navigate(['/scheduling']);
  }

  goForward(type) {
    if (type === 'resident') {
      this.firstEdit = true;
      this.firstEditOption = this.secondEdit = false;
      this.thirdEdit = false;
    }

    if (type === 'care' && this.selectedResidentList.length) {
      this.firstEditOption = this.secondEdit = true;
      this.firstEdit = this.seconddisable = false;
      this.showAddedcares = false;
      this.thirdEdit = false;
    }

    if (type === 'duration' && this.selectedCareList.length) {
      this.selectedCareList.map((item, i) => {
        if (!this.selectedCareList[i].time) {
          this.selectedCareList[i].time = [];
        }
        if (!this.selectedCareList[i].repeat) {
          this.selectedCareList[i].repeat = '';
        }
      });
      this.secondEditOption = true;
      this.afterpreview = false;
      this.secondEdit = false;
      this.showAddedcares = true;
      this.thirddisable = false;
      this.thirdEdit = true;
    }

    if (type === 'done') {
      let checkForm = 'VALID';
      this.selectedCareList.map(item => {
        if (item.repeat === '') {
          checkForm = 'REPEAT';
          return checkForm;
        }
        if (item.time.length) {
          item.time.map( (time: any) => {
              if (time.startTime === '' || time.endTime === '' ) {
              checkForm = 'SETIME';
              return checkForm;
            }
            if ( moment(time.startTime).unix() > moment(time.endTime).unix()) {
              checkForm = 'SEGTIME';
              return checkForm;
            }
          });
        } else {
          checkForm = 'NOTIME';
        }
      });
      if (checkForm === 'VALID') {
        this.afterpreview = true;
        this.thirdEditOption = true;
        this.firstEdit = false;
        this.firstEditOption = this.secondEdit = false;
        this.thirdEdit = false;
      } else {
        if (checkForm === 'SEGTIME') {
          this.toastr.error('Start time cannot be less than end time.');
        } else if (checkForm === 'NOTIME') {
          this.toastr.error('Please select time for care.');
        } else {
          this.toastr.error('Please fill all fields');
        }
      }

    }

  }

  async deleteAssignedResident(residentID) {
    for (let i = 0; i < this.selectedResidentList.length; i++) {
      if (this.selectedResidentList[i].resident.value === residentID ) {
        this.residentslist.push(this.selectedResidentList[i].resident);
        this.selectedResidentList.splice(i, 1);
      }
    }
    this.toastr.success('Resident removed successfully');
  }

  async editAssignedResident(residentID) {
    for (let i = 0; i < this.selectedResidentList.length; i++) {
      if (this.selectedResidentList[i].resident.value === residentID ) {
        this.residentslist.push(this.selectedResidentList[i].resident);
        this.selectedResident = {
          resident_id: this.selectedResidentList[i].resident.value,
          note: this.selectedResidentList[i].note
        };
        this.selectedResidentList.splice(i, 1);
      }
    }
  }

  async assignResident(selectedResident) {
    if (selectedResident.resident_id) {
      this.showerror = false;
      this.selectedResident = {
        resident_id: '',
        note: ''
      };
      for (let i = 0; i < this.residentslist.length; i++) {
        if (this.residentslist[i].value === selectedResident.resident_id) {
          this.selectedResidentList.push({
            resident: this.residentslist[i],
            note: selectedResident.note
          });
          this.residentslist.splice(i, 1);
        }
      }
      if (this.toastr.currentlyActive === 0) {
        this.toastr.success('Resident added successfully');
      }
    } else {
      this.showerror = true;
      // if (this.toastr.currentlyActive === 0)
      //   this.toastr.error("Please select resident")
    }
  }

  async deleteAssignedCare(careID) {
    for (let i = 0; i < this.selectedCareList.length; i++) {
      if (this.selectedCareList[i].care.key === careID ) {
        this.carelist.push(this.selectedCareList[i].care);
        this.selectedCareList.splice(i, 1);
      }
    }
    this.toastr.success('Care removed successfully');
  }

  async editAssignedCare(careID) {
    for (let i = 0; i < this.selectedCareList.length; i++) {
      if (this.selectedCareList[i].care.key === careID ) {
        this.carelist.push(this.selectedCareList[i].care);
        this.selectedCare = {
          care_id: this.selectedCareList[i].care.key,
          note: this.selectedCareList[i].note,
          user_id: this.selectedCareList[i].user_id,
          timePopup: false
        };
        this.selectedCareList.splice(i, 1);
      }
    }
  }

  async assignCare(selectedCare) {
    if (selectedCare.care_id) {
      this.showerror = false;
      this.selectedCare = {
        care_id: '',
        note: '',
        user_id: ''
      };
      for (let i = 0; i < this.carelist.length; i++) {
        if (this.carelist[i].key === selectedCare.care_id) {
          this.selectedCareList.push({
            care: this.carelist[i],
            note: selectedCare.note,
            user_id: selectedCare.user_id,
            repeat: 'never',
            repeat_old: 'never',
            timePopup: false
          });
          this.carelist.splice(i, 1);
        }
      }
      if (this.toastr.currentlyActive === 0) {
        this.toastr.success('Care added successfully');
      }
    } else {
      this.showerror = true;
      // if (this.toastr.currentlyActive === 0)
      //   this.toastr.error("Please select care")
    }
  }

  onAddTimePopup(care_key, ci ) {
    const that = this;
    this.selectedCareList.map(function(value, i) {
      if (ci === i) {
        const careVal = that.carelistData.filter(function (entry) { return entry._id === care_key; })[0];
        const timestartDisp = moment({ hour: 9 }).toDate(); // moment({ hour: 9 });
        const timeendDisp = moment({ hour: 9 }).add((careVal.max) ? careVal.max : 30, 'minutes').toDate();
        that.selectedCareTime[ci] = that.selectedCareList[ci].time;
        if (!that.selectedCareTime[ci].length) {
          that.selectedCareTime[ci] = [{ startTime: timestartDisp, endTime: timeendDisp }];
        }
        that.selectedCareList[ci]['timePopup'] = !that.selectedCareList[ci]['timePopup'];
      } else {
        that.selectedCareList[i]['timePopup'] = false;
      }
    });
  }

  onAddTime(care_key, ci ) {
    const careVal = this.carelistData.filter(function (entry) { return entry._id === care_key; })[0];
    const timestartDisp = moment({ hour: 9 }).toDate(); // moment({ hour: 9 });
    const timeendDisp = moment({ hour: 9 }).add((careVal.max) ? careVal.max : 30, 'minutes').toDate();
    this.selectedCareTime[ci].push({startTime: timestartDisp, endTime: timeendDisp });
  }

  onRemoveTime(care_key, i , ci) {
    // this.selectedCareList[ci].time.splice(i, 1);
    this.selectedCareTime[ci].splice(i, 1);
  }

  onRemoveListTime(ci, i) {
    this.selectedCareList[ci].time.splice(i, 1);
  }

  onSaveAddTime(care_key, ci ) {
    this.selectedCareList[ci].time = this.selectedCareTime[ci];
    this.selectedCareList[ci]['timePopup'] = false;
  }

  repeatChanged(ci) {
    if (this.selectedCareList[ci].repeat !== 'never') {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.maxWidth = '500px';
      dialogConfig.panelClass = 'repeatDialog';
      dialogConfig.disableClose = true;
      this.dialogRefs = this.dialog.open(this.callRepeatDialog, dialogConfig);
      const selectedCareList =  this.selectedCareList[ci];
      this.scheduleRepeat.repeat = selectedCareList.repeat;
      this.scheduleRepeat.index = ci;
      // if (this.scheduleRepeat.repeat_old == null) {
      // }
      // repeat_old
      // this.scheduleRepeat.repeat_old = ci;
      const repeatDays = { monday : true, tuesday : true, wednesday : true, thursday : true, friday : true, saturday : true, sunday : true};
      this.scheduleRepeat.repeat_tenure = selectedCareList.repeat_tenure ? selectedCareList.repeat_tenure : 1;
      if (this.selectedCareList[ci].repeat === 'every_day') {
        this.scheduleRepeat.repeat_on = repeatDays;
      } else {
        this.scheduleRepeat.repeat_on = selectedCareList.repeat_on ? selectedCareList.repeat_on : repeatDays;
      }
      this.scheduleRepeat.repeat_option = selectedCareList.repeat_option ? selectedCareList.repeat_option : 'on_day';
    }
  }

  closeRepeatDialog(): void {
    this.dialogRefs.close();
    this.selectedCareList[this.scheduleRepeat.index].repeat = this.selectedCareList[this.scheduleRepeat.index].repeat_old;
    this.scheduleRepeat = {
      index: null,
      startDate: this.scheduleDuration.startDate,
      endDate: this.scheduleDuration.endDate,
      repeat_tenure: 1,
      repeat: 'every_day',
      repeat_old: null,
      repeat_on: {
        monday : true,
        tuesday : true,
        wednesday : true,
        thursday : true,
        friday : true,
        saturday : true,
        sunday : true
      },
      repeat_option: 'on_day'
    };
  }

  saveRepeatDialog(): void {
    this.dialogRefs.close();
    this.selectedCareList[this.scheduleRepeat.index].startDate = this.scheduleRepeat.startDate;
    this.selectedCareList[this.scheduleRepeat.index].endDate = this.scheduleRepeat.endDate;
    this.selectedCareList[this.scheduleRepeat.index].repeat_tenure = this.scheduleRepeat.repeat_tenure;
    this.selectedCareList[this.scheduleRepeat.index].repeat = this.scheduleRepeat.repeat;
    this.selectedCareList[this.scheduleRepeat.index].repeat_old = this.scheduleRepeat.repeat;
    this.selectedCareList[this.scheduleRepeat.index].repeat_on = this.scheduleRepeat.repeat_on;
    this.selectedCareList[this.scheduleRepeat.index].repeat_option = this.scheduleRepeat.repeat_option;
  }

  radioRepeatChange(event): void {
    this.scheduleRepeat.repeat_option = event.value;
  }

  getRepeatValue( repeat_val ) {
    const repeatVal = this.repeatOptions.filter(function (entry) { return entry.key === repeat_val; })[0];
    return repeatVal.value;
  }

  weekDayChanged(e) {
    let checkData = true;
    for (const [key, value] of Object.entries(this.scheduleRepeat.repeat_on)) {
      if (!value) {
        checkData = false;
        break;
      }
    }
    if (!checkData) {
      this.scheduleRepeat.repeat = 'every_week';
    } else {
      this.scheduleRepeat.repeat = 'every_day';
    }
  }

  weekDayTextInForm(data) {
    const checkData = [];
    for (const [key, value] of Object.entries(data)) {
      if (value) {
        checkData.push((key.charAt(0).toUpperCase() + key.slice(1)));
      }
    }
    return (checkData).toString().replace(/,/g, ', ');
  }

  weekDayText(e) {
    const checkData = [];
    for (const [key, value] of Object.entries(this.scheduleRepeat.repeat_on)) {
      if (value) {
        checkData.push((key.charAt(0).toUpperCase() + key.slice(1)));
      }
    }
    return (checkData).toString().replace(/,/g, ', ');
  }

  repeatPopChanged(ad) {
    if (this.scheduleRepeat.repeat === 'every_day') {
      this.scheduleRepeat.repeat_on = {
        monday : true,
        tuesday : true,
        wednesday : true,
        thursday : true,
        friday : true,
        saturday : true,
        sunday : true
      };
    }
  }

  async done() {
    this._commonService.setLoader(true);
    const careData = [];
    this.selectedResidentList.map(resident => {
     this.selectedCareList.map(item => {
          item.time.map(timedata => {
            const timediff = (moment(timedata.endTime).valueOf() - moment(timedata.startTime).valueOf()) / 1000;

            const startH = moment(timedata.startTime).format('HH');
            const startM = moment(timedata.startTime).format('mm');
            const startDate = moment(this.scheduleDuration.startDate);
            startDate.set({ hour: parseInt(startH), minute: parseInt(startM), second: 0, millisecond: 0 });
            const startdate = startDate.utc().valueOf();
            let enddate = null;
            if  (this.scheduleDuration.endDate) {
              this.scheduleDuration['ts_endDate'] = moment(this.scheduleDuration.endDate).utc().valueOf();
              const endDate = moment(this.scheduleDuration.endDate);
              endDate.set({ hour: 23, minute: 59, second: 59, millisecond: 999 });
              enddate = endDate.utc().valueOf();
            }
            if (item.repeat === 'never') {
              enddate = moment(this.scheduleDuration.startDate).add(1, 'day').valueOf();
            }
            console.log('itemitemitemitem', item);
            const carepart = {
              org_id: this.organization,
              fac_id: this.facility,
              resident_id : resident.resident.value,
              resident_note : resident.note,
              care_id : item.care.key,
              care_note: item.note,
              assigned_to: (item.user_id) ? item.user_id.key : null,
              start_date: startdate,
              end_date: enddate,
              repeat: item.repeat,
              repeat_on: item.repeat_on,
              repeat_tenure: item.repeat_tenure,
              repeat_option: item.repeat_option,
              duration: timediff
            };
            careData.push(carepart);
          });
      });
    });

    const action = {
      type: 'POST',
      target: 'schedule/add'
    };
    const payload = careData;
    let result = await this.apiService.apiFn(action, payload);
    if (result['status']) {
      this.toastr.success('Schedule care added successfully!');
      this._router.navigate(['/scheduling']);
    } else {
      this._commonService.setLoader(false);
      this.toastr.error('Unable to save Schedule care. Please check again!');
    }
  }

}
