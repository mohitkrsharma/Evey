import { Component, OnInit } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { TemplateRef, ViewChild } from '@angular/core';
import { CommonService } from './../../../shared/services/common.service';
import { ApiService } from './../../../shared/services/api/api.service';
import { Subscription } from 'rxjs';
import { Router, ActivatedRoute} from '@angular/router';
import * as moment from 'moment';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { startOfMonth, startOfDay, startOfWeek, addWeeks, endOfDay, subDays, addDays, endOfMonth, endOfWeek, isSameDay,
  isSameMonth, addHours, addMinutes, addSeconds, format } from 'date-fns';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {
  subscription: Subscription;
  scheduleDate = null;
  assigne = false;
  organization; facility; events;
  userslist;
  minDate = null;
  step = 0;
  rulesData = [];
  unassignedData = [];
  assignedData = [];
  dialogRefs = null;
  transferCare = null;
  assignedTo = null;

  @ViewChild('confirmDialog') confirmDialog: TemplateRef<any>;

  constructor(
    private _activeRoute: ActivatedRoute,
    private _router: Router,
    private _apiService: ApiService,
    private _dialog: MatDialog,
    private _commonService: CommonService,
    private _toastr: ToastrService
  ) {
      this.minDate = new Date();
    }

  async ngOnInit() {
    this._commonService.setLoader(true);
    // console.log(this._activeRoute.params['_value']['timestamp']);
    this._activeRoute.params.subscribe(async routeParams => {
      // console.log('routeParamsrouteParamsrouteParams', routeParams);
      // this.loadUserDetail(routeParams.id);
      if (routeParams['timestamp']) {
        this.scheduleDate = routeParams['timestamp'];
        if ( (this.scheduleDate.match(/^\d{13}$/) || this.scheduleDate.match(/^\d{14}$/)) &&
         moment(this.scheduleDate, 'x', true).isValid() ) {
          // tslint:disable-next-line: radix
          this.scheduleDate = parseInt(routeParams['timestamp']);
          this.subscription = this._commonService.contentdata.subscribe(async (contentVal: any) => {
            if (contentVal.org && contentVal.fac) {
              this.organization = contentVal.org;
              this.facility = contentVal.fac;
              // this.getAllresidents();
              await this.getAllusers();
              await this.fetchEvents();
            }
          });
        } else {
          this._router.navigate(['/scheduling']);
        }
      } else {
        this._router.navigate(['/scheduling']);
      }
    });
  }

  setStep(index: number) {
    this.step = index;
  }

  dateChangeEvent(event: MatDatepickerInputEvent<Date>) {
    const startDate = moment(event.value).startOf('day').valueOf();
    this._router.navigate(['/scheduling/day_list', startDate]);
  }

  async fetchEvents() {
    this.events = [];
    const startDate = moment(this.scheduleDate).startOf('day').valueOf();
    const endDate = moment(this.scheduleDate).endOf('day').valueOf();

    const payload = {
      start_time: moment(startDate).utc().valueOf(),
      end_time: moment(endDate).utc().valueOf(),
      org_id: this.organization,
      fac_id: this.facility
    };
    const action = {
      type: 'GET',
      target: 'schedule/get_daylist'
    };
    const result = await this._apiService.apiFn(action, payload);
    if (result['success'] && result['data']) {

      this.rulesData = [];
      this.unassignedData = [];
      this.assignedData = [];

      if ( result['data']['rules'] &&  result['data']['rules'].length ) {
        result['data']['rules'].map((ruledata) => {
          if ( ruledata.scheduleCares && ruledata.scheduleCares.length ) {
            const scheduleCare = [];
            ruledata.scheduleCares.map((eventSchedules) => {
              if ( this.checkEventSched(payload, eventSchedules) ) {
                scheduleCare.push(eventSchedules);
              }
            });
            if (scheduleCare.length) {
              ruledata.scheduleCares = scheduleCare;
              this.rulesData.push(ruledata);
            }
          }
        });
      }
      if ( result['data']['unassigned'] &&  result['data']['unassigned'].length ) {
        result['data']['unassigned'].map((eventSchedules) => {
            if ( this.checkEventSched(payload, eventSchedules) ) {
              this.unassignedData.push(eventSchedules);
            }
        });
      }

      if ( result['data']['assigned'] &&  result['data']['assigned'].length ) {
        result['data']['assigned'].map((assigndata) => {
          if ( assigndata.scheduleCares && assigndata.scheduleCares.length ) {
            const scheduleCare = [];
            assigndata.scheduleCares.map((eventSchedules) => {
              if ( this.checkEventSched(payload, eventSchedules) ) {
                scheduleCare.push(eventSchedules);
              }
            });
            if (scheduleCare.length) {
              assigndata.scheduleCares = scheduleCare;
              this.assignedData.push(assigndata);
            }
          }
        });
      }

      console.log('assignedDataassignedDataassignedDataassignedDataassignedData', this.assignedData);
      console.log('ruledataruledataruledataruledataruledataruledataruledataruledata', this.rulesData);
      console.log('unassignedDataunassignedDataunassignedDataunassignedDataunassignedData', this.unassignedData);
    }
    this._commonService.setLoader(false);
  }

  checkEventSched(payload, data) {

    const startTime = payload.start_time;
    const endTime = endOfDay(startTime).valueOf();

    const startEvnt = startOfDay(data.start_date).valueOf();
    // tslint:disable-next-line: radix
    const hourEvnt = parseInt( moment(data.start_date).format('HH') );
    // tslint:disable-next-line: radix
    const minuteEvnt = parseInt( moment(data.start_date).format('mm') );
    // tslint:disable-next-line: radix
    const endEvnt =   addSeconds( addMinutes( addHours(startEvnt, hourEvnt), minuteEvnt), data.duration).valueOf();

    switch (data.repeat) {
      case 'never':
        if (startEvnt === startTime && (!data.end_date || (data.end_date && endEvnt < endTime)) ) {
          return true;
        }
        break;
      case 'every_week':
        if (startEvnt <= startTime && (!data.end_date ||  (data.end_date && data.end_date > startTime))) {
          const weekDay = moment(startTime).format('dddd').toLocaleLowerCase();
          const eventInWeek = moment(startEvnt).week();
          const dateInWeek = moment(startTime).week();
          if ( (( dateInWeek - eventInWeek) % data.repeat_tenure ) === 0 && data.repeat_on[weekDay] ) {
            return true;
          }
        }
        break;
      case 'every_month':
        const eventInMonth = moment(startEvnt).month();
        const dateInMonth = moment(startTime).month();
        if ( (( dateInMonth - eventInMonth) % data.repeat_tenure ) === 0 && startEvnt < payload.end_time &&
            ( !endEvnt || (endEvnt && endEvnt < payload.end_time)) ) {
          let taskNDate =  moment().valueOf();
          switch (data.repeat_option) {
            case 'on_day':
              const eventDay = moment(startEvnt).format('D');
              const eventMonth = moment(startTime).format('M');
              const eventYear = moment(startTime).format('YYYY');
              taskNDate = moment( eventMonth + '-' + eventDay + '-' + eventYear , 'MM-DD-YYYY').valueOf();
              break;
            case 'on_week_number':
              const weekNDay = moment(startEvnt).format('dddd').toLocaleLowerCase();
              const weekNNo = Math.ceil(moment(startEvnt).date() / 7 );
              taskNDate = this.onSpecificweekOFMonthly(startTime, weekNDay , weekNNo);
              break;
            case 'on_last_week':
              const weekWDay = moment(startEvnt).format('dddd').toLocaleLowerCase();
              const lastDayMonth = moment(startTime).endOf('month').startOf('day').valueOf();
              const startWeeklastMonth = moment(startTime).endOf('month').startOf('day').subtract(6, 'day').valueOf();
              taskNDate =  this.getLastOFMonthly(startWeeklastMonth, lastDayMonth, weekWDay);
              break;
          }
          if (taskNDate && taskNDate >= startTime && taskNDate < endTime &&
             (!data.end_date ||  (data.end_date && data.end_date > startTime))) {
            return true;
          }
        }
        break;
      case 'every_year':
        const eventEMonth = moment(startEvnt).format('M');
        const eventYMonth = moment(startTime).format('M');
        if ( eventYMonth === eventEMonth ) {
          const eventYDay = moment(startEvnt).format('D');
          const eventYYear = moment(startTime).format('Y');
          let taskNDate =  moment().valueOf();
          switch (data.repeat_option) {
            case 'on_day':
              // tslint:disable-next-line: radix
              const dateSet = {'year': parseInt(eventYYear), 'month': parseInt(eventYMonth) - 1 , 'date': parseInt(eventYDay) };
              taskNDate = moment().set( dateSet ).startOf('day').valueOf();
              break;
            case 'on_week_number':
              const weekNDay = moment(startEvnt).format('dddd').toLocaleLowerCase();
              const weekNNo = Math.ceil(moment(startEvnt).date() / 7 );
              taskNDate = this.onSpecificweekOFMonthly(startTime, weekNDay , weekNNo);
              break;
            case 'on_last_week':
              const weekWDay = moment(startEvnt).format('dddd').toLocaleLowerCase();
              const lastDayMonth = moment(startTime).endOf('month').startOf('day').valueOf();
              const startWeeklastMonth = moment(startTime).endOf('month').startOf('day').subtract(6, 'day').valueOf();
              taskNDate =  this.getLastOFMonthly(startWeeklastMonth, lastDayMonth, weekWDay);
              break;
          }
          if ( !endEvnt || (endEvnt && payload.end_time >= taskNDate && payload.start_time <= taskNDate)) {
            return true;
          }
        }
        break;
      case 'every_day':
      default:
        if (startEvnt <= startTime && (!data.end_date ||  (data.end_date && data.end_date > startTime))) {
          return true;
        }
        break;
    }
    return false;
  }

  getMonthlyWeekday(n, d: string, m: string, y: number) {
    let targetDay, curDay = 0, i = 1, seekDay;
    if (d === 'Sunday') { seekDay = 0; }
    if (d === 'monday') { seekDay = 1; }
    if (d === 'Tuesday') { seekDay = 2; }
    if (d === 'Wednesday') { seekDay = 3; }
    if (d === 'Thursday') { seekDay = 4; }
    if (d === 'Friday') { seekDay = 5; }
    if (d === 'Saturday') { seekDay = 6; }
    while (curDay < n && i < 31) {
      targetDay = new Date(i++ + ' ' + m + ' ' + y );
      if (targetDay.getDay() === seekDay) { curDay++; }
    }
    if (curDay === n ) {
      targetDay = targetDay.getDate();
      return targetDay;
    } else {
      return false;
    }
  }

  onSpecificweekOFMonthly(startTime, weekWDay, weekNNo) {
    const startmonth = startOfMonth(startTime).valueOf();
    const endTime = addWeeks( startmonth , (weekNNo)).valueOf();
    startTime = moment(endTime).subtract(7, 'day').valueOf();
    while (startTime < endTime ) {
      const weekDay = moment(startTime).format('dddd').toLocaleLowerCase();
      if (weekDay === weekWDay ) {
        return startTime;
      }
      startTime = addDays(startTime, 1).valueOf();
    }
  }

  getLastOFMonthly(startTime, endTime, weekWDay) {
    while (startTime <= endTime ) {
      const weekDay = moment(startTime).format('dddd').toLocaleLowerCase();
      if (weekDay === weekWDay ) {
        return startTime;
      }
      startTime = addDays(startTime, 1).valueOf();
    }
  }

  ruleTaskCount() {
    let count = 0;
    this.rulesData.map((data) =>  count += data.scheduleCares.length );
    return count;
  }

  totalTaskCount() {
    const count = this.unassignedData.length + this.ruleTaskCount();
    return count;
  }

  performersCount() {
    let count = 0;
    this.assignedData.map(function(assignItem) {
      if (assignItem.scheduleCares && assignItem.scheduleCares.length) { count += 1; }
    });
    return count;
  }

  async getAllusers() {
    const action = {
      type: 'GET',
      target: 'users/get_users_org_fac'
    };
    const payload = { 'organization': [this.organization], 'facility': [this.facility] };
    const result = await this._apiService.apiFn(action, payload);
    if (result['success']) {
      this.userslist = await result['data'].map(function (obj) {
        const robj = {};
        robj['value'] = obj['last_name'] + ', ' + obj['first_name'];
        robj['key'] = obj._id;
        return robj;
      });
      this.userslist.sort(function (a, b) {
        const nameA = a.value.toUpperCase(), nameB = b.value.toUpperCase();
        if (nameA < nameB) { // sort string ascending
          return -1;
        }
        if (nameA > nameB) {
          return 1;
        }
        return 0; // default return value (no sorting)
      });
    }
  }

  drop(event: CdkDragDrop<string[]>) {
    console.log('33333  ', event);
    if ( (event.previousContainer.id === 'ruleSection' && event.container.id.includes('performer-') ) ||
      (event.previousContainer.id.includes('rule-') && event.container.id.includes('performer-') ) ||
      (event.previousContainer.id === 'unassignedSection' && event.container.id.includes('performer-') )
    ) {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.maxWidth = '400px';
      dialogConfig.disableClose = true;
      this.dialogRefs = this._dialog.open(this.confirmDialog, dialogConfig);
      this.transferCare = event.item.data;
      this.assignedTo = event.container.id.split('-').pop();
      console.log('HERE IN CONDITION');
      console.log( 'itemitemitemitemitem', event.item.data );

    }
    if ( event.container.id === 'unassignedSection' && event.previousContainer.id.includes('performer-') ) {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.maxWidth = '400px';
      dialogConfig.disableClose = true;
      // this.dialogRefs = this._dialog.open(this.confirmDialog, dialogConfig);
      // this.transferCare = event.item.data;
      // console.log('HERE IN CONDITION');
      // console.log( 'itemitemitemitemitem', event.item.data );

    }

  }

  onNoClick(): void {
    this.dialogRefs.close(['result']['status'] = false);
  }

  thisCare() {
    this.dialogRefs.close();
  }

  async allCares() {
    if ( this.transferCare && this.transferCare.care  ) {
      this._commonService.setLoader(true);
      const payload = {
        org_id: this.organization,
        fac_id: this.facility,
        schedule_id: [ this.transferCare.care._id ],
        assigned_to: this.assignedTo
      };
      const action = {
        type: 'POST',
        target: 'schedule/update_assignment'
      };
      const result = await this._apiService.apiFn(action, payload);
      if (result['status']) {
        this.fetchEvents();
      } else {
        this._toastr.error(result['message']);
        this._commonService.setLoader(false);
      }

    }
    this.dialogRefs.close();
  }

}
