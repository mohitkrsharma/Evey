import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from './../../../shared/services/common.service';
import { ApiService } from './../../../shared/services/api/api.service';
import {
  CalendarDayViewBeforeRenderEvent,
  CalendarEvent,
  CalendarMonthViewBeforeRenderEvent,
  CalendarWeekViewBeforeRenderEvent,
  CalendarEventTimesChangedEvent,
  CalendarView,
  CalendarEventAction
} from 'angular-calendar';
import { Subject , Subscription, Observable } from 'rxjs';
import { colors } from '../calendar-utils/colors';
import * as moment from 'moment';
import { ViewPeriod } from 'calendar-utils';
import {
  startOfMonth,
  startOfDay,
  startOfWeek,
  endOfDay,
  subDays,
  addDays,
  endOfMonth,
  endOfWeek,
  isSameDay,
  isSameMonth,
  addHours,
  addMinutes,
  addSeconds,
  addWeeks,
  format
} from 'date-fns';

interface Care {
  id: string;
  title: string;
  release_date: string;
  color: string;
  actions: any;
}

@Component({
  selector: 'app-list',
  // changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: 'schedule.component.html',
  styleUrls: ['./schedule.component.scss']
})

export class ScheduleComponent implements OnInit  {
  CalendarView = CalendarView;
  view = CalendarView.Month;
  showCreateList = true;
  viewPeriod: ViewPeriod;
  calendarEvents = [];
  externalEvents = [];
  viewDate = moment().toDate();
  organization; facility;
  subscription: Subscription;
  events: CalendarEvent[] = [];

  constructor(
    private _router: Router,
    private _commonService: CommonService,
    private _apiService: ApiService
  ) {

  }

  ngOnInit() {
    this.subscription = this._commonService.contentdata.subscribe((contentVal: any) => {
      this._commonService.setLoader(true);
      if (contentVal.org && contentVal.fac) {
        this.organization = contentVal.org;
        this.facility = contentVal.fac;
        this.fetchEvents();
        this._commonService.setLoader(false);
      }
    });
  }


  getMonthlyWeekday(n, d: string, m: string, y: number) {
    let targetDay, curDay = 0, i = 1, seekDay;
    if (d === 'Sunday') { seekDay = 0; }
    if (d === 'monday') { seekDay = 1; }
    if (d === 'Tuesday') { seekDay = 2; }
    if (d === 'Wednesday') { seekDay = 3; }
    if (d === 'Thursday') { seekDay = 4; }
    if (d === 'Friday') { seekDay = 5; }
    if (d === 'Saturday') { seekDay = 6; }
    while (curDay < n && i < 31) {
      targetDay = new Date(i++ + ' ' + m + ' ' + y );
      if (targetDay.getDay() === seekDay) { curDay++; }
    }
    if (curDay === n ) {
      targetDay = targetDay.getDate();
      return targetDay;
    } else {
      return false;
    }
  }

  getLastOFMonthly(startTime, endTime, weekWDay) {
    while (startTime <= endTime ) {
      const weekDay = moment(startTime).format('dddd').toLocaleLowerCase();
      if (weekDay === weekWDay ) {
        return startTime;
      }
      startTime = addDays(startTime, 1).valueOf();
    }
  }

  onSpecificweekOFMonthly(startTime, weekWDay, weekNNo) {
    const endTime = addWeeks( startTime , (weekNNo)).valueOf();
    startTime = moment(endTime).subtract(7, 'day').valueOf();
    while (startTime < endTime ) {
      const weekDay = moment(startTime).format('dddd').toLocaleLowerCase();
      if (weekDay === weekWDay ) {
        return startTime;
      }
      startTime = addDays(startTime, 1).valueOf();
    }
  }

  async fetchEvents() {
    this.events = [];
    const getStart: any = { month: startOfMonth, week: startOfWeek, day: startOfDay }[this.view];
    const getEnd: any = { month: endOfMonth, week: endOfWeek, day: endOfDay }[this.view];
    const startDate = getStart(this.viewDate);
    const endDate = getEnd(this.viewDate);
    const payload = {
      start_time: moment(startDate).utc().valueOf(),
      end_time: moment(endDate).utc().valueOf(),
      org_id: this.organization,
      fac_id: this.facility
    };
    const action = {
      type: 'GET',
      target: 'schedule/get'
    };
    const result = await this._apiService.apiFn(action, payload);
    if (result['success']) {
      this.events = [];
      let startTime = payload.start_time;
      // console.log('HEREREREREREERERERE', result['data']['result']);
      result['data'].map((data) => {
        startTime = payload.start_time;
        const startEvnt = startOfDay(data.start_date).valueOf();
        let endEvnt = null;
        if ( data.end_date ) {
          endEvnt = endOfDay(data.end_date).valueOf();
        }
        let checkEnd = true;

        switch (data.repeat) {
          case 'never':
            const hourEvnt = parseInt( moment(data.start_date).format('HH') );
            const minuteEvnt = parseInt( moment(data.start_date).format('mm') );
            endEvnt = addSeconds(addMinutes(addHours(startOfDay(data.start_date), hourEvnt), minuteEvnt ), data.duration);
            checkEnd = true;
            while (startTime < payload.end_time && checkEnd) {
              const endTime = addDays(startTime, 1).valueOf();
              if (startEvnt >= startTime && (endEvnt && endEvnt <= endTime) ) {
                this.addEventFu(startTime, data);
                checkEnd = false;
              }
              startTime = addDays(startTime, 1).valueOf();
            }
            break;
          case 'every_week':
            checkEnd = true;
            while (startTime < payload.end_time) {
              if (data.end_date && endEvnt < startTime) {
                checkEnd = false;
              }
              if (startEvnt <= startTime && checkEnd) {
                const weekDay = moment(startTime).format('dddd').toLocaleLowerCase();
                const eventInWeek = moment(startEvnt).week();
                const dateInWeek = moment(startTime).week();
                if ( (( dateInWeek - eventInWeek) % data.repeat_tenure ) === 0 && data.repeat_on[weekDay] ) {
                  this.addEventFu(startTime, data);
                }
              }
              startTime = addDays(startTime, 1).valueOf();
            }
            break;
          case 'every_month':
            const eventInMonth = moment(startEvnt).month();
            const dateInMonth = moment(startTime).month();
            checkEnd = true;
            if ( (( dateInMonth - eventInMonth) % data.repeat_tenure ) === 0 && startEvnt < payload.end_time  ) {

              let taskNDate =  moment().valueOf();
              let taskEndDate = addSeconds( taskNDate, data.duration).valueOf();
              switch (data.repeat_option) {
                case 'on_day':
                  const eventDay = moment(startEvnt).format('D');
                  const eventMonth = moment(startTime).format('M');
                  const eventYear = moment(startTime).format('YYYY');
                  taskNDate = moment( eventMonth + '-' + eventDay + '-' + eventYear , 'MM-DD-YYYY').valueOf();
                  // taskEndDate = addSeconds( taskNDate, data.duration).valueOf();
                  break;
                case 'on_week_number':
                  const weekNDay = moment(startEvnt).format('dddd').toLocaleLowerCase();
                  const weekNNo = Math.ceil(moment(startEvnt).date() / 7 );
                  taskNDate = this.onSpecificweekOFMonthly(startTime, weekNDay , weekNNo);
                  // taskEndDate = addSeconds( taskNDate, data.duration).valueOf();
                  break;
                case 'on_last_week':
                  const weekWDay = moment(startEvnt).format('dddd').toLocaleLowerCase();
                  const lastDayMonth = moment(startTime).endOf('month').startOf('day').valueOf();
                  const startWeeklastMonth = moment(startTime).endOf('month').startOf('day').subtract(6, 'day').valueOf();
                  taskNDate =  this.getLastOFMonthly(startWeeklastMonth, lastDayMonth, weekWDay);
                  break;
              }
              taskEndDate = addSeconds( taskNDate, data.duration).valueOf();
              if ( !endEvnt || (endEvnt && endEvnt >= taskNDate && endEvnt >= taskEndDate )) {
                this.addEventFu(taskNDate, data);
              }
            }
            break;
          case 'every_year':
            // console.log('every_year data', data);
            const eventEMonth = moment(startEvnt).format('M');
            const eventYMonth = moment(startTime).format('M');
            if ( eventYMonth === eventEMonth ) {
              const eventYDay = moment(startEvnt).format('D');
              const eventYYear = moment(startTime).format('Y');
              let taskNDate =  moment().valueOf();
              let taskEndDate =  addSeconds( taskNDate, data.duration).valueOf();
              switch (data.repeat_option) {
                case 'on_day':
                  const dateSet = {'year': parseInt(eventYYear), 'month':parseInt(eventYMonth) - 1 , 'date': parseInt(eventYDay) };
                  taskNDate = moment().set( dateSet ).startOf('day').valueOf();
                  break;
                case 'on_week_number':
                  const weekNDay = moment(startEvnt).format('dddd').toLocaleLowerCase();
                  const weekNNo = Math.ceil(moment(startEvnt).date() / 7 );
                  taskNDate = this.onSpecificweekOFMonthly(startTime, weekNDay , weekNNo);
                  break;
                case 'on_last_week':
                  const weekWDay = moment(startEvnt).format('dddd').toLocaleLowerCase();
                  const lastDayMonth = moment(startTime).endOf('month').startOf('day').valueOf();
                  const startWeeklastMonth = moment(startTime).endOf('month').startOf('day').subtract(6, 'day').valueOf();
                  taskNDate =  this.getLastOFMonthly(startWeeklastMonth, lastDayMonth, weekWDay);
                  break;
              }
              taskEndDate = addSeconds( taskNDate, data.duration).valueOf();
              if ( !endEvnt || (endEvnt && endEvnt >= taskNDate)) {
                this.addEventFu(taskNDate, data);
              }
            }
            break;
          case 'every_day':
          default:
            // console.log('datadatadatadatadatadata', data);
            checkEnd = true;
            while (startTime < payload.end_time) {
              if (data.end_date && endEvnt < startTime) {
                checkEnd = false;
              }
              if (startEvnt <= startTime && checkEnd) {
                this.addEventFu(startTime, data);
              }
              startTime = addDays(startTime, 1).valueOf();
            }
            break;
        }
      });
      // console.log('this.eventsthis.events', this.events);
    }
  }

  addEventFu(startTime, data) {
    const hourEvnt = parseInt( moment(data.start_date).format('HH') );
    const minuteEvnt = parseInt( moment(data.start_date).format('mm') );
    const evnt = {
      start: addMinutes(addHours(startOfDay(startTime), hourEvnt), minuteEvnt ),
      end: addSeconds(addMinutes(addHours(startOfDay(startTime), hourEvnt), minuteEvnt ), data.duration),
      title: data.careData.name,
      color: colors.red,
      draggable: true,
      meta: {
        assigned_to: data.assigned_to
      }
    };
    this.events.push(evnt);
  }

  handleEvent(action: string, event: CalendarEvent): void {
    // console.log(event, action);
    // this.modalData = { event, action };
    // this.modal.open(this.modalContent, { size: 'lg' });
  }

  dayClicked({ date, events }: { date: Date; events: CalendarEvent[] }): void {
    const startEvnt = startOfDay(date).valueOf();
    const startToday = startOfDay(moment().valueOf()).valueOf();
    if (startToday <= startEvnt) {
      this._router.navigate(['/scheduling/day_list', startEvnt]);
    }
  }

  schedule() {
    this._router.navigate(['/scheduling/create']);
  }

  updateCalendarEvents( viewRender:
      | CalendarMonthViewBeforeRenderEvent
      | CalendarWeekViewBeforeRenderEvent
      | CalendarDayViewBeforeRenderEvent
  ): void {
    // console.log('viewRenderviewRender', viewRender);
    this.viewPeriod = viewRender.period;
    this.calendarEvents = [];
    this.events = [];
    this.fetchEvents();
  }

  getAssignedCount(events) {
    let count = 0;
    events.map((data) => {
      if ( data.meta.assigned_to !== null ) {
        count++;
      }
    });
    return count;
  }

  getUnAssignedCount(events) {
    let count = 0;
    events.map((data) => {
      if ( data.meta.assigned_to === null ) {
        count++;
      }
    });
    return count;
  }
}
