import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from './../../../shared/services/common.service';
import { ApiService } from './../../../shared/services/api/api.service';
import {
  CalendarDayViewBeforeRenderEvent,
  CalendarEvent,
  CalendarMonthViewBeforeRenderEvent,
  CalendarWeekViewBeforeRenderEvent,
  CalendarEventTimesChangedEvent,
  CalendarView,
  CalendarEventAction
} from 'angular-calendar';
import { Subject , Subscription, Observable } from 'rxjs';
import { colors } from '../calendar-utils/colors';
import * as moment from 'moment';
import { ViewPeriod } from 'calendar-utils';
import {
  startOfMonth,
  startOfDay,
  startOfWeek,
  endOfDay,
  subDays,
  addDays,
  endOfMonth,
  endOfWeek,
  isSameDay,
  isSameMonth,
  addHours,
  addMinutes,
  addSeconds,
  format
} from 'date-fns';

interface Care {
  id: string;
  title: string;
  release_date: string;
  color: string;
  actions: any;
}

@Component({
  selector: 'app-list',
  // changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: 'calendar.component.html',
  styleUrls: ['./calendar.component.scss']
})

export class CalendarComponent implements OnInit  {
  CalendarView = CalendarView;
  view = CalendarView.Week;
  showCreateList = true;
  viewPeriod: ViewPeriod;
  calendarEvents = [];
  externalEvents = [];
  viewDate = moment().toDate();
  organization; facility;
  loader = false;
  subscription: Subscription;
  events: CalendarEvent[] = [];

  constructor(
    private router: Router,
    private _commonService: CommonService,
    private apiService: ApiService,
    private cdr: ChangeDetectorRef
  ) {

  }

  actions: CalendarEventAction[] = [
    {
      label: '<i class="fa fa-fw fa-pencil"></i>',
      a11yLabel: 'Edit',
      onClick: ({ event }: { event: CalendarEvent }): void => {
        this.handleEvent('Edited', event);
      }
    },
    {
      label: '<i class="fa fa-fw fa-times"></i>',
      onClick: ({ event }: { event: CalendarEvent }): void => {
        // this.events = this.events.filter(iEvent => iEvent !== event);
        this.handleEvent('Deleted', event);
      }
    }
  ];

  ngOnInit() {
    this.subscription = this._commonService.contentdata.subscribe((contentVal: any) => {
      this.loader = true;
      if (contentVal.org && contentVal.fac) {
        this.organization = contentVal.org;
        this.facility = contentVal.fac;
        this.fetchEvents();
        this.loader = false;
      }
    });
  }

  async fetchEvents() {
    const getStart: any = { month: startOfMonth, week: startOfWeek, day: startOfDay }[this.view];
    const getEnd: any = { month: endOfMonth, week: endOfWeek, day: endOfDay }[this.view];
    const startDate = getStart(this.viewDate);
    const endDate = getEnd(this.viewDate);
    const payload = {
      start_time: moment(startDate).utc().valueOf(),
      end_time: moment(endDate).utc().valueOf(),
      org_id: this.organization,
      fac_id: this.facility
    };
    const sss = moment(startDate);

    const action = {
      type: 'GET',
      target: 'schedule/get'
    };
    const result = await this.apiService.apiFn(action, payload);
    if (result['status']) {
      this.events = [];
      let startTime = payload.start_time;
      // while (startTime < payload.end_time) {
      //   // console.log('******', startTime , payload.end_time );
      //   startTime = addDays(startTime, 1).valueOf();
      // }

      result['data']['result'].map((data) => {
        startTime = payload.start_time;
        switch (data.repeat) {
          case 'never':
            // console.log('never data', data);
            // break;
          case 'every_two_days':
            // console.log('every_two_days data', data);
            // break;
          case 'every_week':
            // console.log('every_week data', data);
            // break;
          case 'every_two_weeks':
            // console.log('every_two_weeks data', data);
            // break;
          case 'every_month':
            // console.log('every_month data', data);
            // break;
          case 'every_year':
            // console.log('every_year data', data);
            // break;
          case 'every_day':
          default:
            const startEvnt = startOfDay(data.start_date).valueOf();
            const endEvnt = endOfDay(data.end_date).valueOf();
            const hourEvnt = parseInt( moment(data.start_date).format('HH') );
            const minuteEvnt = parseInt( moment(data.start_date).format('mm') );
            console.log('hourEvnthourEvnthourEvnt', data, hourEvnt , minuteEvnt);
            let checkEnd = true;
            while (startTime < payload.end_time) {
              console.log('data.start_date <= startTime', data._id,  data.start_date , startTime);

              if (data.end_date && endEvnt < startTime) {
                checkEnd = false;
              }
              if (startEvnt <= startTime && checkEnd) {
                const evnt = {
                  start: addMinutes(addHours(startOfDay(startTime), hourEvnt), minuteEvnt ),
                  end: addSeconds(addMinutes(addHours(startOfDay(startTime), hourEvnt), minuteEvnt ), data.duration),
                  title: data.careData.name,
                  color: colors.red,
                  actions: this.actions,
                  draggable: true,
                  meta: payload
                };
                this.events.push(evnt);
              }
              startTime = addDays(startTime, 1).valueOf();
            }
            break;
        }
      });
      console.log('this.eventsthis.events', this.events);
    }

  }

  handleEvent(action: string, event: CalendarEvent): void {
    console.log(event, action);
    // this.modalData = { event, action };
    // this.modal.open(this.modalContent, { size: 'lg' });
  }

  schedule() {
    this.router.navigate(['/scheduling/create']);
  }

  updateCalendarEvents( viewRender:
      | CalendarMonthViewBeforeRenderEvent
      | CalendarWeekViewBeforeRenderEvent
      | CalendarDayViewBeforeRenderEvent
  ): void {
    console.log('viewRenderviewRender', viewRender);
    this.viewPeriod = viewRender.period;
    this.calendarEvents = [];
    this.events = [];
    this.fetchEvents();
  }

  eventDropped({ event, newStart, newEnd, allDay }: CalendarEventTimesChangedEvent): void {
    // console.log('event,newStart,newEnd,allDay', event, newStart, newEnd, allDay);
    // const externalIndex = this.externalEvents.indexOf(event);
    // if (typeof allDay !== 'undefined') {
    //   event.allDay = allDay;
    // }
    // if (externalIndex > -1) {
    //   this.externalEvents.splice(externalIndex, 1);
    //   this.events.push(event);
    // }
    // // event.start = newStart;
    // // if (newEnd) {
    // //   event.end = newEnd;
    // // }
    // if (this.view === 'month') {
    //   this.viewDate = newStart;
    //   this.activeDayIsOpen = true;
    // }
    // this.events = [...this.events];
  }

  externalDrop(event: CalendarEvent) {
    // if (this.externalEvents.indexOf(event) === -1) {
    //   this.events = this.events.filter(iEvent => iEvent !== event);
    //   this.externalEvents.push(event);
    // }
  }
}
