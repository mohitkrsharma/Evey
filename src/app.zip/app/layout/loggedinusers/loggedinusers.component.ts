import { Component, OnInit, Input } from '@angular/core';
import { ApiService } from './../../shared/services/api/api.service';
import { SocketService } from '../../shared/services/socket/socket.service';
import { Subscription } from 'rxjs';
import { CommonService } from './../../shared/services/common.service';

@Component({
  selector: 'app-loggedinusers',
  templateUrl: './loggedinusers.component.html',
  styleUrls: ['./loggedinusers.component.scss']
})
export class LoggedinusersComponent implements OnInit {
  @Input() public myInputVariable: string;

  loggedinArr;
  _clientArr: any = [];
  user_id: any;
  organization; facility;
  private subscription: Subscription;

  constructor(
    private apiService: ApiService,
    private socketService: SocketService,
    public commonService: CommonService
  ) { }

  async ngOnInit() {
    this.subscription = this.commonService.contentdata.subscribe(async (contentVal: any) => {
      if (contentVal.org && contentVal.fac) {
        this.organization = contentVal.org;
        this.facility = contentVal.fac;
      }
    });

    const storeObj = await this.apiService.getauthData();
    this.user_id = storeObj['user_id'];
    this.getConnectedUserDetailFn();
    this.socketService.onLoginUpdateFn().subscribe(_response => {
      this.getConnectedUserDetailFn();
    });
  }

  async getConnectedUserDetailFn() {
    const action = { type: 'POST', target: 'reports/get_loggedin_user' };
    const payload = { fac_id: this.facility };
    const result = await this.apiService.apiFn(action, payload);
    this._clientArr = [];
    if (result['data'] && result['status']) {
      this._clientArr = result['data'];
      const output = [];
      this._clientArr.forEach(function (item) {
        const existing = output.filter(function (v, i) {
          return v.user_id === item.user_id;
        });
        if (existing.length) {
          const existingIndex = output.indexOf(existing[0]);
          output[existingIndex].platform = output[existingIndex].platform.concat(item.platform);
        } else {
          if (typeof item.platform === 'string') {
            item.platform = [item.platform];
          }
          output.push(item);
        }
      });

      this._clientArr = output;
    }
  }

}
