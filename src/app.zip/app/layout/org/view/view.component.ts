import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from './../../../shared/services/api/api.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})

export class ViewComponent implements OnInit {
  organization;
  constructor(private route: ActivatedRoute,
    private router: Router,
    private apiService: ApiService) { }

  loader = false;

  async ngOnInit() {
    this.loader = true;
    const id = this.route.params['_value']['id'];
    const action = { type: 'POST', target: 'organization/view' };
    const payload = { organizationId: id };
    const result = await this.apiService.apiFn(action, payload);
    this.organization = result['data'];
    this.loader = false;
  }

  editOrganization(id) {
    this.router.navigate(['/org/form', id]);
  }

  cancel() {
    this.router.navigate(['/org']);
  }

}
