import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ApiService } from './../../../shared/services/api/api.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../../../shared/services/common.service';
import { MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-build-restriction',
  templateUrl: './build_restriction.component.html',
  styleUrls: ['./build_restriction.component.scss']
})

export class BuildRestrictionComponent implements OnInit {
  buildForm: FormGroup;
  showBuildTable = false;
  constructor(
    private apiService: ApiService,
    private router: Router,
    private route: ActivatedRoute,
    private toastr: ToastrService,
    public commonService: CommonService) {

  }
  versionList;
  loader = false;
  _form = {
    app_id: '',
    version_id: ''
  };
  displayedColumns = ['app_id', 'version_id', 'action'];
  dataSource = new MatTableDataSource(this.versionList);

  async ngOnInit() {
    this.getBuildVersions();
  }

  async getBuildVersions() {
    this.loader = true;
    const action = { type: 'GET', target: 'build_restricted/get' };
    const payload = { };
    const result = await this.apiService.apiFn(action, payload);
    if (result['data'] && result['data']['build_versions']) {
      this.versionList = result['data']['build_versions'];
      this.dataSource = new MatTableDataSource(this.versionList);
      this.showBuildTable = true;
    }
    this.loader = false;
  }

  // function to accept only alpha numeric character
  checkAllwoNum(key) {
    const result = this.commonService.allwoNumDecimal(key);
    return result;
  }

  async addBuildVersion(form) {
    if (form.app_id === '' || form.app_id === undefined) {
      this.toastr.error('Please enter App Id');
    } else if (form.version_id === '' || form.version_id === undefined) {
      this.toastr.error('Please enter Version Id');
    } else {
      if (this.versionList === undefined || this.versionList.length < 1) {
        this.versionList = [
          {
            'app_id': form.app_id,
            'version_id': form.version_id
          }
        ];
        this._form = { app_id: '', version_id: '' };
        this.saveBuild();
      } else {
        if (this.versionList.some(item => item.app_id.trim() === form.app_id.trim() && item.version_id.trim() === form.version_id.trim())) {
          if (this.toastr.currentlyActive === 0) {
            this.toastr.error('Build version already added');
          }
        } else {
          this.versionList.push({
            'app_id': form.app_id,
            'version_id': form.version_id
          });
          this._form = { app_id: '', version_id: '' };
          this.saveBuild();
        }
      }
      this.dataSource = new MatTableDataSource(this.versionList);
      this.showBuildTable = true;
    }
  }

  async onRemoveBuildVersion(i) {
    this.versionList.splice(i, 1);
    if (this.versionList.length > 0) {
      this.showBuildTable = true;
      this.dataSource = new MatTableDataSource(this.versionList);
    } else if (this.versionList.length === 0) {
      this.showBuildTable = false;
    }
    this.saveBuild();
  }

  // Add/Edit NFC form
  async saveBuild() {
    this.loader = true;
    const action = {
      type: 'POST',
      target: 'build_restricted/add'
    };
    const result = await this.apiService.apiFn(action, this.versionList);
    if (result['status']) {
      this.toastr.success(result['message']);
      this._form = { app_id: '', version_id: '' };
      this.getBuildVersions();
      this.loader = false;
      this.router.navigate(['settings/build_restriction']);
    } else {
      if (this.toastr.currentlyActive === 0) {
        this.toastr.error(result['message']);
      }
      this.loader = false;
    }

  }

  // async onSubmit(f, form) {
  //   let valid = f.form.status;
  //   if (this.versionList === undefined || this.versionList.length < 1) {
  //     if (form.app_id === '' || form.version_id === '') {
  //       valid = 'INVALID';
  //     }
  //     if (valid === 'VALID') {
  //       this.versionList = [
  //         {
  //           'app_id': form.app_id,
  //           'version_id': form.version_id
  //         }
  //       ];
  //     } else {
  //       if (this.toastr.currentlyActive === 0) {
  //         this.toastr.error('Please enter app id and version id.');
  //       }
  //     }
  //   } else {
  //     valid = 'VALID';
  //   }
  //   if (valid === 'VALID') {
  //     const action = {
  //       type: 'POST',
  //       target: 'build_restricted/add'
  //     };
  //     const result = await this.apiService.apiFn(action, this.versionList);
  //     if (result['status']) {
  //       this.toastr.success(result['message']);
  //       this._form = { app_id: '', version_id: '' };
  //       this.getBuildVersions();
  //       this.router.navigate(['settings/build_restriction']);
  //     } else {
  //       if (this.toastr.currentlyActive === 0) {
  //         this.toastr.error(result['message']);
  //       }
  //     }
  //   }
  // }

}
