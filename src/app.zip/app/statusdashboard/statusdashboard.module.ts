import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StatusdashboardComponent } from './statusdashboard.component';
import { StatusdashboardRoutingModule } from './statusdashboard-routing.module';
import { MatTableModule, MatSortModule, MatSelectModule, MatFormFieldModule,    MatCardModule,
  MatProgressSpinnerModule,
  MatMenuModule,
  MatIconModule,
  MatToolbarModule, } from '@angular/material';
import { ChartsModule } from 'ng2-charts';
import { SafeHtmlPipe } from './../shared/pipes/safe-html.pipe';


import { TimerComponent } from './../layout/components/timerComponent/timer.component';
@NgModule({
  declarations: [
    StatusdashboardComponent,TimerComponent
  ],
  imports: [
    CommonModule,
    StatusdashboardRoutingModule,
    MatTableModule,
    MatSortModule, MatSelectModule, MatFormFieldModule,    MatCardModule,
    MatProgressSpinnerModule,
    MatMenuModule,
    MatIconModule,
    MatToolbarModule,
    ChartsModule,
    SafeHtmlPipe
  ]
})
export class StatusdashboardModule { }


