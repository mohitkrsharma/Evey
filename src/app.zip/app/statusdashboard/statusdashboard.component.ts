import { Component, OnInit, AfterViewInit } from '@angular/core';
import { ApiService } from './../shared/services/api/api.service';
import * as moment from 'moment';
import { Router, ActivatedRoute } from '@angular/router';
import { SocketService } from './../shared/services/socket/socket.service';
import { Aes256Service } from './../shared/services/aes-256/aes-256.service';
import * as _ from 'underscore';
import { Chart } from 'chart.js';
import $ from 'jquery';
import { MatTableDataSource } from '@angular/material';

export interface PeriodicElement {
  resident: string;
  room: number;
}

@Component({
  selector: 'app-statusdashboard',
  templateUrl: './statusdashboard.component.html',
  styleUrls: ['./statusdashboard.component.scss']
})
export class StatusdashboardComponent implements OnInit, AfterViewInit {

  displayedColumns: string[] = ['resident', 'room'];
  hashCode: any;
  linkData: any;
  level_one: any;
  level_two: any;
  level_three: any;
  vacation: any;
  hospitalized: any;
  skilled_nursing: any;
  hospice: any;
  outoffac: any;
  extendoutoffac: any;
  infac: any;
  ready; not_ready;
  doughnutChart: any;
  doughnutChart2: any;
  count;
  // Doughnut
  _date: any;
  _time: any;
  rooms: any;
  chartOptions = {
    maintainAspectRatio: false,
    cutoutPercentage: 75,
    elements: {
      arc: {
        borderWidth: 0
      }
    },
    tooltips: { enabled: false }
  };

  Color = [
    {
      backgroundColor: [
        '#28A5DE', '#1975B8'
      ]
    }
  ];
  Color2 = [
    {
      backgroundColor: [
        '#28A5DE', '#1975B8'
      ]
    }
  ];
  facility;
  announcements;
  newdata = false;
  isolated_residents: any;
  dataSource: MatTableDataSource<Element>;
  constructor(
    private apiService: ApiService,
    private router: Router,
    private route: ActivatedRoute,
    private socketService: SocketService,
    private aes256Service: Aes256Service
  ) { }

  ngOnInit() {
    let hashcode: any;
    this.hashCode = hashcode = this.route.params['_value']['id'];

    if (!this.hashCode) {
      this.router.navigate(['/']);
    }
    // hashCode = atob(hashCode);
    this.linkData = this.aes256Service.decFnWithsalt((hashcode).replace(/\*/g, '/'));

    if (!this.linkData.organization) {
      this.router.navigate(['/']);
    }


    // this.facility = this.route.params['_value']['fac'];
    this.getFacility();
    this.getAnnouncements();
    this.getLevelList();
    this.getStatusList();
    this.getHospiceList();
    this.getOutoffacList();
    this.getcensusdata();
    this.getopenroomsdata();
    this.getIsolatedResiList();

    setInterval(async () => { this.getDateTime(); }, 1000);

    this.socketService.getAnnouncementFn().subscribe((_response: any) => {
      if (_response) {
        if (_response.length > 1) {
          this.getAnnouncements();
        } else {
           // tslint:disable-next-line: max-line-length
           const index = _response[0].facility.findIndex(item => item.fac === this.linkData.facility && item.org === this.linkData.organization);

           if (index > -1) {
             const _ind = this.announcements.findIndex(item => item._id === _response[0]._id);
            // this.data[index]['outofFac'] = _response.is_out_of_fac;
            if (_ind >- 1) {
              this.announcements.splice(_ind, 1, _response[0]);
              this.announcements = this.announcements.filter(_item => _item.deleted === false && _item.isactive === true);
            } else {
              this.announcements.unshift(_response[0]);
            }
          }
        }
      }
    });

    this.socketService.addResidentFn().subscribe(_response => {
      this.newdata = true;
      if (_response) {
        this.getLevelList();
        this.getStatusList();
        this.getHospiceList();
        this.getOutoffacList();
        this.getcensusdata();
      }
    });

    this.socketService.updateResidentFn().subscribe(_response => {
      this.newdata = true;
      if (_response) {
        this.getLevelList();
        this.getStatusList();
        this.getHospiceList();
        this.getOutoffacList();
        this.getcensusdata();
      }
    });
    this.socketService.updateZoneFn().subscribe(_response => {
      if (_response) {
        this.getopenroomsdata();
      }
    });

    this.socketService.onResidentIsIsolationFn().subscribe(async (_response: any ) => {
      if (_response) {
        
       // console.log("socket isolation data",_response)
       
        const index = _response.facility.findIndex(item =>  item.fac===this.linkData.facility);
       // console.log("index>>",index)
        if(index>-1){
          
          const index1 = this.isolated_residents.findIndex(item =>  _response._ids.indexOf(item._id)>-1);
         // console.log("index 1>>",index1);
          if(index1>-1){
            
            let EndTime= _response.end_time_isolation;
            this.isolated_residents[index1]['isolation_end_date'] ="";
            this.isolated_residents[index1]['room'] =_response.room;
           setTimeout(()=>{
            this.isolated_residents[index1]['isolation_end_date'] =EndTime;
           },0)
            this.createTable(this.isolated_residents);
          }else{
            this.isolated_residents.push({_id:_response._ids[0],first_name:_response.first_name,last_name:_response.last_name,isolation_end_date:_response.end_time_isolation,room:_response.room})
            this.createTable(this.isolated_residents);
          }
          
        }
       
      }
    })

  }

  scrollerFunc(classTable) {

    const that = this;
    const scroller = function (obj) {
      const scCnt = $(obj).scrollTop() + 2;
      $(obj).animate({ scrollTop: scCnt }, 100, function() { });
      if ($(obj).scrollTop() + Math.ceil($(obj).innerHeight()) >= $(obj)[0].scrollHeight) {
        $(obj).animate({ scrollTop: 0 }, 800, function() {
        });
      }
      setTimeout(function () { scroller(obj); }, 1000);
    };
    setTimeout(function() {
      if (classTable === 'rmno.data-rooms') {
        const scrollHeight = $(document).find('.' + classTable).find('.scroller span').height();
        scroller($(document).find('.' + classTable));
      } else if (classTable === 'announcement-scroll') {
        const scrollHeight = $(document).find('.' + classTable).find('.scroller mat-card').height();
        scroller($(document).find('.' + classTable));
      } else {
        const scrollHeight = $(document).find('.' + classTable).find('.scroller tbody').height();
        scroller($(document).find('.' + classTable));
      }
    }, 1000);
  }

  ngAfterViewInit() {
    this.scrollerFunc('table-level-outfac');
    this.scrollerFunc('table-level-one');
    this.scrollerFunc('table-level-two');
    this.scrollerFunc('table-level-three');
    this.scrollerFunc('announcement-scroll');
  this.scrollerFunc('table-level-vacation');
  this.scrollerFunc('table-level-skilled_nursing');
  this.scrollerFunc('table-level-hospitalized');
   this.scrollerFunc('table-level-hospice');
   this.scrollerFunc('table-level-isolation');
  this.scrollerFunc('rmno.data-rooms')

   
  }

  async getDateTime() {
    this._date = moment().format('MMMM Do YYYY');
    this._time = moment().format('HH:mm');
  }

  async getFacility() {
    const id = this.route.params['_value']['fac'];
    const action = { type: 'POST', target: 'facility/getfac' };
    const payload = { facilityId: this.linkData.facility };
    const result = await this.apiService.apiFn(action, payload);
    this.facility = result['data']['fac_name'];
  }

  async getLevelList() {
    const action = {
      type: 'GET',
      target: 'residents/residents_level'
    };
    const payload = {
      'facility': this.linkData.facility
    };
    const result = await this.apiService.apiFn(action, payload);
    result['data'].map((item) => {
      if (item && item.level === 'Level 1') {
        this.level_one = item.data;
      }
      if (item && item.level === 'Level 2') {
        this.level_two = item.data;
      }
      if (item && item.level === 'Level 3') {
        this.level_three = item.data;
      }
    });
  
    //this.scrollerFunc();
   $(document).find('.table-level-one').scrollTop(0);
   $(document).find('.table-level-two').scrollTop(0);
   $(document).find('.table-level-three').scrollTop(0);
  }

  async getStatusList() {
    const action = {
      type: 'GET',
      target: 'residents/residents_status'
    };
    const payload = {
      'facility': this.linkData.facility
    };
    const result = await this.apiService.apiFn(action, payload);
    result['data'].map((item) => {
      if (item && item._id === 'Vacation') {
        this.vacation = item.data;
      }
      if (item && item._id === 'Hospitalized') {
        this.hospitalized = item.data;
      }
      if (item && item._id === 'Skilled Nursing') {
        this.skilled_nursing = item.data;
      }
    });
    $(document).find('.table-level-vacation').scrollTop(0);
    $(document).find('.table-level-skilled_nursing').scrollTop(0);
    $(document).find('.table-level-hospitalized').scrollTop(0);
  }

  async getHospiceList() {
    const action = {
      type: 'GET',
      target: 'residents/list_hospice'
    };
    const payload = {
      'facility': this.linkData.facility
    };
    const result = await this.apiService.apiFn(action, payload);
    this.hospice = result['data'];

    $(document).find('.table-level-hospice').scrollTop(0);
  }

  async getOutoffacList() {
    const action = {
      type: 'GET',
      target: 'residents/list_outoffac'
    };
    const payload = {
      'facility': this.linkData.facility
    };
    const result = await this.apiService.apiFn(action, payload);
    this.outoffac = result['data'];
    // this.scrollerFunc();
    $(document).find('.table-level-outfac').scrollTop(0);
  }

  async getcensusdata() {
    const action = {
      type: 'GET',
      target: 'residents/census_graph'
    };
    const payload = {
      'facility': this.linkData.facility
    };
    const result = await this.apiService.apiFn(action, payload);
    this.extendoutoffac = result['data']['outoffac'];
    this.infac = result['data']['infac'];
   
    this.doughnutChart = new Chart('doughnutChart', {
      type: 'doughnut',
      data: {
        datasets: [{
          data: [this.infac, this.extendoutoffac],
          backgroundColor: ['#1975B8', '#85CFEB' ]
          
        }]

      },
      options: this.chartOptions
    });
  }

  async getopenroomsdata() {
    const action = {
      type: 'GET',
      target: 'zones/open_rooms_graph'
    };
    const payload = {
      'facility': this.linkData.facility
    };
    const result = await this.apiService.apiFn(action, payload);
    this.rooms = result['data']['ready'].map(itm => itm.room).toString().replace(/,/g, ", ");
    $(document).find('.rmno.data-rooms').scrollTop(0);

    this.ready = result['data']['ready'].length;
    this.not_ready = result['data']['not_ready'] - this.ready;
    this.doughnutChart2 = new Chart('doughnutChart2', {
      type: 'doughnut',
      data: {
        datasets: [{
          data: [this.ready, this.not_ready],
          backgroundColor: [  '#1975B8', '#85CFEB'  ]

        }]

      },
      options: this.chartOptions
    });
  }

  async getAnnouncements() {
    const action = { type: 'GET', target: 'announcement/get' };
    const payload = { 'fac_id': this.linkData.facility, 'org_id': this.linkData.organization };
    const result = await this.apiService.apiFn(action, payload);
    if (result['data'] && result['data'].length) {
      this.announcements = result['data'];
    } else {
      this.announcements = [];
    }
    $(document).find('.announcement-scroll').scrollTop(0);
  }

  async getIsolatedResiList() {
    const action = {
      type: 'GET',
      target: 'residents/isolated_list'
    };
    const payload = {
      'facility': this.linkData.facility
    };
    const result = await this.apiService.apiFn(action, payload);
    this.isolated_residents = result['data'];
    this.createTable(this.isolated_residents);
    $(document).find('.table-level-isolation').scrollTop(0);
  }
  timerCompleted(event){
    //console.log("timer end ",event)

      const index = this.isolated_residents.findIndex(item => item._id == event.endTimer);
    // console.log("index",index)
     if(index>-1){

      this.isolated_residents.splice(index,1)  
      this.createTable(this.isolated_residents);   
     }      
     
  }


  createTable(arr) {
    const tableArr: Element[] = arr;
    this.dataSource = new MatTableDataSource(tableArr);
    // this.dataSource.sort = this.sort;
  }

}



