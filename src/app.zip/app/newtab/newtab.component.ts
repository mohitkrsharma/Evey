import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newtab',
  templateUrl: './newtab.component.html',
  styleUrls: ['./newtab.component.scss']
})
export class NewtabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
