import { Component, OnInit, ViewChild, AfterViewInit, ViewEncapsulation, ElementRef } from '@angular/core';
import { SocketService } from './../shared/services/socket/socket.service';
import { ApiService } from './../shared/services/api/api.service';
import { CommonService } from './../shared/services/common.service';
import * as moment from 'moment';
import { MatTableDataSource } from '@angular/material/table';
import { Router, ActivatedRoute } from '@angular/router';
import { ChartType, Label, MultiDataSet, ChartDataSets, ChartOptions } from 'chart.js';
import * as asyncfunc from 'async';
import * as _ from 'underscore';
import { Chart } from 'chart.js';
import { forEach } from '@angular/router/src/utils/collection';
import { Aes256Service } from './../shared/services/aes-256/aes-256.service';
import $ from 'jquery';

@Component({
  selector: 'app-livedashboard',
  templateUrl: './livedashboard.component.html',
  styleUrls: ['./livedashboard.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class LivedashboardComponent implements OnInit, AfterViewInit {
  hashCode: any;
  linkData: any;
  shift: any = {
    'rotation': 0,
    'sTime': 0,
    'eTime': 0,
    'sTimeUTC': 0,
    'eTimeUTC': 0,
    'sMinute': 0,
    'eMinute': 0,
    'start_date': 0,
    'end_date': 0,
    'prevShiftStart': 0
  };
  _date: any;
  _time: any;

  _facilityName = '';
  _levelCares: any = [];
  _prevlevelCares: Number = 0;
  _openCares: any;
  afterConstructor = false;
  dataSource: any;
  missedDataSource: any = [];
  missedData: Number = 0;
  userdata2: any;
  missed: any;
  CareData;
  chartLabel;
  careGraphData: any;
  finalCareDataArr = [];
  colorArray = ['#32a53e', 'rgba(40, 165, 222)'];
  LineChart = null;
  displayedColumnsNew: string[] = ['resident','room', 'care', 'performer', 'pausedtime'] ;
  //'];
  _clientArr: any = [];
  shiftType;
  shiftsTimeUTC;
  toDay_Date;
  _alertCares: any;
  alertDataSource: any;
  alert: any;
  _fallsCares: any;
  fallsDataSource: any;
  fallsUserdata: any;

  timeSolt = [];
  currenttimeSolt = [];
  QtimeSolt = [];

  doughnutChart1;
  totalCount1 = 0;
  checkinCount1 = 0;
  hour1;

  shiftsTimeUTC2;
  doughnutChart2;
  totalCount2 = 0;
  checkinCount2 = 0;
  hour2;

  shiftsTimeUTC3;
  doughnutChart3;
  totalCount3 = 0;
  checkinCount3 = 0;
  hour3;

  shiftsTimeUTC4;
  doughnutChart4;
  totalCount4 = 0;
  checkinCount4 = 0;
  hour4;

  ctx: any;

  // Doughnut
  chartOptions = {
    maintainAspectRatio: false,
    cutoutPercentage: 75,
    elements: {
      arc: {
        borderWidth: 0
      }
    },
    tooltips: { enabled: false }
  };

  chartOptions2 = this.chartOptions;
  chartOptions3 = this.chartOptions;
  chartOptions4 = this.chartOptions;

  dataSource2; dataSource3; dataSource4;
  displayedColumnsMissed = ['name', 'timeslot', 'room_num', 'is_out_of_fac'];

  public doughnutChartType: ChartType = 'doughnut';
  public doughnutChartType2: ChartType = 'doughnut';
  public doughnutChartType3: ChartType = 'doughnut';
  public doughnutChartType4: ChartType = 'doughnut';

  displayedColumnsFalls: string[] = ['resident', 'time'];
  displayedColumnsCareAlert: string[] = ['resident', 'reporter', 'time'];
  Falls = [
    { id: 'resident', value: 'Resident' },
    { id: 'time', value: 'Time' }
  ];

  dataMain; data1; data2; data3;

  constructor(
    private apiService: ApiService,
    private aes256Service: Aes256Service,
    private socketService: SocketService,
    private commonService: CommonService,
    private router: Router,
    private route: ActivatedRoute,
  ) { }

  message: any;
  _closedCount: any = 0;
  _closedCareMinutes: any = 0;
  _unassignedCount: any = 0;
  _unassignedCareMinutes: any = 0;
  _totalCareMinutes: any = 0;
  _totalFalls: any = [];
  _rotation: Object = {
    endTime: Number,
    rotation: Number,
    startTime: Number,
  };

  _performers = [];


  async ngOnInit() {
    let hashcode: any;
    this.hashCode = hashcode = this.route.params['_value']['id'];
    if (!this.hashCode) {
      this.router.navigate(['/']);
    }
    // hashCode = atob(hashCode);
    this.linkData = this.aes256Service.decFnWithsalt((hashcode).replace(/\*/g, '/'));
    if (!this.linkData.organization) {
      this.router.navigate(['/']);
    }
    // const action = {
    //   type: 'LIVE',
    //   target: 'users/update_active_link'
    // };
    // const payload = { userId: this.linkData.userId, hashCode: hashcode };
    // const result = await this.apiService.apiFn(action, payload);
    // if (!result['success']) {
    //   this.router.navigate(['/']);
    // }

    this.getFacility();
    // this._facilityName = result['data']['fac_name'];
    const dateUTC = moment();
    const hours = dateUTC.hour();
    const min = dateUTC.minute();
    this.shift = await this.commonService.get_rotation();
    const that = this;
    that.getDataFunction();
    that.getLoggedInUser();
    this.setDeceleratingTimeout(function () {
      that.getDataFunction();
      that.getLoggedInUser();
      setInterval(async () => {
        that.getDataFunction();
        that.getLoggedInUser();
        that.setDeceleratingTimeout(function () {
          that.getDataFunction();
          that.getLoggedInUser();
        }, 2000, 1);
      }, (15 * 60000));
    }, ((15 - (min % 15)) * 60000), 1);
    setInterval(async () => { that.getDateTime(); }, 1000);

    this.socketService.onTrackCareUpdateFn().subscribe(_response => {
      if (_response) {
        that.getDataFunction();
      }
    });
    this.socketService.onLoginUpdateFn().subscribe(_response => {
      that.getLoggedInUser();
    });
    // this.socketService.onDeleteLiveDashboard().subscribe(_response => {
    //   that.checkIfActive();
    // });
  }

  ngAfterViewInit() {
    this.scrollerFunc('table-performer'); // worked
    this.scrollerFunc('table-mis-checkin'); // worked
    this.scrollerFunc('table-care-notifications'); // worked
    this.scrollerFunc('table-loggedIn'); // worked
    this.scrollerFunc('table-falls'); // worked
    this.scrollerFunc('table-opcare');
  }

  scrollerFunc(classTable) {
   // console.log("calssssssssssss",classTable)

    const that = this;
    const scroller = function (obj) {
     // console.log("ooooooooo",obj)
        const scCnt = $(obj).scrollTop() + 2;
        $(obj).animate({ scrollTop: scCnt }, 100, function() {
        });
        if ($(obj)[0] && ($(obj).scrollTop() + Math.ceil($(obj).innerHeight()) >= $(obj)[0].scrollHeight)) {
          $(obj).animate({ scrollTop: 0 }, 800, function() {
          });
        }
          setTimeout(function () {
            scroller(obj);
          }, 1000);
    };
    setTimeout(function() {
        const scrollHeight = $(document).find('.' + classTable).find('.scroller tbody').height();
          scroller($(document).find('.' + classTable));
    }, 1000);
  }

  async getFacility() {
    const id = this.linkData['facility'];
    const action = { type: 'POST_DASHBOARD', target: 'facility/getfac' };
    const payload = { facilityId: this.linkData.facility };
    const result =  await this.apiService.apiFn(action, payload);
    console.log('resultresultresult', result);
    if (!result['status']) {
      this.router.navigate(['/']);
    }
    this._facilityName = result['data']['fac_name'];
  }

  // async checkIfActive() {
  //   const hashcode = this.hashCode;
  //   this.linkData = this.aes256Service.decFnWithsalt((hashcode).replace(/\*/g, '/'));
  //   const action = {
  //     type: 'LIVE',
  //     target: 'users/update_active_link'
  //   };
  //   const payload = { userId: this.linkData.userId, hashCode: hashcode };
  //   const result = await this.apiService.apiFn(action, payload);
  //   if (!result['success']) {
  //     this.router.navigate(['/']);
  //   }
  // }

  async getDataFunction() {
    this.shift = await this.commonService.get_rotation();
    this.getOngoingShiftDetailsFn();
    this.fetchFalls();
    // this.missedDataSource = [];
    // this.missedData = 0;
    this.fetchLevel();
    this.TimeSlotWise();
    this.loadAllChart();
    this.openCareLeft();
    this.getOngoingOpenCares();
    this.care_graphs();
    this.updateTimeframeLD();
  }

  async updateTimeframeLD() {
    const payload = {
      'hashCode': this.hashCode
    };
    const action = { type: 'POST_DASHBOARD', target: 'users/update_livedb_time' };
    const result = await this.apiService.apiFn(action, payload);
  }

  setDeceleratingTimeout(callback, factor, times) {
    const internalCallback = function (tick, counter) {
      return function () {
        if (--tick >= 0) {
          window.setTimeout(internalCallback, ++counter * factor);
          callback();
        }
      };
    }(times, 0);

    window.setTimeout(internalCallback, factor);
  }

  getOngoingShiftDetailsFn() {
    this.getDateTime();
    this.getOngoingShift();
    this.getOngoingCares();
  }

  // async getDateTime() {
  getDateTime() {
    this._date = moment().format('MMMM Do YYYY');
    this._time = moment().format('HH:mm');
  }

  async getOngoingShift() {
    const shiftnew = await this.commonService.get_rotation();
    this._rotation = shiftnew;
  }

  async getOngoingCares() {
    const payload = {
      'shift': this.shift.rotation,
      'start_date': this.shift.start_date,
      'end_date': this.shift.end_date,
      'sTimeUTC': this.shift.sTimeUTC,
      'eTimeUTC': this.shift.eTimeUTC,
      'facId': this.linkData.facility,
      'sMinute': this.shift.sMinute,
      'eMinute': this.shift.eMinute,
      'shift24start': this.shift.shift24sMinute,
      'shift24end': this.shift.shift24eMinute
    };
    const action = { type: 'POST_DASHBOARD', target: 'reports/shift_live_count_report' };
    const result = await this.apiService.apiFn(action, payload);
    if ( result['data'] && result['data'] && result['data']['reports'] ) {
      const reportData = result['data']['reports'];
      this._closedCount = reportData['totalReport']['totalCarePerformed'];
      this._closedCareMinutes = reportData['totalReport']['timeOnCare'];
      this._unassignedCareMinutes = reportData['totalReport']['timeUnassigned'];
      this._totalCareMinutes = reportData['totalReport']['totalTime'];
      if (reportData['reportValue']) {
        this._performers = reportData['reportValue'];
      }
      $(document).find('.table-performer').scrollTop(0);
    }
    const actionFall = { type: 'POST_DASHBOARD', target: 'reports/fall_live_count_report' };
    const resultFall = await this.apiService.apiFn(actionFall, payload);
    if ( resultFall['data'] && resultFall['data']) {
      this._totalFalls = resultFall['data'];
      $(document).find('.table-falls').scrollTop(0);
    }
  }

  async fetchFalls() {
    let shiftsMinute: any, shifteMinute: any;
    let date1 = moment(), date2 = moment().subtract(1, 'days');
    date1 = date1.utc();
    date2 = date2.utc();
    shiftsMinute = date2['_d'].getTime();
    shifteMinute = date1['_d'].getTime();
    const payload = {
      shiftsMinute: shiftsMinute,
      shifteMinute: shifteMinute,
      facId: this.linkData.facility
    };
    const action = { type: 'POST_DASHBOARD', target: 'reports/fall_record_count_report' };
    const result = await this.apiService.apiFn(action, payload);
    if (result['status']) {
      this._alertCares = result['data'];
      this.alertDataSource = new MatTableDataSource(this._alertCares);
      $(document).find('.table-care-notifications').scrollTop(0);
    }
  }


  async fetchLevel() {

    let shiftsTimeUTC, shifteTimeUTC, shiftsMinute, shifteMinute;
    let dateUTC = moment();
    const hours = dateUTC.hour();
    const min = dateUTC.minute();
    const toDayDate = moment(dateUTC).format('YYYY-MM-DD');
    const toDayHours = (dateUTC.utc()).hours();
    dateUTC = dateUTC.set({ hour: 23, minute: 59, second: 59, millisecond: 0 });
    dateUTC = dateUTC.utc();
    dateUTC = dateUTC['_d'].getTime();

    let schartDate = moment();
    schartDate = schartDate.set({ hour: 0, minute: 0, second: 0, millisecond: 0 });
    schartDate = schartDate.utc();
    schartDate = schartDate['_d'].getTime();

    const hourlist = Array.from({ length: 24 }, (v, k) => k);
    const timeSolt = hourlist.reduce((obj, item) => {
      if (item % 2 === 0) {
        obj.push({ s: item, e: item + 2 });
      }
      return obj;
    }, []);
    let realtimeSlot;
    if (hours % 2 === 1) {
      realtimeSlot = await _.filter(timeSolt, (num) => { if (num.s === hours - 1) { return num; } });
    } else {
      realtimeSlot = await _.filter(timeSolt, (num) => { if (num.s === hours) { return num; } });
    }
    const checkSlot = true;
    // if (realtimeSlot[0].s === hours) {
    //   if (min >= 45) {
    //     checkSlot = true;
    //   } else {
    //     checkSlot = false;
    //     this.missedDataSource = [];
    //     this.missedData = 0;
    //   }
    // } else if (hours === (realtimeSlot[0].s + 1)) {
    //   checkSlot = true;
    // }
    // checkSlot = true;
    if  (checkSlot) {
      const { s, e } = realtimeSlot[0];
      let date1 = moment(), date2 = moment();
      date1 = date1.set({ hour: (s - 1), minute: 45, second: 0, millisecond: 0 });
      // date2 = date2.set({ hour: s, minute: 30, second: 0, millisecond: 0 });
      date2 = date2.set({ hour: s, minute: 45, second: 0, millisecond: 0 });
      date1 = date1.utc();
      date2 = date2.utc();
      shiftsTimeUTC = date1.hours();
      shiftsMinute = date1.minutes();
      shifteTimeUTC = date2.hours();
      shifteMinute = date2.minutes();
      date1 = date1['_d'].getTime();
      date2 = date2['_d'].getTime();

      const payload = {
        schartDate: date1,
        echartDate: date2,
        shiftData: { shiftsTimeUTC: shiftsTimeUTC, shifteTimeUTC: shifteTimeUTC, shiftsMinute: shiftsMinute, shifteMinute: shifteMinute },
        toDayHour: toDayHours,
        toDay_Date: toDayDate,
        realtimeSlot: realtimeSlot,
        facId: this.linkData.facility
      };
      // console.log('========================================', payload);
      const action = { type: 'POST_DASHBOARD', target: 'reports/level_record_count_report' };
      const result = await this.apiService.apiFn(action, payload);
      if (result['status']) {

        if (!_.isEqual(this._levelCares, result['data'])) {
          this._levelCares = result['data'];
          this.missedDataSource = new MatTableDataSource(this._levelCares);
          $(document).find('.table-mis-checkin').scrollTop(0);
          this.missedData = this.missedDataSource.data.length;
        } 
      }
    }
  }

  async TimeSlotWise() {
    let dateUTC = moment();
    const hours = dateUTC.hour();
    this.toDay_Date = moment(dateUTC).format('YYYY-MM-DD');
    const toDayHours = (dateUTC.utc()).hours();
    dateUTC = dateUTC.set({ hour: 23, minute: 59, second: 59, millisecond: 0 });
    dateUTC = dateUTC.utc();
    dateUTC = dateUTC['_d'].getTime();

    let schartDate = moment();
    schartDate = schartDate.set({ hour: 0, minute: 0, second: 0, millisecond: 0 });
    schartDate = schartDate.utc();
    schartDate = schartDate['_d'].getTime();


    const hourlist = Array.from({ length: 24 }, (v, k) => k);
    this.timeSolt = hourlist.reduce((obj, item) => {
      if (item % 2 === 0) {
        obj.push({ s: item, e: item + 2 });
      }
      return obj;
    }, []);
    let realtimeSlot;
    if (hours % 2 === 1) {
      realtimeSlot = await _.filter(this.timeSolt, (num) => { if (num.s === hours - 1) { return num; } });
    } else {
      realtimeSlot = await _.filter(this.timeSolt, (num) => { if (num.s === hours) { return num; } });
    }
    let shiftData;
    const { s, e } = realtimeSlot[0];
    let date1 = moment(), date2 = moment();
    date1 = date1.set({ hour: (s - 1), minute: 45, second: 0, millisecond: 0 });
    // date2 = date2.set({ hour: s, minute: 30, second: 0, millisecond: 0 });
    date2 = date2.set({ hour: s, minute: 45, second: 0, millisecond: 0 });
    date1 = date1.utc();
    date2 = date2.utc();
    date1 = date1['_d'].getTime();
    date2 = date2['_d'].getTime();

    // decare variable
    shiftData = {
      shiftsTimeUTC: this.shiftsTimeUTC
    };

    // this.hour1 = ((realtimeSlot[0].s - 1) > 0) ? `${realtimeSlot[0].s - 1}:45- ${realtimeSlot[0].s}:30` : `11:45- ${realtimeSlot[0].s}:30`;
    this.hour1 = ((realtimeSlot[0].s - 1) > 0) ? `${realtimeSlot[0].s - 1}:45- ${realtimeSlot[0].s}:45` : `11:45- ${realtimeSlot[0].s}:45`;

    const payload = {
      schartDate: date1,
      echartDate: date2,
      shiftData: shiftData,
      toDayHour: toDayHours,
      toDay_Date: this.toDay_Date,
      facId: this.linkData.facility
    };
    const action = { type: 'POST_DASHBOARD', target: 'reports/timeslot_count_report' };
    const result = await this.apiService.apiFn(action, payload);
    // const result = _res['_result']['_records'];
    if (result['data'] && result['status']) {
      this.totalCount1 = result['data']['count'];
      this.checkinCount1 = (result['data'] && result['data']['totalcount']) ? result['data']['totalcount'] : 0;
      const data = [this.totalCount1 - this.checkinCount1, this.checkinCount1];
      if (!_.isEqual(this.dataMain, data)) {
        this.dataMain = data;
        this.doughnutChart1 = new Chart('doughnutChart1', {
          type: 'doughnut',
          data: {
            datasets: [{
              data: data,
              backgroundColor: ['#ef4036', '#32a53e']
            }]

          },
          options: this.chartOptions
        });
      }
    }
  }

  // async loadAllChart() {
  loadAllChart() {
    this.doughnutChart2Fn();
    this.doughnutChart3Fn();
    this.doughnutChart4Fn();
  }

  async doughnutChart2Fn() {
    const cType = 2;
    const dateUTC = moment().subtract(2, 'hours');
    let date1 = moment().subtract(2, 'hours'), date2 = moment().subtract(2, 'hours');
    const hours = dateUTC.hour() % 2 === 1 ? (dateUTC.hour() - 1) : dateUTC.hour();
    // this.toDay_Date = moment(dateUTC).format('YYYY-MM-DD');
    const hourlist = Array.from({ length: 24 }, (v, k) => k);
    this.timeSolt = hourlist.reduce((obj, item) => {
      if (item % 2 === 0) {
        obj.push({ s: item, e: item + 2 });
      }
      return obj;
    }, []);
    let realtimeSlot;
    if (hours % 2 === 1) {
      realtimeSlot = await _.filter(this.timeSolt, (num) => { if (num.s === hours - 1) { return num; } });
    } else {
      realtimeSlot = await _.filter(this.timeSolt, (num) => { if (num.s === hours) { return num; } });
    }
    const { s, e } = realtimeSlot[0];
    date1 = date1.set({ hour: (s - 1), minute: 45, second: 0, millisecond: 0 });
    date2 = date2.set({ hour: s, minute: 45, second: 0, millisecond: 0 });
    // date2 = date2.set({ hour: s, minute: 30, second: 0, millisecond: 0 });
    date1 = date1.utc();
    date2 = date2.utc();

    // get variable on the bases of cType
    if (cType === 2) {
      this.shiftsTimeUTC2 = date1.hours();
      if (realtimeSlot) {
        const rTmSt = realtimeSlot[0].s;
        const strRealtimeSlot = rTmSt <= 12 ? rTmSt === 0 ? `12 AM` : rTmSt === 12 ? `${rTmSt} PM` : `${rTmSt} AM` : `${rTmSt - 12} PM`;
        this.hour2 = strRealtimeSlot;
      }
    }
    date1 = date1['_d'].getTime();
    date2 = date2['_d'].getTime();
    const action = { type: 'POST_DASHBOARD', target: 'reports/timeslot_count_report' };
    const result = await this.apiService.apiFn(action, {
      schartDate: date1,
      echartDate: date2,
      facId: this.linkData.facility
    });
    if (result['data'] && result['status']) {
      let data = [], cType_chartOptions, chartName;
      if (cType === 2) {
        this.totalCount2 = result['count'];
        this.checkinCount2 = result['data']['totalcount'] ? result['data']['totalcount'] : 0;
        data = [this.totalCount2 - this.checkinCount2, this.checkinCount2];
        cType_chartOptions = this.chartOptions2;
        chartName = 'doughnutChart2';
      }

      if (!_.isEqual(this.data1, data)) {
        this.data1 = data;
        this.doughnutChart2 = new Chart(chartName, {
          type: 'doughnut',
          data: {
            datasets: [{
              data: data,
              backgroundColor: ['#ef4036', '#32a53e']
            }]

          },
          options: cType_chartOptions
        });
      }
    }
  }

  async doughnutChart3Fn() {
    const cType = 3;
    const dateUTC = moment().subtract(4, 'hours');
    let date1 = moment().subtract(4, 'hours'), date2 = moment().subtract(4, 'hours');
    const hours = dateUTC.hour() % 2 === 1 ? (dateUTC.hour() - 1) : dateUTC.hour();
    // this.toDay_Date = moment(dateUTC).format('YYYY-MM-DD');
    const hourlist = Array.from({ length: 24 }, (v, k) => k);
    this.timeSolt = hourlist.reduce((obj, item) => {
      if (item % 2 === 0) {
        obj.push({ s: item, e: item + 2 });
      }
      return obj;
    }, []);
    let realtimeSlot;
    if (hours % 2 === 1) {
      realtimeSlot = await _.filter(this.timeSolt, (num) => { if (num.s === hours - 1) { return num; } });
    } else {
      realtimeSlot = await _.filter(this.timeSolt, (num) => { if (num.s === hours) { return num; } });
    }
    const { s, e } = realtimeSlot[0];
    date1 = date1.set({ hour: (s - 1), minute: 45, second: 0, millisecond: 0 });
    date2 = date2.set({ hour: s, minute: 45, second: 0, millisecond: 0 });
    // date2 = date2.set({ hour: s, minute: 30, second: 0, millisecond: 0 });
    date1 = date1.utc();
    date2 = date2.utc();

    // get variable on the bases of cType
    if (cType === 3) {
      if (realtimeSlot) {
        const rTmSt = realtimeSlot[0].s;
        const strRealtimeSlot = rTmSt <= 12 ? rTmSt === 0 ? `12 AM` : rTmSt === 12 ? `${rTmSt} PM` : `${rTmSt} AM` : `${rTmSt - 12} PM`;
        this.hour3 = strRealtimeSlot;
      }
    }

    date1 = date1['_d'].getTime();
    date2 = date2['_d'].getTime();
    const action = { type: 'POST_DASHBOARD', target: 'reports/timeslot_count_report' };
    const result = await this.apiService.apiFn(action, {
      schartDate: date1,
      echartDate: date2,
      facId: this.linkData.facility
    });
    // const result = _res['_result']['_records'];
    if (result['data'] && result['status']) {
      let data = [], cType_chartOptions, chartName;
      if (cType === 3) {
        this.totalCount3 = result['data']['count'];
        this.checkinCount3 = result['data']['totalcount'] ? result['data']['totalcount'] : 0;
        data = [this.totalCount3 - this.checkinCount3, this.checkinCount3];
        cType_chartOptions = this.chartOptions3;
        chartName = 'doughnutChart3';
      }

      if (!_.isEqual(this.data2, data)) {
        this.data2 = data;
        this.doughnutChart3 = new Chart(chartName, {
          type: 'doughnut',
          data: {
            datasets: [{
              data: data,
              backgroundColor: ['#ef4036', '#32a53e']
            }]
          },
          options: cType_chartOptions
        });
      }
    }
  }

  async doughnutChart4Fn() {
    const cType = 4;
    const dateUTC = moment().subtract(6, 'hours');
    let date1 = moment().subtract(6, 'hours'), date2 = moment().subtract(6, 'hours');
    const hours = dateUTC.hour() % 2 === 1 ? (dateUTC.hour() - 1) : dateUTC.hour();
    // this.toDay_Date = moment(dateUTC).format('YYYY-MM-DD');
    const hourlist = Array.from({ length: 24 }, (v, k) => k);
    this.timeSolt = hourlist.reduce((obj, item) => {
      if (item % 2 === 0) {
        obj.push({ s: item, e: item + 2 });
      }
      return obj;
    }, []);
    let realtimeSlot;
    if (hours % 2 === 1) {
      realtimeSlot = await _.filter(this.timeSolt, (num) => { if (num.s === hours - 1) { return num; } });
    } else {
      realtimeSlot = await _.filter(this.timeSolt, (num) => { if (num.s === hours) { return num; } });
    }
    const { s, e } = realtimeSlot[0];
    date1 = date1.set({ hour: (s - 1), minute: 45, second: 0, millisecond: 0 });
    // date2 = date2.set({ hour: s, minute: 30, second: 0, millisecond: 0 });
    date2 = date2.set({ hour: s, minute: 45, second: 0, millisecond: 0 });
    date1 = date1.utc();
    date2 = date2.utc();
    // get variable on the bases of cType
    if (cType === 4) {
      if (realtimeSlot) {
        const rTmSt = realtimeSlot[0].s;
        const strRealtimeSlot = rTmSt <= 12 ? rTmSt === 0 ? `12 AM` : rTmSt === 12 ? `${rTmSt} PM` : `${rTmSt} AM` : `${rTmSt - 12} PM`;
        this.hour4 = strRealtimeSlot;
      }
    }

    date1 = date1['_d'].getTime();
    date2 = date2['_d'].getTime();
    const action = { type: 'POST_DASHBOARD', target: 'reports/timeslot_count_report' };
    const result = await this.apiService.apiFn(action, {
      schartDate: date1,
      echartDate: date2,
      facId: this.linkData.facility
    });
    // const result = _res['_result']['_records'];
    if (result['data'] && result['status']) {
      let data = [], cType_chartOptions, chartName;
      if (cType === 4) {
        this.totalCount4 = result['data']['count'];
        this.checkinCount4 = result['data']['totalcount'] ? result['data']['totalcount'] : 0;
        data = [this.totalCount4 - this.checkinCount4, this.checkinCount4];
        cType_chartOptions = this.chartOptions4;
        chartName = 'doughnutChart4';
      }
      if (!_.isEqual(this.data3, data)) {
        this.data3 = data;
        this.doughnutChart4 = new Chart(chartName, {
          type: 'doughnut',
          data: {
            datasets: [{
              data: data,
              backgroundColor: ['#ef4036', '#32a53e']
            }]

          },
          options: cType_chartOptions
        });
      }
    }
  }

  async openCareLeft() {
    const action = { type: 'POST_DASHBOARD', target: 'reports/prev_open_care_report' };
    const payload = this.shift;
    payload.fac_id = this.linkData.facility;
    const result = await this.apiService.apiFn(action, payload);
    if (result['data'] && result['status']) {
      this._prevlevelCares = result['data'];
    }
  }

  async getLoggedInUser() {
    const action = { type: 'POST_DASHBOARD', target: 'reports/get_loggedin_user' };
    const payload = this.shift;
    payload.fac_id = this.linkData.facility;
    const result = await this.apiService.apiFn(action, payload);
    this._clientArr = [];
    if (result['data'] && result['status']) {
      if(result['data']){
        this._clientArr = result['data'];
      }
      const output = [];
      this._clientArr.forEach(function (item) {
        const existing = output.filter(function (v, i) {
          return v.user_id === item.user_id;
        });
        if (existing.length) {
          const existingIndex = output.indexOf(existing[0]);
          output[existingIndex].platform = output[existingIndex].platform.concat(item.platform);
        } else {
          if (typeof item.platform === 'string') {
            item.platform = [item.platform];
          }
          output.push(item);
        }
      });
      this._clientArr = output;
      $(document).find('.table-loggedIn').scrollTop(0);
    }
    this.updateTimeframeLD();
  }

  removeunderscore(val) {
    return val.replace(/ /g, '_');
  }

  async getOngoingOpenCares() {
    const payload = this.shift;
    payload.fac_id = this.linkData.facility;
    const action = { type: 'POST_DASHBOARD', target: 'reports/ongoing_open_care_report' };
    const result = await this.apiService.apiFn(action, payload);
    if (result['data'] && result['status']) {
      if(result['data']){
        this._openCares = result['data'];
        this.createOngoingCareTable(this._openCares);

      }
    }
  }

  createOngoingCareTable(arr) {
    const tableArr: Element[] = arr;
    if(tableArr){
      this.dataSource = new MatTableDataSource(tableArr);

    }
    this.afterConstructor = true;
    $(document).find('.table-opcare').scrollTop(0);

  }

  async care_graphs() {
    let schartDate, echartDate, date1, date2;
    date1 = moment().subtract(7, 'days');
    date2 = moment();
    schartDate = moment(date1).set({ hour: 0, minute: 0, second: 0, millisecond: 0 });
    schartDate = schartDate.utc();
    schartDate = schartDate['_d'].getTime();

    this.toDay_Date = moment(date2).format('YYYY-MM-DD');

    echartDate = date2;
    echartDate = echartDate.utc();
    echartDate = echartDate['_d'].getTime();
    const action = { type: 'POST_DASHBOARD', target: 'reports/care_graph_report' };
    const _res = await this.apiService.apiFn(action, {
      schartDate: schartDate,
      echartDate: echartDate,
      facId: this.linkData.facility
    });
    this.CareData = _res['data'];
    let ddStr = [];
    for (let i = 0; i < 7; i++) {
      ddStr.push({
        date: moment().subtract(i, 'days').format('YYYY-MM-DD').toString(),
        day: moment().subtract(i, 'days').format('ddd').toString()
      });
    }
    // let ddStr = Array.from({ length: 7 }, (v, k) => moment().subtract(k, 'days').format('YYYY-MM-DD').toString());
    let careFullData = this.CareData.reduce((obj, item) => {
      const dateStr = moment(item.ts_date_created).format('YYYY-MM-DD').toString();
      const dayStr = moment(item.ts_date_created).format('ddd');
      // !existingDates.includes(dateStr) && existingDates.push(dateStr);
      obj.push({ count: 1, dateStr, dayStr });
      return obj;
    }, []);
    careFullData = _.groupBy(careFullData, 'dateStr');
    ddStr = _.sortBy(ddStr, 'date'); // function (o) { return -o.date; });
    const cLabel = [], cData = [];
    // this.CareData=ddStr.map((item) => {
    ddStr.map((item) => {
      cData.push(careFullData[item.date] ? careFullData[item.date].length : 0);
      cLabel.push(item.day);
      // return { count: careFullData[item.date] ? careFullData[item.date].length : 0, date: item.date, day: item.day };
    });
    if (this.CareData && this.CareData.length > 0) {
      this.showCahrt(cData, cLabel, 'Cares Chart', {});
    } else {
      this.showCahrt([], [], 'Cares Chart', {});
    }
  }

  showCahrt(data, cLabel, name, res) {

    const canvas: any = document.getElementById('lineChart');
    let gradientFill = null;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        gradientFill = ctx.createLinearGradient(0, 0, 0, canvas.height * 2);
        gradientFill.addColorStop(0, '#3CB54A');
        gradientFill.addColorStop(1, 'rgba(255, 255, 255, 0.5)');
      }
    }
    if (!gradientFill) {
      gradientFill = 'white';
    }

    // gradientFill

    const options = {
      maintainAspectRatio: false,
      responsive: true,
      spanGaps: false,
      elements: {
        line: {
          tension: 0.4
        }
      },
      plugins: {
        filler: {
          propagate: false
        }
      },
      legend: {
        display: false,
        // onClick: (e) => e.stopPropagation()
      },
      scales: {
        xAxes: [{
          // display: false,
          scaleShowLabels: false,
          // ticks: {
          //   autoSkip: false,
          //   maxRotation: 0
          // }
        }],
        // yAxes: [{
        //   display: true,
        //   scaleShowLabels: false,
        // }]
      }
    };
    if (data && data.length > 0) {
      // this.chartdata = data;
      if (this.LineChart) {
        this.LineChart.destroy();
        // this.LineChart = '';
      }

      this.LineChart = new Chart('lineChart', {
        type: 'line',
        data: {
          labels: cLabel,
          datasets: [{
            backgroundColor: gradientFill,
            data: data,
            borderWidth: 2,

            pointBackgroundColor: 'white',
            pointBorderColor: '#55D8FE',
            borderColor: '#3CB54A',
            pointRadius: 5,

            // label: 'Dataset',
           // fill: true
          }]
        },

        options: Chart.helpers.merge(options, {
          title: {
            text: 'fill: ' + 'start',
            display: false
          }
        })
      });

      // this.dataSource = new MatTableDataSource(this.chartdata);
      if (name === 'No record found!') {
        // this.noRecord = false;
      }
    } else {
      // this.noRecord = false;
    }
  }
}
