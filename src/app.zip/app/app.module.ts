import { LayoutModule } from '@angular/cdk/layout';
import { OverlayModule } from '@angular/cdk/overlay';
import { NgModule } from '@angular/core';
import { BrowserModule, DomSanitizer } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { PersistenceModule } from 'angular-persistence';
import { ChartsModule } from 'ng2-charts';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatIconModule, MatProgressSpinnerModule,
    MatCheckboxModule, MatInputModule, MatRadioModule, MatExpansionModule, MatSelectModule,
    MatCardModule } from '@angular/material';
import { MatTooltipModule } from '@angular/material/tooltip';
import {CdkStepperModule} from '@angular/cdk/stepper';
import {MatStepperModule} from '@angular/material';
import { ToastrModule } from 'ngx-toastr';
import { AgmCoreModule } from '@agm/core';
import { MatIconRegistry } from '@angular/material/icon';
import 'hammerjs';

// SOCKET
import { SocketIoModule, SocketIoConfig } from 'ngx-socket-io';
import { environment } from './../environments/environment';
const config: SocketIoConfig = { url: environment.config.socket_url, options: {} };
import { SocketService } from './shared/services/socket/socket.service';
import { CookieService } from 'ngx-cookie-service';

/////////////////////////////////////////////////////////////////////////////

// import Store from './shared/store';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ApiService } from './shared/services/api/api.service';
import { CommonService } from './shared/services/common.service';
import { ConstantsService } from './shared/services/constants.service';
import { Aes256Service } from './shared/services/aes-256/aes-256.service';
import { ScheduleModalComponent } from './shared/modals/schedule-modal/schedule-modal.component';
import { NgxMaskModule } from 'ngx-mask';
import { AlertComponent } from './shared/modals/alert/alert.component';
import { ExcelService } from './shared/services/excel.service';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { SavereportComponent } from './shared/modals/savereport/savereport.component';
import { SetnewpasswordComponent } from './password/setnewpassword/setnewpassword.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { ForgotpasswordComponent } from './password/forgotpassword/forgotpassword.component';
import { NewtabComponent } from './newtab/newtab.component';
import { MatTableModule, MatSortModule } from '@angular/material';
import { StoreModule } from '@ngrx/store';
import { authReducer } from './shared/store/auth/reducer';
import { shiftRep_Reducer } from './shared/store/shiftReport/reducer';
import { DECLARATIONS, PROVIDERS, IMPORTS } from './shared/exports/exports';

@NgModule({
    declarations: [
        AppComponent,
        ScheduleModalComponent,
        AlertComponent,
        SavereportComponent,
        NotfoundComponent,
        ForgotpasswordComponent,
        NewtabComponent,
        SetnewpasswordComponent,
        DECLARATIONS,
    ],
    imports: [
        StoreModule.forRoot({ authState: authReducer, shiftRepState: shiftRep_Reducer }),
        BrowserModule,
        AppRoutingModule,
        ChartsModule,
        BrowserAnimationsModule,
        ToastrModule.forRoot({ maxOpened: 1, autoDismiss: true, timeOut: 2000, preventDuplicates: true, }),
        LayoutModule,
        OverlayModule,
        HttpClientModule,
        HttpModule,
        PersistenceModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatCheckboxModule,
        MatInputModule,
        MatRadioModule,
        MatExpansionModule,
        MatSelectModule,
        MatCardModule,
        NgxMaskModule.forRoot(),
        AgmCoreModule.forRoot({
            apiKey: 'AIzaSyC2lht-_fRNIFmJ2Lj2RfEPdN9rvCSGpfw',
            libraries: ['places']
        }),
        AngularMultiSelectModule,
        MatProgressSpinnerModule,
        MatIconModule,
        SocketIoModule.forRoot(config),
        MatTableModule,
        MatSortModule,
        IMPORTS,
        MatTooltipModule,
        CdkStepperModule,
        MatStepperModule
    ],
    providers: [
        ApiService,
        Aes256Service,
        ExcelService,
        CommonService,
        ConstantsService,
        SocketService,
        CookieService,
        PROVIDERS
    ],
    bootstrap: [AppComponent],
    entryComponents: [ScheduleModalComponent, AlertComponent, SavereportComponent]
})

export class AppModule {
    constructor(matIconRegistry: MatIconRegistry, domSanitizer: DomSanitizer) {
        matIconRegistry.addSvgIconSet(domSanitizer.bypassSecurityTrustResourceUrl('https://edricchan03.github.io/res/mdi.svg'));
      }
}
