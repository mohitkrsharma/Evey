import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './shared/guard/auth.guard';
import { LivedashGuard } from './shared/guard/livedash.guard';
import { SetnewpasswordComponent } from './password/setnewpassword/setnewpassword.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { ForgotpasswordComponent } from './password/forgotpassword/forgotpassword.component';
import { NewtabComponent } from './newtab/newtab.component';


const routes: Routes = [
    {
        path: 'forgot',
        component: ForgotpasswordComponent
    },
    {
        path: '',
        loadChildren: './layout/layout.module#LayoutModule'
    },
    {
        path: 'newtab',
        component: NewtabComponent
    },
    {
        path: 'newPassword/:id',
        component: SetnewpasswordComponent
    },
    {
        path: 'livedashboard/:id',
        loadChildren: './livedashboard/livedashboard.module#LivedashboardModule'
    },
    {
        path: 'statusdashboard/:id',
        loadChildren: './statusdashboard/statusdashboard.module#StatusdashboardModule'
    },
    {
        path: '**',
        redirectTo: 'notfound'
    },
    {
        path: 'notfound',
        component: NotfoundComponent
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
    providers: [AuthGuard, LivedashGuard]
})
export class AppRoutingModule { }
